import asyncio
from bleak import BleakScanner

async def scan():
    print("扫描中...（10 秒）")
    devices = await BleakScanner.discover(timeout=10)
    for d in devices:
        print(f"发现设备: {d.name}  地址: {d.address}")

asyncio.run(scan())