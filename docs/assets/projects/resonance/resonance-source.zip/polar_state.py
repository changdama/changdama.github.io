"""
Polar H10 · 统一状态向量 v2
============================

三阶段流程:
  WARMUP (30s)      → 传感器稳定, ACC 基线建立 (sec 15-30)
  CALIBRATION (60s) → 仅累计 still 数据, 建立 HRV/HR 基线
  REALTIME (180s)   → 输出 predicted/confirmed state, 运动排除

依赖:
    pip install bleak numpy
"""

import asyncio
import time
import numpy as np
from enum import Enum
from collections import deque
from bleak import BleakClient, BleakScanner
from music_mapping import MusicMapper

# === BLE UUIDs ===
HR_CHAR_UUID = "00002a37-0000-1000-8000-00805f9b34fb"
PMD_CONTROL  = "FB005C81-02E7-F387-1CAD-8ACD2D8DF0C8"
PMD_DATA     = "FB005C82-02E7-F387-1CAD-8ACD2D8DF0C8"

ACC_START_CMD = bytearray([
    0x02, 0x02,
    0x00, 0x01, 0xC8, 0x00,
    0x01, 0x01, 0x10, 0x00,
    0x02, 0x01, 0x08, 0x00,
])

ACC_SAMPLE_RATE = 200


class Phase(Enum):
    WARMUP = "warmup"
    CALIBRATION = "calibration"
    REALTIME = "realtime"


class State:
    def __init__(self):
        self.phase = Phase.WARMUP
        self.phase_start_time = 0.0
        self.session_start_time = 0.0

        self.hr = None

        self.rr_realtime = deque()
        self.rr_calibration = []
        self.hr_calibration = []
        self.calibration_still_seconds = 0
        self.calibration_paused = False
        self.last_valid_rr = None
        self.artifact_count = 0
        self.valid_rr_count = 0

        self.baseline_rmssd = None
        self.baseline_hr = None

        self.mag_short = deque(maxlen=400)
        self.acc_warmup_samples = []
        self.acc_collection_started = False
        self.activity_baseline = None

        self.activity_history = deque(maxlen=10)
        self.movement_state = "unknown"

        self.still_streak_seconds = 0
        self.motion_excluded = False
        self.recovery_pending = False
        self.still_recovery_seconds = 0

        self.predicted_state = "unknown"
        self.confirmed_state = "unknown"
        self.predicted_state_streak = 0

        self.last_tap_time = 0.0
        self.tap_history = deque(maxlen=30)
        self.last_highlight_time = 0.0
        self.HIGHLIGHT_COOLDOWN = 5.0
        self.new_tap_this_update = False
        self.new_highlight_this_update = False

        self.last_hr_time = 0.0
        self.last_acc_time = 0.0
        self.STALE_TIMEOUT = 3.0

        self.warmup_rr_count = 0
        self.latest_state_vector = None


state = State()


# ===== Parsing =====

def parse_hr_data(data: bytearray):
    flags = data[0]
    hr_16bit = flags & 0x01
    rr_present = (flags & 0x10) >> 4
    offset = 1
    if hr_16bit:
        hr = int.from_bytes(data[offset:offset+2], "little")
        offset += 2
    else:
        hr = data[offset]
        offset += 1
    rr_intervals = []
    if rr_present:
        while offset < len(data):
            rr_raw = int.from_bytes(data[offset:offset+2], "little")
            rr_ms = rr_raw * 1000 / 1024
            rr_intervals.append(rr_ms)
            offset += 2
    return hr, rr_intervals


def filter_rr_artifact(new_rr, last_valid_rr):
    if new_rr < 300 or new_rr > 2000:
        return False
    if last_valid_rr is not None:
        if abs(new_rr - last_valid_rr) / last_valid_rr > 0.25:
            return False
    return True


def compute_rmssd(rr_list):
    if len(rr_list) < 5:
        return None
    diffs = np.diff(np.array(rr_list))
    return float(np.sqrt(np.mean(diffs ** 2)))


def parse_acc_data(data: bytearray):
    if len(data) < 10 or data[0] != 0x02 or data[9] != 0x01:
        return []
    samples = []
    offset = 10
    while offset + 6 <= len(data):
        ax = int.from_bytes(data[offset:offset+2], "little", signed=True)
        ay = int.from_bytes(data[offset+2:offset+4], "little", signed=True)
        az = int.from_bytes(data[offset+4:offset+6], "little", signed=True)
        samples.append((ax/1000.0, ay/1000.0, az/1000.0))
        offset += 6
    return samples


def compute_magnitude(samples):
    return [np.sqrt(ax*ax + ay*ay + az*az) - 1.0 for ax, ay, az in samples]


def compute_activity_level(mag_window):
    if len(mag_window) < 100:
        return None
    arr = np.array(mag_window)
    rms = float(np.sqrt(np.mean(arr ** 2)))
    if state.activity_baseline is None:
        return None
    ratio = rms / (state.activity_baseline + 1e-6)
    if ratio <= 1.0:
        return 0.0
    return max(0.0, min(1.0, np.log10(ratio) / 1.7))


# ===== Movement =====

def compute_movement(activity):
    if activity is None:
        return "unknown"
    state.activity_history.append(activity)
    if activity < 0.05:
        return "still"
    if len(state.activity_history) >= 4:
        recent4 = list(state.activity_history)[-4:]
        if sum(1 for a in recent4 if a >= 0.3) >= 3:
            return "strong_motion"
    return "small_motion"


# ===== Stress Classification =====

def classify_stress(ratio, hr=None, baseline_hr=None):
    if ratio is None:
        return "unknown"
    hr_diff = 0
    if hr is not None and baseline_hr is not None:
        hr_diff = hr - baseline_hr
    if ratio < 0.85 and hr_diff > 20:
        return "activated"
    if ratio > 1.5 and hr_diff <= 8:
        return "deeply_relaxed"
    if ratio > 1.2 and hr_diff > 12:
        return "recovering"
    if ratio > 1.2 and hr_diff <= 12:
        return "relaxed"
    if hr_diff > 12:
        return "tense"
    if ratio >= 0.85:
        return "neutral"
    return "tense"


# ===== Tap Detection =====

def detect_tap_in_samples(samples):
    new_taps = 0
    now = time.time()
    for ax, ay, az in samples:
        mag = abs(np.sqrt(ax*ax + ay*ay + az*az) - 1.0)
        if mag > 2.0:
            if now - state.last_tap_time > 0.2:
                state.last_tap_time = now
                state.tap_history.append(now)
                new_taps += 1
        now += 1.0 / ACC_SAMPLE_RATE
    return new_taps


def get_recent_tap_count(window_sec=3.0):
    now = time.time()
    return sum(1 for t in state.tap_history if now - t < window_sec)


def check_highlight_trigger():
    now = time.time()
    if now - state.last_highlight_time < state.HIGHLIGHT_COOLDOWN:
        return False
    if sum(1 for t in state.tap_history if now - t < 1.5) >= 2:
        state.last_highlight_time = now
        return True
    return False


# ===== Calibration =====

def check_hr_stability():
    if len(state.hr_calibration) < 20:
        return False, "insufficient HR data"
    hr_arr = np.array(state.hr_calibration)
    p90 = np.percentile(hr_arr, 90)
    p10 = np.percentile(hr_arr, 10)
    if p90 - p10 > 8:
        return False, f"HR range: P10={p10:.0f} P90={p90:.0f} ({p90-p10:.1f} bpm)"
    x = np.arange(len(hr_arr))
    slope = np.polyfit(x, hr_arr, 1)[0]
    avg_rr_sec = np.mean(np.array(state.rr_calibration)) / 1000.0 if state.rr_calibration else 0.75
    slope_per_min = slope * (60.0 / avg_rr_sec)
    if slope_per_min < -4.0:
        return False, f"HR declining: {slope_per_min:.1f} bpm/min"
    return True, "stable"


def try_complete_calibration():
    if state.calibration_still_seconds < 40:
        return False, "still accumulating"
    stable, msg = check_hr_stability()
    if not stable:
        return False, msg
    state.baseline_rmssd = compute_rmssd(state.rr_calibration)
    if state.baseline_rmssd is None:
        return False, "RMSSD computation failed"
    state.baseline_hr = float(np.median(state.hr_calibration))
    return True, "success"


def reset_calibration():
    state.rr_calibration.clear()
    state.hr_calibration.clear()
    state.calibration_still_seconds = 0
    state.calibration_paused = False
    state.last_valid_rr = None
    state.phase_start_time = time.time()


def invalidate_realtime():
    state.movement_state = "unknown"
    state.motion_excluded = True
    state.recovery_pending = False
    state.still_streak_seconds = 0
    state.still_recovery_seconds = 0
    state.rr_realtime.clear()
    state.last_valid_rr = None
    state.predicted_state = "unknown"
    state.confirmed_state = "unknown"
    state.predicted_state_streak = 0


# ===== Realtime RMSSD =====

def compute_realtime_rmssd():
    now = time.time()
    cutoff = now - 30.0
    while state.rr_realtime and state.rr_realtime[0][0] < cutoff:
        state.rr_realtime.popleft()
    if len(state.rr_realtime) < 20:
        return None
    return compute_rmssd([rr for _, rr in state.rr_realtime])


# ===== State Stability =====

def update_state_stability(new_predicted):
    if new_predicted == state.predicted_state:
        state.predicted_state_streak += 1
    else:
        state.predicted_state = new_predicted
        state.predicted_state_streak = 1
    if state.predicted_state_streak >= 5 and state.still_recovery_seconds >= 15:
        state.confirmed_state = state.predicted_state


# ===== Motion Exclusion =====

def update_motion_state(movement):
    if movement == "still":
        state.still_streak_seconds += 1
        state.still_recovery_seconds += 1
        if state.still_streak_seconds >= 3:
            state.motion_excluded = False
            state.recovery_pending = True
        if state.still_recovery_seconds >= 15 and len(state.rr_realtime) >= 20:
            state.recovery_pending = False
    else:
        state.rr_realtime.clear()
        state.still_streak_seconds = 0
        state.still_recovery_seconds = 0
        state.motion_excluded = True
        state.recovery_pending = False
        state.predicted_state = "unknown"
        state.confirmed_state = "unknown"
        state.predicted_state_streak = 0
        state.last_valid_rr = None


# ===== Build State Dict =====

def compute_confidence(movement, rmssd_ratio):
    if movement == "unknown":
        return "low"
    if state.motion_excluded:
        return "low"
    if state.recovery_pending:
        return "low"
    if rmssd_ratio is None:
        return "low"
    if state.still_recovery_seconds < 15:
        return "low"
    if len(state.rr_realtime) < 20:
        return "low"
    if state.confirmed_state == "unknown":
        return "low"
    return "high"


def build_state_dict(activity, movement, rmssd, rmssd_ratio, tap, highlight):
    confidence = compute_confidence(movement, rmssd_ratio)
    sv = {
        "timestamp": time.time(),
        "phase": state.phase.value,
        "hr": state.hr,
        "baseline_hr": state.baseline_hr,
        "rmssd": round(rmssd, 1) if rmssd is not None else None,
        "rmssd_ratio": round(rmssd_ratio, 2) if rmssd_ratio is not None else None,
        "predicted_state": state.predicted_state,
        "confirmed_state": state.confirmed_state,
        "confidence": confidence,
        "activity": round(activity, 2) if activity is not None else None,
        "movement_state": movement,
        "motion_excluded": state.motion_excluded,
        "recovery_pending": state.recovery_pending,
        "sensor_available": movement != "unknown",
        "tap": tap,
        "tap_count_3s": get_recent_tap_count(3.0),
        "highlight_marker": highlight,
        "valid_rr_count": len(state.rr_realtime),
        "artifact_count": state.artifact_count,
        "calibrated": state.baseline_rmssd is not None,
    }
    state.latest_state_vector = sv
    return sv


# ===== BLE Callbacks =====

def hr_callback(_, data):
    state.last_hr_time = time.time()
    hr, rrs = parse_hr_data(data)
    state.hr = hr

    for rr in rrs:
        if state.phase in (Phase.CALIBRATION, Phase.REALTIME):
            if state.movement_state != "still":
                continue

        if not filter_rr_artifact(rr, state.last_valid_rr):
            state.artifact_count += 1
            continue

        state.last_valid_rr = rr
        state.valid_rr_count += 1

        if state.phase == Phase.WARMUP:
            state.warmup_rr_count += 1
        elif state.phase == Phase.CALIBRATION:
            state.rr_calibration.append(rr)
            state.hr_calibration.append(hr)
        elif state.phase == Phase.REALTIME:
            state.rr_realtime.append((time.time(), rr))


def acc_callback(_, data):
    state.last_acc_time = time.time()
    samples = parse_acc_data(data)
    if not samples:
        return

    mags = compute_magnitude(samples)
    for m in mags:
        state.mag_short.append(abs(m))
        if state.acc_collection_started and state.activity_baseline is None:
            state.acc_warmup_samples.append(abs(m))

    new_taps = detect_tap_in_samples(samples)
    if new_taps > 0:
        state.new_tap_this_update = True
        if check_highlight_trigger():
            state.new_highlight_this_update = True


# ===== Main Loop =====

async def main():
    print()
    print("  ╔══════════════════════════════════════════════════════════════════╗")
    print("  ║          共振 Resonance · Polar H10 生理状态系统                ║")
    print("  ║          Physiology → State → Music Control Pipeline            ║")
    print("  ╚══════════════════════════════════════════════════════════════════╝")
    print()
    print("  扫描 Polar H10...")

    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    if not device:
        print("  没找到 Polar H10")
        return

    print(f"  找到: {device.name} ({device.address})")
    print("  连接中...\n")

    async with BleakClient(device) as client:
        await client.start_notify(HR_CHAR_UUID, hr_callback)
        print("  HR 流已启动")

        try:
            await client.write_gatt_char(PMD_CONTROL, ACC_START_CMD, response=True)
            await client.start_notify(PMD_DATA, acc_callback)
            print("  ACC 流已启动 (200Hz)")
        except Exception as e:
            print(f"  ACC 启动失败: {e}")

        state.session_start_time = time.time()
        state.phase_start_time = time.time()

        print("  ── Phase 1: WARMUP (30s) ─────────────────────────────────────")
        print("  传感器稳定 · 前15s调整, 后15s建立ACC基线")
        print()
        print("  演示提示 (校准完成后):")
        print("    · 慢深呼吸 6s吸+8s呼 → 状态变 relaxed / deeply_relaxed")
        print("    · 快速站起 → 状态变 tense / activated")
        print("    · 拍胸口 2 下 → highlight_marker 触发")
        print()

        mapper = MusicMapper()
        realtime_seconds = 0

        try:
            sec = 0
            while True:
                await asyncio.sleep(1)
                sec += 1
                now = time.time()

                # Start ACC collection after 15s
                if not state.acc_collection_started:
                    if now - state.session_start_time >= 15.0:
                        state.acc_collection_started = True

                # Build ACC baseline at 30s using all warmup samples
                if state.activity_baseline is None and state.phase == Phase.WARMUP:
                    if now - state.session_start_time >= 30.0 and state.acc_warmup_samples:
                        arr = np.array(state.acc_warmup_samples)
                        state.activity_baseline = float(np.sqrt(np.mean(arr ** 2)))
                        print(f"  [warmup] ACC 基线 = {state.activity_baseline:.4f} g ({len(arr)} samples)")

                # Connection health
                hr_stale = (state.last_hr_time > 0 and now - state.last_hr_time > state.STALE_TIMEOUT)
                acc_stale = (state.last_acc_time > 0 and now - state.last_acc_time > state.STALE_TIMEOUT)

                if hr_stale and acc_stale:
                    print(f"  [{sec:3d}s] ⚠️ 信号丢失 (HR+ACC)")
                    continue
                elif hr_stale:
                    print(f"  [{sec:3d}s] ⚠️ HR 信号丢失")
                    continue

                # Compute movement
                activity = compute_activity_level(state.mag_short)
                movement = compute_movement(activity)
                state.movement_state = movement

                # Capture tap/highlight
                tap_this_tick = state.new_tap_this_update
                highlight_this_tick = state.new_highlight_this_update
                state.new_tap_this_update = False
                state.new_highlight_this_update = False

                hl_str = " 🎯HIGHLIGHT" if highlight_this_tick else (" 👋TAP" if tap_this_tick else "")
                act_str = f"{activity:.2f}" if activity is not None else "---"

                # === WARMUP ===
                if state.phase == Phase.WARMUP:
                    elapsed = now - state.phase_start_time
                    if state.activity_baseline:
                        acc_status = "ready"
                    elif state.acc_collection_started:
                        acc_status = f"collecting({len(state.acc_warmup_samples)})"
                    else:
                        acc_status = "waiting(15s)"
                    print(f"  [{sec:3d}s] WARMUP | HR:{state.hr or '---':>3} | RR:{state.warmup_rr_count} | act:{act_str} [{movement}] | ACC:{acc_status}{hl_str}")

                    if elapsed >= 30.0:
                        if state.activity_baseline is None:
                            print(f"  [{sec:3d}s] WARMUP | ⚠ ACC 基线尚未就绪, 继续等待...")
                            continue
                        state.phase = Phase.CALIBRATION
                        state.phase_start_time = now
                        state.last_valid_rr = None
                        print()
                        print("  ── Phase 2: CALIBRATION (40s still) ─────────────────────────────")
                        print("  请保持静坐, 建立个人 HRV/HR 基线")
                        print()

                # === CALIBRATION ===
                elif state.phase == Phase.CALIBRATION:
                    if acc_stale or movement == "unknown":
                        # ACC unavailable: full reset of calibration data
                        reset_calibration()
                        print(f"  [{sec:3d}s] CALIBRATION | ⚠ ACC 不可用, 校准数据已清零{hl_str}")
                        continue

                    if movement == "still":
                        state.calibration_still_seconds += 1
                        state.calibration_paused = False
                    else:
                        state.rr_calibration.clear()
                        state.hr_calibration.clear()
                        state.calibration_still_seconds = 0
                        state.last_valid_rr = None
                        state.calibration_paused = True

                    success, msg = try_complete_calibration()
                    if success:
                        state.phase = Phase.REALTIME
                        state.phase_start_time = now
                        hr_arr = np.array(state.hr_calibration)
                        p10 = np.percentile(hr_arr, 10)
                        p90 = np.percentile(hr_arr, 90)
                        print()
                        print("  ┌─ 校准完成 ─────────────────────────────────────────────────┐")
                        print(f"  │  RMSSD 基线 = {state.baseline_rmssd:.1f} ms                           │")
                        print(f"  │  HR 基线    = {state.baseline_hr:.0f} bpm (P10-P90: {p10:.0f}-{p90:.0f})          │")
                        print(f"  │  有效 RR    = {len(state.rr_calibration)} 个                                │")
                        print("  └────────────────────────────────────────────────────────────┘")
                        print()
                        print("  ── Phase 3: REALTIME (180s) ──────────────────────────────────")
                        print("  实时状态推断 + 音乐参数输出")
                        print()
                    else:
                        if state.calibration_still_seconds >= 60 and msg != "still accumulating":
                            print(f"  [{sec:3d}s] CALIBRATION | ⚠ {msg}")
                            reset_calibration()
                            print(f"             重新开始校准...\n")
                        elif state.calibration_paused:
                            print(f"  [{sec:3d}s] CALIBRATION | ⚠ 检测到移动, 数据已清零 | still_time:0s/40s{hl_str}")
                        else:
                            hr_range_str = ""
                            if len(state.hr_calibration) >= 10:
                                hr_arr = np.array(state.hr_calibration)
                                hr_range_str = f" | HR:{np.percentile(hr_arr,10):.0f}-{np.percentile(hr_arr,90):.0f}"
                            print(f"  [{sec:3d}s] CAL | HR:{state.hr or '---':>3} | still:{state.calibration_still_seconds}s/40s | RR:{len(state.rr_calibration)}{hr_range_str} | [{movement}]{hl_str}")

                # === REALTIME ===
                elif state.phase == Phase.REALTIME:
                    realtime_seconds += 1

                    # ACC unavailable: full invalidation
                    if acc_stale or movement == "unknown":
                        invalidate_realtime()
                        sv = build_state_dict(activity, "unknown", None, None, tap_this_tick, highlight_this_tick)
                        print(f"  [{sec:3d}s] HR:{state.hr or '---':>3} | sensor_unavailable (low) | [{state.movement_state}] | RR:0 art:{state.artifact_count}{hl_str}")
                        if realtime_seconds >= 180:
                            break
                        continue

                    update_motion_state(movement)

                    rmssd = compute_realtime_rmssd()
                    rmssd_ratio = None
                    if rmssd is not None and state.baseline_rmssd and state.baseline_rmssd > 0:
                        rmssd_ratio = rmssd / state.baseline_rmssd

                    if not state.motion_excluded and not state.recovery_pending and rmssd_ratio is not None:
                        predicted = classify_stress(rmssd_ratio, state.hr, state.baseline_hr)
                        update_state_stability(predicted)

                    sv = build_state_dict(activity, movement, rmssd, rmssd_ratio, tap_this_tick, highlight_this_tick)

                    rr_count = len(state.rr_realtime)
                    mc = mapper.update(sv)
                    energy_str = f"E:{mc['energy_level']:.2f}"

                    if state.motion_excluded:
                        print(f"  [{sec:3d}s] HR:{state.hr or '---':>3} | 🏃 运动中 [{movement}] act:{act_str} | {energy_str}{hl_str}")
                    elif state.recovery_pending:
                        print(f"  [{sec:3d}s] HR:{state.hr or '---':>3} | ⏳ 恢复中 RR:{rr_count}/20 | {energy_str}{hl_str}")
                    else:
                        if rmssd is not None and rmssd_ratio is not None:
                            rmssd_disp = f"x{rmssd_ratio:.2f}"
                        else:
                            rmssd_disp = "filling"
                        conf_icon = "✓" if sv['confidence'] == 'high' else "○"
                        print(f"  [{sec:3d}s] HR:{state.hr or '---':>3} | HRV {rmssd_disp} | {conf_icon} {state.confirmed_state} | {energy_str}{hl_str}")

                    if mc['emotion_updated_this_tick']:
                        print(f"         ★ 状态确认 → {mc['emotion_source_state']} → 音乐切换: {mc['emotion_texture']}")
                    if mc['motif_event']:
                        print(f"         ♪ HIGHLIGHT 触发")

                    if realtime_seconds >= 180:
                        print()
                        print("  ── 会话结束 ──────────────────────────────────────────────────")
                        print(f"  总时长: {sec}s | 最终状态: {state.confirmed_state}")
                        print(f"  基线: HR={state.baseline_hr:.0f}bpm RMSSD={state.baseline_rmssd:.1f}ms")
                        print(f"  最终音乐: texture={mc['emotion_texture']} energy={mc['energy_level']:.2f}")
                        break

        except KeyboardInterrupt:
            print("\n\n  [Ctrl+C] 用户中断")
            if state.latest_state_vector:
                mc = mapper.update(state.latest_state_vector)
                print(f"  最终状态: {state.confirmed_state} | texture={mc['emotion_texture']} energy={mc['energy_level']:.2f}")

        try:
            await client.stop_notify(HR_CHAR_UUID)
        except Exception:
            pass
        try:
            await client.stop_notify(PMD_DATA)
        except Exception:
            pass

        print("\n  BLE 已断开. 会话结束.")


if __name__ == "__main__":
    asyncio.run(main())
