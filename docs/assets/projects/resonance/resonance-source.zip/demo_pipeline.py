"""
Resonance Signal Pipeline Demo
================================

用 MockSource 模拟完整信号管道跑 30s，终端实时打印:
- 每秒的生理指标
- 每次 Lyria 转向指令（触发原因 + prompts + config）

用法:
    python demo_pipeline.py

不需要 BLE 设备、不需要 Lyria API key。
"""

import asyncio
import time
import sys

from sigbus.bus import SignalBus
from sigbus.sources import MockSource
from sigbus.processors import HRProcessor, CadenceProcessor, BreathProcessor
from sigbus.prompt_composer import PromptComposer, Section
from sigbus.steer_controller import SteerController
from sigbus.calibration import CalibrationManager


# ANSI colors
CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
DIM = '\033[2m'
RESET = '\033[0m'


async def main():
    print()
    print(f"  {CYAN}{'='*60}{RESET}")
    print(f"  {CYAN}  Resonance Signal Pipeline Demo (MockSource, 30s){RESET}")
    print(f"  {CYAN}{'='*60}{RESET}")
    print()

    # === 1. 创建 Bus + Source + Processors ===
    bus = SignalBus(history_size=200)
    source = MockSource(bus)

    hr_proc = HRProcessor(bus, hr_baseline=72.0, rmssd_baseline=40.0)
    cadence_proc = CadenceProcessor(bus, acc_baseline=0.01)
    breath_proc = BreathProcessor(bus)

    # === 2. 校准阶段 (5s 快速模拟) ===
    print(f"  {DIM}[Calibration] 5s 快速校准...{RESET}")
    for sec in range(5):
        source.tick(elapsed_sec=sec, phase='calibration')
        await asyncio.sleep(0.05)  # 加速

    # 设置 baseline
    hr_proc.set_baselines(hr_baseline=72.0, rmssd_baseline=40.0)
    cadence_proc.set_baseline(0.01)
    print(f"  {GREEN}[Calibration] 完成 - HR baseline: 72, RMSSD baseline: 40{RESET}")
    print()

    # === 3. 创建 Composer + SteerController ===
    composer = PromptComposer(
        bus, style='electronic', mood='uplifting',
        hr_baseline=72.0, rmssd_baseline=40.0,
    )
    composer.set_section(Section.VERSE)

    steer_queue = asyncio.Queue(maxsize=10)
    loop = asyncio.get_event_loop()
    controller = SteerController(bus, composer, steer_queue, loop=loop)
    controller.start(loop)

    # === 4. 消费转向指令的后台任务 ===
    steer_log = []

    async def steer_consumer():
        while True:
            try:
                item = await asyncio.wait_for(steer_queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            if item is None:
                break
            steer_log.append(item)

            trigger = item['trigger']
            prompts = item['prompts']
            config = item['config']['music_generation_config']

            color = RED if trigger == 'event' else (YELLOW if trigger == 'drift' else DIM)
            prompt_summary = ' | '.join(
                f"{p['text'][:30]}({p['weight']:.1f})" for p in prompts[:4]
            )
            print(f"  {color}[STEER:{trigger:>8}]{RESET} "
                  f"bpm={config['bpm']} den={config['density']} "
                  f"bri={config['brightness']} gui={config['guidance']}")
            print(f"  {DIM}    prompts: {prompt_summary}{RESET}")

    consumer_task = asyncio.create_task(steer_consumer())

    # === 5. Running Phase (30s) ===
    print(f"  {CYAN}[Running] 开始模拟跑步 30s...{RESET}")
    print(f"  {DIM}  (秒 10: 切换到 Chorus, 秒 20: 模拟深呼吸事件){RESET}")
    print()

    session_start = time.time()

    for sec in range(1, 31):
        # 模拟数据
        source.tick(elapsed_sec=sec, phase='running')

        # 秒 10: 切换段落
        if sec == 10:
            composer.set_section(Section.CHORUS)
            bus.publish('section.change', {'from': 'verse', 'to': 'chorus'})
            print(f"  {GREEN}[Section] verse -> chorus{RESET}")

        # 秒 20: 模拟深呼吸事件
        if sec == 20:
            bus.publish('breath.deep', True)
            print(f"  {GREEN}[Event] Deep breathing detected!{RESET}")

        # 每 5s 打印 metrics 摘要
        if sec % 5 == 0:
            hr = bus.last_value('hr.smooth', '--')
            delta = bus.last_value('hr.delta', '--')
            cadence = bus.last_value('cadence.smooth', '--')
            rmssd = bus.last_value('hrv.rmssd', '--')
            breath = bus.last_value('breath.rate', '--')

            hr_str = f"{hr:.0f}" if isinstance(hr, float) else str(hr)
            delta_str = f"+{delta:.0f}" if isinstance(delta, float) and delta >= 0 else (f"{delta:.0f}" if isinstance(delta, float) else str(delta))
            cad_str = f"{cadence:.0f}" if isinstance(cadence, float) else str(cadence)
            rmssd_str = f"{rmssd:.0f}" if isinstance(rmssd, float) else str(rmssd)
            br_str = f"{breath:.1f}" if isinstance(breath, float) else str(breath)

            print(f"  [{sec:2d}s] HR:{hr_str} ({delta_str}) | "
                  f"Cadence:{cad_str} | RMSSD:{rmssd_str} | "
                  f"Breath:{br_str}")

        await asyncio.sleep(0.1)  # 加速模拟 (实际每秒)

    # === 6. 停止 ===
    controller.stop()
    try:
        steer_queue.put_nowait(None)
    except asyncio.QueueFull:
        pass
    await consumer_task

    # === 7. 统计 ===
    stats = controller.get_stats()
    print()
    print(f"  {CYAN}{'='*60}{RESET}")
    print(f"  {CYAN}  Session Complete{RESET}")
    print(f"  {CYAN}{'='*60}{RESET}")
    print(f"  Total steers: {stats['total_steers']}")
    print(f"    Event-driven: {stats['event_steers']}")
    print(f"    Drift-based:  {stats['drift_steers']}")
    print(f"    Fallback:     {stats['fallback_steers']}")
    print()
    print(f"  {DIM}(旧方案: 固定每 3s 转向 = 10 次/30s)")
    print(f"  (新方案: 事件驱动 = 仅在有意义变化时转向){RESET}")
    print()


if __name__ == '__main__':
    asyncio.run(main())
