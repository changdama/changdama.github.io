"""
test_mapping.py · 模拟状态向量 → 验证 MusicMapper 输出
======================================================

无需 Polar H10，直接用合成数据验证 mapping 逻辑。
"""

from music_mapping import MusicMapper

scenarios = [
    {
        "name": "1. 静坐 neutral — 高置信, texture 更新",
        "sv": {"phase": "realtime", "hr": 68, "confirmed_state": "neutral",
               "confidence": "high", "motion_excluded": False, "recovery_pending": False,
               "movement_state": "still", "highlight_marker": False, "baseline_hr": 65},
    },
    {
        "name": "2. 深呼吸放松 — texture 切换到 gentle_flowing",
        "sv": {"phase": "realtime", "hr": 62, "confirmed_state": "relaxed",
               "confidence": "high", "motion_excluded": False, "recovery_pending": False,
               "movement_state": "still", "highlight_marker": False, "baseline_hr": 65},
    },
    {
        "name": "3. 开始运动 — energy 上升, texture 冻结",
        "sv": {"phase": "realtime", "hr": 95, "confirmed_state": "relaxed",
               "confidence": "low", "motion_excluded": True, "recovery_pending": False,
               "movement_state": "strong_motion", "highlight_marker": False, "baseline_hr": 65},
    },
    {
        "name": "4. 运动中拍胸口 — motif 触发, energy 继续",
        "sv": {"phase": "realtime", "hr": 102, "confirmed_state": "relaxed",
               "confidence": "low", "motion_excluded": True, "recovery_pending": False,
               "movement_state": "small_motion", "highlight_marker": True, "baseline_hr": 65},
    },
    {
        "name": "5. 恢复中(静止但HRV未就绪) — energy 继续跟随平滑HR, texture 冻结",
        "sv": {"phase": "realtime", "hr": 78, "confirmed_state": "relaxed",
               "confidence": "low", "motion_excluded": False, "recovery_pending": True,
               "movement_state": "still", "highlight_marker": False, "baseline_hr": 65},
    },
    {
        "name": "6. 完全恢复, 新状态 — texture 更新为 grounded_stabilizing",
        "sv": {"phase": "realtime", "hr": 70, "confirmed_state": "tense",
               "confidence": "high", "motion_excluded": False, "recovery_pending": False,
               "movement_state": "still", "highlight_marker": False, "baseline_hr": 65},
    },
]


def main():
    mapper = MusicMapper()

    print("=" * 70)
    print("MusicMapper 模拟测试")
    print("=" * 70)

    for scenario in scenarios:
        result = mapper.update(scenario["sv"])
        print(f"\n--- {scenario['name']} ---")
        print(f"  输入: HR={scenario['sv']['hr']} | conf={scenario['sv']['confidence']} "
              f"| motion_excl={scenario['sv']['motion_excluded']} "
              f"| recovery={scenario['sv']['recovery_pending']} "
              f"| movement={scenario['sv']['movement_state']}")
        print(f"  输出:")
        print(f"    emotion_texture:       {result['emotion_texture']}")
        print(f"    energy_level:          {result['energy_level']}")
        print(f"    motif_event:           {result['motif_event']}")
        print(f"    hrv_paused:            {result['hrv_paused']}")
        print(f"    motion_active:         {result['motion_active']}")
        print(f"    emotion_source_state:  {result['emotion_source_state']}")
        print(f"    emotion_updated:       {result['emotion_updated_this_tick']}")

    print("\n" + "=" * 70)
    print("验证要点:")
    print("  - texture 仅在 #1, #2, #6 变化 (confidence==high)")
    print("  - energy 每 tick 变化 (HR 驱动)")
    print("  - motif 仅在 #4 触发 (highlight_marker)")
    print("  - hrv_paused: #3,#4,#5 = True")
    print("  - motion_active: #3,#4 = True; #5 = False (静止恢复中)")
    print("=" * 70)


if __name__ == "__main__":
    main()
