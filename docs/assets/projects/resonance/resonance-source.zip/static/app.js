const socket = io();

// Client-side timer (avoids server timestamp jitter)
let timerInterval = null;
let elapsedSec = 0;
let totalSec = 300;

function startTimer(durationMin) {
    stopTimer();
    elapsedSec = 0;
    totalSec = durationMin * 60;
    document.getElementById('elapsed-time').textContent = formatTime(0);
    document.getElementById('total-time').textContent = formatTime(totalSec);
    timerInterval = setInterval(() => {
        elapsedSec++;
        document.getElementById('elapsed-time').textContent = formatTime(elapsedSec);
    }, 1000);
}

function stopTimer() {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
}

// === Phase Management ===
function showPhase(name) {
    document.querySelectorAll('.phase').forEach(el => el.classList.remove('active'));
    document.getElementById('phase-' + name).classList.add('active');
}

// === Setup Phase ===
document.getElementById('btn-start').addEventListener('click', () => {
    const style = document.getElementById('sel-style').value;
    const mood = document.getElementById('sel-mood').value;
    const duration = parseInt(document.getElementById('sel-duration').value);
    socket.emit('start_session', { style, mood, duration });
    showPhase('calibration');
});

// === Calibration Events ===
socket.on('connection_status', (data) => {
    document.getElementById('cal-status').textContent = data.message;
});

socket.on('calibration_tick', (data) => {
    document.getElementById('cal-hr').textContent = data.hr || '--';
    document.getElementById('cal-rr').textContent = data.rr_count;
    document.getElementById('cal-acc').textContent = data.acc_samples;
    document.getElementById('cal-countdown').textContent = data.remaining;
    const pct = Math.min(100, (data.elapsed / 30) * 100);
    document.getElementById('cal-progress').style.width = pct + '%';
    if (data.status) {
        document.getElementById('cal-status').textContent = data.status;
    }
});

socket.on('calibration_complete', (data) => {
    const totalMin = data.duration_min || 5;
    showPhase('running');
    startTimer(totalMin);
});

// === Running Phase ===

// Section buttons
document.querySelectorAll('.btn-section').forEach(btn => {
    btn.addEventListener('click', () => {
        const section = btn.dataset.section;
        socket.emit('switch_section', { section });
    });
});

socket.on('section_changed', (data) => {
    document.querySelectorAll('.btn-section').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.section === data.section);
    });
});

// Metrics update
socket.on('metrics_update', (data) => {
    const p = data.physiology;

    // HR
    document.getElementById('m-hr').textContent = p.hr || '--';

    // Delta HR
    if (p.delta_hr !== null && p.delta_hr !== undefined) {
        const sign = p.delta_hr >= 0 ? '+' : '';
        document.getElementById('m-delta').textContent = sign + Math.round(p.delta_hr);
    } else {
        document.getElementById('m-delta').textContent = '--';
    }

    // Trend
    if (p.hr_trend_10s !== null && p.hr_trend_10s !== undefined) {
        let arrow = '→';
        if (p.hr_trend_10s > 8) arrow = '↑';
        else if (p.hr_trend_10s < -4) arrow = '↓';
        document.getElementById('m-trend').textContent = arrow;
    } else {
        document.getElementById('m-trend').textContent = '--';
    }

    // Cadence
    if (p.cadence) {
        const lockIcon = p.cadence_locked ? '🔒' : '';
        document.getElementById('m-cadence').textContent = Math.round(p.cadence) + lockIcon;
    } else {
        document.getElementById('m-cadence').textContent = '--';
    }

    // RMSSD
    if (p.rmssd !== null && p.rmssd !== undefined) {
        document.getElementById('m-rmssd').textContent = Math.round(p.rmssd);
    } else {
        document.getElementById('m-rmssd').textContent = '--';
    }

    // Breath
    if (data.breath_hold) {
        document.getElementById('m-breath').textContent = 'HOLD';
        document.getElementById('m-breath').style.color = '#ef5350';
    } else if (data.deep_breath_rt) {
        document.getElementById('m-breath').textContent = 'DEEP';
        document.getElementById('m-breath').style.color = '#ab47bc';
    } else if (p.breath_rate) {
        document.getElementById('m-breath').textContent = Math.round(p.breath_rate);
        document.getElementById('m-breath').style.color = '';
    } else {
        document.getElementById('m-breath').textContent = '--';
        document.getElementById('m-breath').style.color = '';
    }

    // Energy level
    let level = '--';
    if (p.delta_hr !== null && p.delta_hr !== undefined) {
        if (p.delta_hr < 15) level = 'light';
        else if (p.delta_hr < 35) level = 'steady';
        else if (p.delta_hr < 50) level = 'strong';
        else level = 'HIGH';
    }
    document.getElementById('energy-fill').setAttribute('data-level', level);
    document.getElementById('energy-label').textContent = level;

    // Timer is handled client-side (see startTimer)

    // Prompt tags
    const tagsDiv = document.getElementById('prompt-tags');
    const tags = data.prompt_tags || [];
    tagsDiv.innerHTML = tags.map(t => `<span class="tag">${t}</span>`).join('');

    // Full prompt
    document.getElementById('full-prompt-text').textContent = data.full_prompt || '';
});

// === Session Complete ===
socket.on('session_complete', (data) => {
    stopTimer();
    showPhase('complete');
    const sections = data.sections || [];
    document.getElementById('summary-sections').textContent = sections.join(' → ');
    document.getElementById('summary-prompt').textContent = data.final_prompt || '';
});

// Restart
document.getElementById('btn-restart').addEventListener('click', () => {
    showPhase('setup');
});

// === Utility ===
function formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
}
