"""
Polar H10 · 加速度计实时监测 (v3)
==================================

v3 调整:
1. 放宽 activity 阈值, 适配真实身体反应幅度
2. 收紧步频判定门槛 (5x 而不是 3x), 避免噪声出读数
3. 显示原始 RMS, 便于校准
4. 步频要求有最低绝对幅度
"""

import asyncio
import time
import numpy as np
from collections import deque
from scipy.signal import welch
from bleak import BleakClient, BleakScanner

PMD_CONTROL = "FB005C81-02E7-F387-1CAD-8ACD2D8DF0C8"
PMD_DATA    = "FB005C82-02E7-F387-1CAD-8ACD2D8DF0C8"

ACC_START_CMD = bytearray([
    0x02, 0x02,
    0x00, 0x01, 0xC8, 0x00,
    0x01, 0x01, 0x10, 0x00,
    0x02, 0x01, 0x08, 0x00,
])

SAMPLE_RATE = 200

mag_short  = deque(maxlen=400)
mag_long   = deque(maxlen=2000)
baseline_samples = deque(maxlen=800)

last_tap_time = 0.0
tap_history = deque(maxlen=20)
activity_baseline = None


def parse_acc_data(data: bytearray):
    if len(data) < 10 or data[0] != 0x02:
        return []
    if data[9] != 0x01:
        return []
    samples = []
    offset = 10
    while offset + 6 <= len(data):
        ax = int.from_bytes(data[offset:offset+2], "little", signed=True)
        ay = int.from_bytes(data[offset+2:offset+4], "little", signed=True)
        az = int.from_bytes(data[offset+4:offset+6], "little", signed=True)
        samples.append((ax/1000.0, ay/1000.0, az/1000.0))
        offset += 6
    return samples


def compute_magnitude(samples):
    return [np.sqrt(ax*ax + ay*ay + az*az) - 1.0 for ax, ay, az in samples]


def compute_rms_raw(mag_window):
    """计算原始 RMS (单位 g), 不做归一化"""
    if len(mag_window) < 100:
        return None
    arr = np.array(mag_window)
    return float(np.sqrt(np.mean(arr ** 2)))


def compute_activity_level(mag_window):
    """
    归一化活动强度.

    v3: 放宽映射, 跑步时大约 0.5-0.7 而不是 1.0
    使用对数式缩放: 基线 -> 0, 基线 × 50 -> 1
    """
    global activity_baseline
    if len(mag_window) < 100:
        return None
    rms = compute_rms_raw(mag_window)
    if activity_baseline is None:
        return rms

    ratio = rms / (activity_baseline + 1e-6)

    if ratio <= 1.0:
        return 0.0
    normalized = min(1.0, np.log10(ratio) / 1.7)
    return max(0.0, normalized)


def classify_movement(activity):
    if activity is None:
        return "  ---  "
    if activity < 0.05:
        return "静止"
    elif activity < 0.25:
        return "轻微"
    elif activity < 0.5:
        return "走路"
    elif activity < 0.8:
        return "跑步"
    else:
        return "冲刺"


def compute_cadence(mag_window):
    """
    通过加速度频谱估算步频.

    v3: 更严格的判定
    1. 主峰能量比平均高 5 倍
    2. 主峰能量必须超过最低绝对阈值
    """
    if len(mag_window) < 800:
        return None

    arr = np.array(mag_window)

    rms = np.sqrt(np.mean(arr ** 2))
    if rms < 0.05:
        return None

    arr = arr - np.mean(arr)

    nperseg = min(len(arr), 1024)
    freqs, psd = welch(arr, fs=SAMPLE_RATE, nperseg=nperseg)

    mask = (freqs >= 1.0) & (freqs <= 3.5)
    if not mask.any():
        return None

    band_freqs = freqs[mask]
    band_psd = psd[mask]

    peak_idx = np.argmax(band_psd)
    peak_power = band_psd[peak_idx]
    mean_power = np.mean(band_psd)

    if peak_power < 5 * mean_power:
        return None

    if 0 < peak_idx < len(band_psd) - 1:
        y0, y1, y2 = band_psd[peak_idx-1], band_psd[peak_idx], band_psd[peak_idx+1]
        denom = y0 - 2*y1 + y2
        delta = 0.5 * (y0 - y2) / denom if abs(denom) > 1e-12 else 0
        df = band_freqs[1] - band_freqs[0]
        peak_freq = band_freqs[peak_idx] + delta * df
    else:
        peak_freq = band_freqs[peak_idx]

    return float(peak_freq * 60)


def detect_tap(samples):
    global last_tap_time, tap_history
    tap_count = 0
    now = time.time()
    for ax, ay, az in samples:
        mag = abs(np.sqrt(ax*ax + ay*ay + az*az) - 1.0)
        if mag > 2.0:
            if now - last_tap_time > 0.2:
                last_tap_time = now
                tap_count += 1
                tap_history.append(now)
        now += 1.0 / SAMPLE_RATE
    return tap_count


def get_recent_tap_count(window_sec=3.0):
    now = time.time()
    return sum(1 for t in tap_history if now - t < window_sec)


async def main():
    global activity_baseline

    print("=" * 70)
    print("Polar H10 · 加速度实时监测 (v3)")
    print("=" * 70)
    print("\n扫描 Polar H10...")

    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    if not device:
        print("没找到 Polar H10")
        return

    print(f"找到设备: {device.name}")
    print("正在连接...\n")

    sample_count = 0
    output_count = 0

    async with BleakClient(device) as client:
        print("已连接, 启动 ACC 流...")
        try:
            await client.write_gatt_char(PMD_CONTROL, ACC_START_CMD, response=True)
            print("ACC 流已启动 (200 Hz)\n")
        except Exception as e:
            print(f"启动失败: {e}")
            return

        print("【校准】前 10 秒静坐, 建立基线...")
        print("【实验顺序建议】:")
        print("  10s 静坐 -> 10s 缓慢走路 -> 10s 快走 -> 10s 跑步")
        print("  中间可以拍胸口测 TAP")
        print()

        def callback(_, data):
            nonlocal sample_count, output_count
            global activity_baseline

            samples = parse_acc_data(data)
            if not samples:
                return

            mags = compute_magnitude(samples)
            for m in mags:
                mag_short.append(abs(m))
                mag_long.append(abs(m))
                if activity_baseline is None:
                    baseline_samples.append(abs(m))

            tap_count = detect_tap(samples)
            if tap_count > 0:
                print(f"  [TAP] x{tap_count}")

            sample_count += len(samples)

            if activity_baseline is None and len(baseline_samples) >= 800:
                arr = np.array(baseline_samples)
                activity_baseline = float(np.sqrt(np.mean(arr ** 2)))
                print(f"\n静息基线 RMS = {activity_baseline:.4f} g\n")

            new_output = sample_count // 200
            if new_output > output_count:
                output_count = new_output

                rms_raw = compute_rms_raw(mag_short)
                activity = compute_activity_level(mag_short)
                cadence = compute_cadence(mag_long)
                recent_taps = get_recent_tap_count(3.0)

                if activity_baseline is None:
                    progress = min(100, len(baseline_samples) * 100 // 800)
                    rms_str = f"{rms_raw:.4f}g" if rms_raw else " --- "
                    print(f"  [校准 {progress}%] RMS={rms_str}")
                else:
                    rms_str = f"{rms_raw:.3f}g" if rms_raw else " --- "
                    ratio = rms_raw / activity_baseline if rms_raw else 0
                    act_str = f"{activity:.2f}" if activity is not None else " --- "
                    cad_str = f"{cadence:5.1f}/min" if cadence is not None else "  ---     "
                    movement = classify_movement(activity)
                    tap_str = f"拍击近3秒 {recent_taps}" if recent_taps > 0 else ""
                    print(f"RMS:{rms_str} x{ratio:5.1f} | 活动:{act_str} [{movement}] | 步频:{cad_str} | {tap_str}")

        await client.start_notify(PMD_DATA, callback)
        await asyncio.sleep(180)
        await client.stop_notify(PMD_DATA)

        print(f"\n会话结束 - 总样本: {sample_count}, 总拍击: {len(tap_history)}")


if __name__ == "__main__":
    asyncio.run(main())