# Lyria RealTime PoC - Prompt Steering Test

## Purpose

Test how quickly Lyria RealTime responds to mid-stream prompt/config changes,
validating feasibility for real-time physiological-data-driven music generation.

## Scripts

### 1. `lyria_realtime_test.py` — Discrete Steering Events

Tests 5 distinct transitions at fixed intervals (simulating goal-based state changes):
- Warmup → Energy Spike → Cadence Lock → HRV Drop → Recovery

Measures latency between sending new prompt and receiving first audio chunk after.

### 2. `lyria_continuous_steer.py` — Continuous Physiological Simulation

Simulates a full 90-second run with realistic physiological changes every 3 seconds.
Maps HR/cadence/HRV/breathing to Lyria's weighted_prompts + music_generation_config.

This is the closest simulation to how the final integration will work.

## Setup

```bash
pip install websockets
```

Create `lyria_poc/.env`:
```
GOOGLE_API_KEY=your_google_ai_api_key_here
```

Or set environment variable:
```bash
export GOOGLE_API_KEY=your_key
```

## Run

```bash
# Test 1: Discrete steering events (50s)
python lyria_poc/lyria_realtime_test.py

# Test 2: Continuous physiological steering (90s)
python lyria_poc/lyria_continuous_steer.py
```

## Output

Each test creates:
- `.wav` files — the generated audio (listen to hear transitions)
- `steering_report.txt` or `steer_log.json` — timing data
- `test_summary.json` — overview metrics

## Key Questions This Answers

1. **Steering latency**: How fast does audio change after a new prompt?
2. **Transition smoothness**: Does Lyria fade between styles or hard-cut?
3. **BPM tracking**: Can we match running cadence in real-time?
4. **Parameter sensitivity**: Which params (density/brightness/guidance) have most audible impact?
5. **Stability**: Does the WebSocket stay connected for 90+ seconds of continuous steering?

## Mapping: Physiology → Lyria Parameters

| Physio Signal | Lyria Parameter | Mapping |
|---------------|----------------|---------|
| Running Cadence | `bpm` | Direct (160-180 SPM → BPM) |
| HR Energy (ΔHR) | `guidance` | Higher HR → stricter prompt following |
| HRV (RMSSD) | `density` | Low HRV → high density (tension) |
| Breath Rate | `brightness` | Fast breathing → brighter sound |
| HR + Section | `weighted_prompts` | Text descriptions of energy/mood |
