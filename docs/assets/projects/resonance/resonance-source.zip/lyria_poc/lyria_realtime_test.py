"""
Lyria RealTime Proof-of-Concept: Prompt Steering Latency Test

Tests how quickly Lyria RealTime responds to mid-stream prompt changes,
simulating physiological state transitions during a run.

Scenario simulated:
  - Start with calm warmup music
  - After 10s, shift to high-energy running music (simulating HR spike)
  - After 20s, shift BPM to match cadence change
  - After 30s, shift mood (simulating HRV drop = tension)
  - After 40s, return to calm (simulating recovery)

Each transition is logged with timestamps to measure steering latency.
"""

import asyncio
import base64
import json
import os
import sys
import time
import wave
import contextlib
from pathlib import Path
from dataclasses import dataclass, field

try:
    from websockets.asyncio.client import connect
except ImportError:
    print("ERROR: websockets not installed. Run: pip install websockets")
    sys.exit(1)


# --- Configuration ---

MODEL = "models/lyria-realtime-exp"
HOST = "generativelanguage.googleapis.com"
API_VERSION = "v1alpha"

SAMPLE_RATE = 48000
CHANNELS = 2
SAMPLE_WIDTH = 2  # 16-bit

# Total test duration in seconds
TEST_DURATION = 50

# How many seconds of audio per WAV file segment
SEGMENT_DURATION = 10


@dataclass
class SteeringEvent:
    """A scheduled prompt/config change."""
    time_sec: float
    prompts: list
    config: dict
    label: str
    sent_at: float = 0.0
    first_audio_after: float = 0.0


# --- Simulated physiological transitions ---

STEERING_TIMELINE = [
    SteeringEvent(
        time_sec=0,
        prompts=[
            {"text": "ambient", "weight": 1.0},
            {"text": "calm warmup", "weight": 0.8},
            {"text": "gentle electronic", "weight": 0.5},
        ],
        config={"music_generation_config": {"bpm": "100", "density": "0.2", "brightness": "0.4", "guidance": "3"}},
        label="WARMUP: calm ambient, BPM=100",
    ),
    SteeringEvent(
        time_sec=10,
        prompts=[
            {"text": "energetic running music", "weight": 1.0},
            {"text": "driving beat", "weight": 0.8},
            {"text": "electronic", "weight": 0.5},
        ],
        config={"music_generation_config": {"bpm": "140", "density": "0.6", "brightness": "0.6", "guidance": "4"}},
        label="HR SPIKE: energy up, BPM=140",
    ),
    SteeringEvent(
        time_sec=20,
        prompts=[
            {"text": "energetic running music", "weight": 1.0},
            {"text": "driving beat", "weight": 0.8},
            {"text": "electronic", "weight": 0.5},
        ],
        config={"music_generation_config": {"bpm": "168", "density": "0.7", "brightness": "0.7", "guidance": "5"}},
        label="CADENCE LOCK: BPM→168, density up",
    ),
    SteeringEvent(
        time_sec=30,
        prompts=[
            {"text": "dark intense", "weight": 1.0},
            {"text": "industrial", "weight": 0.7},
            {"text": "tense rhythmic", "weight": 0.6},
        ],
        config={"music_generation_config": {"bpm": "168", "density": "0.8", "brightness": "0.3", "guidance": "5"}},
        label="HRV DROP: tension, dark mood",
    ),
    SteeringEvent(
        time_sec=40,
        prompts=[
            {"text": "ambient recovery", "weight": 1.0},
            {"text": "spacious", "weight": 0.8},
            {"text": "gentle pad", "weight": 0.6},
        ],
        config={"music_generation_config": {"bpm": "110", "density": "0.2", "brightness": "0.5", "guidance": "3"}},
        label="RECOVERY: calm down, BPM=110",
    ),
]


@contextlib.contextmanager
def wave_file(filename, channels=CHANNELS, rate=SAMPLE_RATE, sample_width=SAMPLE_WIDTH):
    with wave.open(filename, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(rate)
        yield wf


class LyriaSteeringTest:
    def __init__(self, api_key: str, output_dir: str = "lyria_poc/output"):
        self.api_key = api_key
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.uri = (
            f"wss://{HOST}/ws/google.ai.generativelanguage.{API_VERSION}"
            f".GenerativeService.BidiGenerateMusic?key={self.api_key}"
        )

        self.ws = None
        self.start_time = 0.0
        self.total_bytes = 0
        self.chunk_count = 0
        self.events = list(STEERING_TIMELINE)
        self.log_entries = []
        self.running = True

    def elapsed(self) -> float:
        return time.time() - self.start_time

    def log(self, msg: str):
        t = self.elapsed()
        entry = f"[{t:6.2f}s] {msg}"
        self.log_entries.append(entry)
        print(entry)

    async def run(self):
        print(f"\n{'='*60}")
        print("  LYRIA REALTIME - PROMPT STEERING LATENCY TEST")
        print(f"{'='*60}")
        print(f"  Output dir: {self.output_dir.resolve()}")
        print(f"  Test duration: {TEST_DURATION}s")
        print(f"  Steering events: {len(self.events)}")
        print(f"{'='*60}\n")

        try:
            async with connect(self.uri, additional_headers={"Content-Type": "application/json"}) as ws:
                self.ws = ws
                await self.setup()
                self.start_time = time.time()

                # Run sender and receiver concurrently
                await asyncio.gather(
                    self.sender_loop(),
                    self.receiver_loop(),
                )
        except Exception as e:
            self.log(f"CONNECTION ERROR: {e}")
            raise
        finally:
            self.write_report()

    async def setup(self):
        print("Sending setup message...")
        await self.ws.send(json.dumps({
            "setup": {"model": MODEL}
        }))
        raw = await self.ws.recv(decode=False)
        response = json.loads(raw.decode("ascii"))
        print(f"Setup complete: {response}\n")

    async def sender_loop(self):
        """Send prompt/config changes at scheduled times."""
        pending_events = list(self.events)

        for event in pending_events:
            # Wait until it's time
            wait_time = event.time_sec - self.elapsed()
            if wait_time > 0:
                await asyncio.sleep(wait_time)

            if not self.running:
                break

            # Send prompts
            self.log(f"STEER → {event.label}")
            message = {
                "client_content": {
                    "weighted_prompts": event.prompts
                }
            }
            await self.ws.send(json.dumps(message))
            event.sent_at = time.time()

            # Send config
            await self.ws.send(json.dumps(event.config))

            # Send PLAY (needed after first prompt)
            if event.time_sec == 0:
                await self.ws.send(json.dumps({"playback_control": "PLAY"}))
                self.log("PLAY command sent")

        # Wait for remaining duration
        remaining = TEST_DURATION - self.elapsed()
        if remaining > 0:
            await asyncio.sleep(remaining)

        self.running = False
        self.log("Test duration complete, closing...")

    async def receiver_loop(self):
        """Receive audio chunks and write to segmented WAV files."""
        segment_idx = 0
        segment_bytes = 0
        bytes_per_segment = SAMPLE_RATE * CHANNELS * SAMPLE_WIDTH * SEGMENT_DURATION

        wav_path = self.output_dir / f"segment_{segment_idx:02d}.wav"
        wav = wave.open(str(wav_path), "wb")
        wav.setnchannels(CHANNELS)
        wav.setsampwidth(SAMPLE_WIDTH)
        wav.setframerate(SAMPLE_RATE)

        try:
            async for raw_response in self.ws:
                if not self.running:
                    break

                response = json.loads(raw_response.decode())
                server_content = response.get("serverContent")

                if server_content is None:
                    self.log(f"Non-audio message: {json.dumps(response)[:100]}")
                    continue

                audio_chunks = server_content.get("audioChunks")
                if audio_chunks is None:
                    continue

                recv_time = time.time()
                self.chunk_count += 1

                for chunk in audio_chunks:
                    pcm_data = base64.b64decode(chunk["data"])
                    self.total_bytes += len(pcm_data)
                    segment_bytes += len(pcm_data)
                    wav.writeframes(pcm_data)

                # Mark first audio after each steering event
                for event in self.events:
                    if event.sent_at > 0 and event.first_audio_after == 0.0:
                        event.first_audio_after = recv_time

                # Log progress every 50 chunks
                if self.chunk_count % 50 == 0:
                    duration_received = self.total_bytes / (SAMPLE_RATE * CHANNELS * SAMPLE_WIDTH)
                    self.log(f"  ...received {self.chunk_count} chunks, ~{duration_received:.1f}s audio")

                # Rotate WAV file at segment boundary
                if segment_bytes >= bytes_per_segment:
                    wav.close()
                    self.log(f"  Segment {segment_idx} saved: {wav_path.name}")
                    segment_idx += 1
                    segment_bytes = 0
                    wav_path = self.output_dir / f"segment_{segment_idx:02d}.wav"
                    wav = wave.open(str(wav_path), "wb")
                    wav.setnchannels(CHANNELS)
                    wav.setsampwidth(SAMPLE_WIDTH)
                    wav.setframerate(SAMPLE_RATE)

        except Exception as e:
            self.log(f"Receiver error: {e}")
        finally:
            wav.close()
            if segment_bytes > 0:
                self.log(f"  Final segment {segment_idx} saved: {wav_path.name}")

        # Also write the full combined WAV
        await self.combine_segments(segment_idx + 1)

    async def combine_segments(self, num_segments: int):
        """Combine all segment WAVs into one full recording."""
        combined_path = self.output_dir / "full_recording.wav"
        with wave_file(str(combined_path)) as combined:
            for i in range(num_segments):
                seg_path = self.output_dir / f"segment_{i:02d}.wav"
                if seg_path.exists():
                    with wave.open(str(seg_path), "rb") as seg:
                        combined.writeframes(seg.readframes(seg.getnframes()))
        self.log(f"Combined recording saved: {combined_path.name}")

    def write_report(self):
        """Write a latency report."""
        report_path = self.output_dir / "steering_report.txt"

        lines = [
            "=" * 60,
            "  LYRIA REALTIME STEERING LATENCY REPORT",
            "=" * 60,
            "",
            f"  Total chunks received: {self.chunk_count}",
            f"  Total audio bytes: {self.total_bytes:,}",
            f"  Total audio duration: {self.total_bytes / (SAMPLE_RATE * CHANNELS * SAMPLE_WIDTH):.1f}s",
            "",
            "-" * 60,
            "  STEERING EVENTS & LATENCY",
            "-" * 60,
            "",
        ]

        for event in self.events:
            lines.append(f"  [{event.time_sec:5.1f}s] {event.label}")
            if event.sent_at > 0 and event.first_audio_after > 0:
                latency = event.first_audio_after - event.sent_at
                lines.append(f"          First audio after steer: {latency*1000:.0f}ms")
            else:
                lines.append(f"          (no audio received after this event)")
            lines.append("")

        lines.extend([
            "-" * 60,
            "  FULL LOG",
            "-" * 60,
            "",
        ])
        lines.extend(self.log_entries)

        report = "\n".join(lines)
        report_path.write_text(report, encoding="utf-8")
        print(f"\n{report}")
        print(f"\nReport saved to: {report_path.resolve()}")


def get_api_key() -> str:
    """Get API key from environment or .env file."""
    key = os.environ.get("GOOGLE_API_KEY")
    if key:
        return key

    # Try .env file
    env_path = Path(__file__).parent.parent / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if line.startswith("GOOGLE_API_KEY="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")

    # Try lyria_poc/.env
    env_path = Path(__file__).parent / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if line.startswith("GOOGLE_API_KEY="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")

    print("ERROR: GOOGLE_API_KEY not found.")
    print("Set it via:")
    print("  1. Environment variable: export GOOGLE_API_KEY=your_key")
    print("  2. File: lyria_poc/.env with GOOGLE_API_KEY=your_key")
    sys.exit(1)


if __name__ == "__main__":
    api_key = get_api_key()
    test = LyriaSteeringTest(api_key)
    asyncio.run(test.run())
