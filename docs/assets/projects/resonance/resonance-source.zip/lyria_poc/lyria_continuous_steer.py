"""
Lyria RealTime Proof-of-Concept: Continuous Steering (Simulated Run)

Simulates a 90-second run where physiological metrics change every second,
continuously steering Lyria RealTime — exactly how the final integration would work.

This mimics polar_state2.py's output: every second it generates new prompts/config
based on simulated HR, cadence, HRV, and breathing changes.

Output:
  - WAV file of the generated music
  - JSON log of all steering commands with timestamps
  - Latency measurements between steer and audible change
"""

import asyncio
import base64
import json
import math
import os
import sys
import time
import wave
import contextlib
from pathlib import Path
from dataclasses import dataclass

try:
    from websockets.asyncio.client import connect
except ImportError:
    print("ERROR: websockets not installed. Run: pip install websockets")
    sys.exit(1)


MODEL = "models/lyria-realtime-exp"
HOST = "generativelanguage.googleapis.com"
API_VERSION = "v1alpha"

SAMPLE_RATE = 48000
CHANNELS = 2
SAMPLE_WIDTH = 2

# Simulated run duration
RUN_DURATION = 90  # seconds
STEER_INTERVAL = 3  # send new prompt every N seconds (avoid flooding)


@dataclass
class PhysioState:
    """Simulated physiological state (mimics polar_state2.State output)."""
    hr: int = 80
    hr_baseline: int = 72
    cadence: int = 0
    rmssd: float = 45.0
    rmssd_baseline: float = 40.0
    breath_rate: float = 14.0
    section: str = "intro"


def simulate_physio(t: float, duration: float) -> PhysioState:
    """
    Simulate realistic physiological changes during a run.

    Timeline:
      0-15s:   Warmup (HR rises slowly, no cadence)
      15-60s:  Running (HR high, cadence locked, HRV drops)
      60-75s:  Sprint (HR peaks, cadence up, HRV lowest)
      75-90s:  Recovery (everything returns toward baseline)
    """
    state = PhysioState()
    progress = t / duration

    if t < 15:
        # Warmup phase
        state.hr = 72 + int(t * 2)  # 72 → 102
        state.cadence = 0
        state.rmssd = 45 - t * 0.5  # slowly dropping
        state.breath_rate = 14 + t * 0.2
        state.section = "intro"
    elif t < 60:
        # Running phase
        run_t = t - 15
        state.hr = 140 + int(10 * math.sin(run_t / 10))  # oscillates 130-150
        state.cadence = 165 + int(5 * math.sin(run_t / 8))  # ~160-170
        state.rmssd = 25 + 5 * math.sin(run_t / 15)  # lower, oscillating
        state.breath_rate = 22 + 3 * math.sin(run_t / 12)
        state.section = "verse" if run_t < 25 else "chorus"
    elif t < 75:
        # Sprint phase
        sprint_t = t - 60
        state.hr = 165 + int(sprint_t * 0.5)  # climbing to 172+
        state.cadence = 180 + int(sprint_t * 0.3)  # fast
        state.rmssd = 18 - sprint_t * 0.2  # very low
        state.breath_rate = 28 + sprint_t * 0.3
        state.section = "chorus"
    else:
        # Recovery
        rec_t = t - 75
        state.hr = 170 - int(rec_t * 4)  # dropping fast
        state.cadence = 100 - int(rec_t * 5)  # slowing
        if state.cadence < 0:
            state.cadence = 0
        state.rmssd = 20 + rec_t * 2  # recovering
        state.breath_rate = 30 - rec_t * 1.5
        state.section = "outro"

    return state


def physio_to_lyria(state: PhysioState) -> tuple:
    """
    Convert physiological state to Lyria RealTime prompts + config.
    This is the core mapping that would live in the final integration.
    """
    # --- Weighted prompts based on state ---
    prompts = []

    # Base genre (always present)
    prompts.append({"text": "electronic instrumental", "weight": 0.5})

    # Energy from HR
    delta_hr = state.hr - state.hr_baseline
    if delta_hr > 50:
        prompts.append({"text": "intense powerful driving", "weight": 1.0})
    elif delta_hr > 30:
        prompts.append({"text": "energetic motivating", "weight": 1.0})
    elif delta_hr > 15:
        prompts.append({"text": "steady rhythmic groove", "weight": 0.8})
    else:
        prompts.append({"text": "calm ambient gentle", "weight": 0.8})

    # HRV texture
    hrv_ratio = state.rmssd / state.rmssd_baseline
    if hrv_ratio > 1.1:
        prompts.append({"text": "open flowing harmonic", "weight": 0.6})
    elif hrv_ratio < 0.6:
        prompts.append({"text": "tight percussive minimal", "weight": 0.7})
    else:
        prompts.append({"text": "balanced coherent", "weight": 0.4})

    # Section mood
    section_prompts = {
        "intro": {"text": "building anticipation", "weight": 0.5},
        "verse": {"text": "emerging groove rhythmic build", "weight": 0.6},
        "chorus": {"text": "peak energy euphoric", "weight": 0.8},
        "bridge": {"text": "tension contrast", "weight": 0.6},
        "outro": {"text": "resolution fading peaceful", "weight": 0.7},
    }
    prompts.append(section_prompts.get(state.section, section_prompts["verse"]))

    # --- Music generation config ---
    # BPM: use cadence if running, otherwise moderate
    bpm = str(state.cadence) if state.cadence > 100 else "100"

    # Density: maps from HRV (low HRV = high density/tension)
    density = max(0.1, min(0.9, 1.0 - (state.rmssd / 60.0)))

    # Brightness: maps from breath rate (fast breathing = brighter/more urgent)
    brightness = max(0.2, min(0.9, state.breath_rate / 35.0))

    # Guidance: higher when HR is high (follow prompts more strictly during intensity)
    guidance = max(2, min(6, int(delta_hr / 15) + 2))

    config = {
        "music_generation_config": {
            "bpm": bpm,
            "density": f"{density:.1f}",
            "brightness": f"{brightness:.1f}",
            "guidance": str(guidance),
        }
    }

    return prompts, config


class ContinuousSteerTest:
    def __init__(self, api_key: str, output_dir: str = "lyria_poc/output_continuous"):
        self.api_key = api_key
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.uri = (
            f"wss://{HOST}/ws/google.ai.generativelanguage.{API_VERSION}"
            f".GenerativeService.BidiGenerateMusic?key={self.api_key}"
        )

        self.ws = None
        self.start_time = 0.0
        self.total_bytes = 0
        self.chunk_count = 0
        self.running = True
        self.steer_log = []

    def elapsed(self) -> float:
        return time.time() - self.start_time

    def log(self, msg: str):
        print(f"[{self.elapsed():6.2f}s] {msg}")

    async def run(self):
        print(f"\n{'='*60}")
        print("  LYRIA REALTIME - CONTINUOUS STEERING TEST")
        print(f"  Simulating {RUN_DURATION}s run with physio-driven prompts")
        print(f"{'='*60}\n")

        try:
            async with connect(self.uri, additional_headers={"Content-Type": "application/json"}) as ws:
                self.ws = ws
                await self.setup()
                self.start_time = time.time()

                await asyncio.gather(
                    self.physio_sender(),
                    self.audio_receiver(),
                )
        except Exception as e:
            self.log(f"ERROR: {e}")
            raise
        finally:
            self.save_results()

    async def setup(self):
        await self.ws.send(json.dumps({"setup": {"model": MODEL}}))
        raw = await self.ws.recv(decode=False)
        response = json.loads(raw.decode("ascii"))
        print(f"Connected: {response}\n")

    async def physio_sender(self):
        """Every STEER_INTERVAL seconds, compute new physio state and steer Lyria."""
        first = True

        for t in range(0, RUN_DURATION, STEER_INTERVAL):
            wait = t - self.elapsed()
            if wait > 0:
                await asyncio.sleep(wait)

            if not self.running:
                break

            # Simulate physiological state at time t
            state = simulate_physio(t, RUN_DURATION)
            prompts, config = physio_to_lyria(state)

            # Send to Lyria
            msg = {"client_content": {"weighted_prompts": prompts}}
            await self.ws.send(json.dumps(msg))
            await self.ws.send(json.dumps(config))

            if first:
                await self.ws.send(json.dumps({"playback_control": "PLAY"}))
                first = False

            # Log
            self.log(
                f"STEER t={t:3d}s | HR={state.hr} cad={state.cadence} "
                f"HRV={state.rmssd:.0f} br={state.breath_rate:.0f} "
                f"sec={state.section} | BPM={config['music_generation_config']['bpm']}"
            )

            self.steer_log.append({
                "time_sec": t,
                "elapsed": self.elapsed(),
                "physio": {
                    "hr": state.hr,
                    "cadence": state.cadence,
                    "rmssd": state.rmssd,
                    "breath_rate": state.breath_rate,
                    "section": state.section,
                },
                "prompts": prompts,
                "config": config,
            })

        # Wait for final audio
        remaining = RUN_DURATION - self.elapsed()
        if remaining > 0:
            await asyncio.sleep(remaining)
        self.running = False

    async def audio_receiver(self):
        """Receive and save all audio chunks."""
        wav_path = self.output_dir / "continuous_run.wav"

        with wave.open(str(wav_path), "wb") as wav:
            wav.setnchannels(CHANNELS)
            wav.setsampwidth(SAMPLE_WIDTH)
            wav.setframerate(SAMPLE_RATE)

            async for raw_response in self.ws:
                if not self.running:
                    break

                response = json.loads(raw_response.decode())
                server_content = response.get("serverContent")
                if not server_content:
                    continue

                audio_chunks = server_content.get("audioChunks")
                if not audio_chunks:
                    continue

                self.chunk_count += 1
                for chunk in audio_chunks:
                    pcm_data = base64.b64decode(chunk["data"])
                    self.total_bytes += len(pcm_data)
                    wav.writeframes(pcm_data)

                if self.chunk_count % 100 == 0:
                    dur = self.total_bytes / (SAMPLE_RATE * CHANNELS * SAMPLE_WIDTH)
                    self.log(f"  Audio: {self.chunk_count} chunks, {dur:.1f}s received")

        self.log(f"Audio saved: {wav_path.name}")

    def save_results(self):
        """Save steering log and summary."""
        # Steering log JSON
        log_path = self.output_dir / "steer_log.json"
        log_path.write_text(json.dumps(self.steer_log, indent=2), encoding="utf-8")

        # Summary
        audio_duration = self.total_bytes / (SAMPLE_RATE * CHANNELS * SAMPLE_WIDTH)
        summary = {
            "test_config": {
                "run_duration_sec": RUN_DURATION,
                "steer_interval_sec": STEER_INTERVAL,
                "total_steers": len(self.steer_log),
            },
            "results": {
                "total_chunks": self.chunk_count,
                "total_audio_bytes": self.total_bytes,
                "audio_duration_sec": round(audio_duration, 1),
                "audio_vs_wall_clock": f"{audio_duration/RUN_DURATION*100:.0f}%",
            },
        }
        summary_path = self.output_dir / "test_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        print(f"\n{'='*60}")
        print(f"  TEST COMPLETE")
        print(f"  Audio duration: {audio_duration:.1f}s")
        print(f"  Chunks received: {self.chunk_count}")
        print(f"  Steering commands sent: {len(self.steer_log)}")
        print(f"  Files saved to: {self.output_dir.resolve()}")
        print(f"{'='*60}")


def get_api_key() -> str:
    key = os.environ.get("GOOGLE_API_KEY")
    if key:
        return key

    for env_path in [Path(__file__).parent / ".env", Path(__file__).parent.parent / ".env"]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("GOOGLE_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")

    print("ERROR: GOOGLE_API_KEY not found.")
    print("Set via: export GOOGLE_API_KEY=your_key  OR  lyria_poc/.env")
    sys.exit(1)


if __name__ == "__main__":
    api_key = get_api_key()
    test = ContinuousSteerTest(api_key)
    asyncio.run(test.run())
