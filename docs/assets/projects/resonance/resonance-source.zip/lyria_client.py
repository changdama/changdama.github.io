"""
Lyria RealTime WebSocket client for Resonance.

Manages the WebSocket connection to Google's Lyria RealTime API,
consuming physio-derived prompts from an asyncio.Queue and streaming
audio chunks back via SocketIO to the browser.
"""

import asyncio
import base64
import json
import time
import wave
from pathlib import Path

try:
    from websockets.asyncio.client import connect
    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False

MODEL = "models/lyria-realtime-exp"
HOST = "generativelanguage.googleapis.com"
API_VERSION = "v1alpha"

SAMPLE_RATE = 48000
CHANNELS = 2
SAMPLE_WIDTH = 2

KEEPALIVE_PROMPT = [{"text": "ambient pad texture, gentle sustained tone", "weight": 0.5}]
KEEPALIVE_CONFIG = {"music_generation_config": {"bpm": "100", "density": "0.10", "brightness": "0.30", "guidance": "2"}}

# Warm-up prompt: matches Intro style (no drums, low density) to avoid
# harsh transition when SteerController sends the real first prompt
WARMUP_PROMPT = [{"text": "ambient atmospheric pad, gentle swell, no drums, emerging texture", "weight": 1.0}]
WARMUP_CONFIG = {"music_generation_config": {"bpm": "120", "density": "0.15", "brightness": "0.40", "guidance": "3"}}


class LyriaClient:
    def __init__(self, api_key: str, socketio, steer_queue: asyncio.Queue, output_dir: str = "output", segment_idx: int = 0):
        self.api_key = api_key
        self.socketio = socketio
        self.steer_queue = steer_queue
        self.segment_idx = segment_idx
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.uri = (
            f"wss://{HOST}/ws/google.ai.generativelanguage.{API_VERSION}"
            f".GenerativeService.BidiGenerateMusic?key={self.api_key}"
        )

        self.ws = None
        self.connected = False
        self.stop_requested = False
        self.started_playing = False
        self.chunk_count = 0
        self.total_bytes = 0

        # Muted mode: receive audio but don't write WAV or emit to browser
        self.muted = False

        self.wav_file = None
        self.wav_path = None
        self.segment_wav_paths = []
        self._init_wav()

    def _init_wav(self):
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        self.wav_path = self.output_dir / f"session_{timestamp}_seg{self.segment_idx}.wav"
        self.wav_file = wave.open(str(self.wav_path), "wb")
        self.wav_file.setnchannels(CHANNELS)
        self.wav_file.setsampwidth(SAMPLE_WIDTH)
        self.wav_file.setframerate(SAMPLE_RATE)

    def mute(self):
        """Enter muted mode: keep connection alive but don't record or stream."""
        self.muted = True
        # Finalize current WAV segment
        if self.wav_file:
            self.wav_file.close()
            self.wav_file = None
            if self.wav_path and self.wav_path.exists() and self.wav_path.stat().st_size > 44:
                self.segment_wav_paths.append(str(self.wav_path))
                print(f"  [LYRIA] Segment {self.segment_idx} saved: {self.wav_path.name}")

    def unmute(self):
        """Exit muted mode: start new WAV segment and resume streaming."""
        self.segment_idx += 1
        self._init_wav()
        self.muted = False

    async def send_keepalive(self):
        """Send a minimal prompt to keep the WebSocket alive during rest."""
        if self.ws and self.connected:
            msg = {"client_content": {"weighted_prompts": KEEPALIVE_PROMPT}}
            await self.ws.send(json.dumps(msg))
            await self.ws.send(json.dumps(KEEPALIVE_CONFIG))

    def get_segment_wavs(self):
        """Return list of all completed segment WAV paths."""
        # Finalize current segment if still open
        if self.wav_file:
            self.wav_file.close()
            self.wav_file = None
            if self.wav_path and self.wav_path.exists() and self.wav_path.stat().st_size > 44:
                self.segment_wav_paths.append(str(self.wav_path))
        return self.segment_wav_paths

    async def run(self):
        if not WEBSOCKETS_AVAILABLE:
            print("  [LYRIA] websockets not installed, skipping")
            self.socketio.emit('lyria_status', {'status': 'error', 'message': 'websockets not installed'})
            return

        try:
            self.socketio.emit('lyria_status', {'status': 'connecting'})
            print(f"  [LYRIA] Connecting to {HOST}...")
            async with connect(self.uri, additional_headers={"Content-Type": "application/json"}, open_timeout=10, ping_interval=None) as ws:
                self.ws = ws
                print("  [LYRIA] WebSocket open, sending setup...")
                await self._setup()
                self.connected = True
                self.socketio.emit('lyria_status', {'status': 'streaming'})
                print("  [LYRIA] Connected and streaming")

                await asyncio.gather(
                    self._sender_loop(),
                    self._receiver_loop(),
                )
        except asyncio.CancelledError:
            pass
        except Exception as e:
            import traceback
            print(f"  [LYRIA] !! Connection error: {type(e).__name__}: {e}")
            traceback.print_exc()
            self.socketio.emit('lyria_status', {'status': 'disconnected', 'message': f"{type(e).__name__}: {e}"})
        finally:
            self.connected = False
            if self.wav_file:
                self.wav_file.close()
                self.wav_file = None
                if self.wav_path and self.wav_path.exists() and self.wav_path.stat().st_size > 44:
                    self.segment_wav_paths.append(str(self.wav_path))

    async def _setup(self):
        await self.ws.send(json.dumps({"setup": {"model": MODEL}}))
        raw = await self.ws.recv(decode=False)
        response = json.loads(raw.decode("ascii"))
        print(f"  [LYRIA] Setup: {response}")

        # Immediately send warm-up prompt + PLAY so audio generation starts
        # without waiting for the first steer_queue item (saves 3-5s silence)
        msg = {"client_content": {"weighted_prompts": WARMUP_PROMPT}}
        await self.ws.send(json.dumps(msg))
        await self.ws.send(json.dumps(WARMUP_CONFIG))
        await self.ws.send(json.dumps({"playback_control": "PLAY"}))
        self.started_playing = True
        print("  [LYRIA] Warm-up PLAY sent immediately")

    async def _sender_loop(self):
        while not self.stop_requested:
            try:
                item = await asyncio.wait_for(self.steer_queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue

            if item is None:
                break

            prompts = item.get('prompts', [])
            config = item.get('config', {})

            msg = {"client_content": {"weighted_prompts": prompts}}
            await self.ws.send(json.dumps(msg))

            if config:
                await self.ws.send(json.dumps(config))

            if not self.started_playing:
                await self.ws.send(json.dumps({"playback_control": "PLAY"}))
                self.started_playing = True
                print("  [LYRIA] PLAY sent")

    async def _receiver_loop(self):
        try:
            async for raw_response in self.ws:
                if self.stop_requested:
                    break

                response = json.loads(raw_response.decode())
                server_content = response.get("serverContent")
                if not server_content:
                    continue

                audio_chunks = server_content.get("audioChunks")
                if not audio_chunks:
                    continue

                self.chunk_count += 1

                # In muted mode: receive but discard (keeps connection alive)
                if self.muted:
                    continue

                for chunk in audio_chunks:
                    pcm_data = base64.b64decode(chunk["data"])
                    self.total_bytes += len(pcm_data)

                    if self.wav_file:
                        self.wav_file.writeframes(pcm_data)

                    self.socketio.emit('lyria_audio_chunk', {
                        'pcm': chunk["data"],
                        'seq': self.chunk_count,
                        'bytes': len(pcm_data),
                    })

        except asyncio.CancelledError:
            pass
        except Exception as e:
            if not self.stop_requested:
                print(f"  [LYRIA] Receiver error: {e}")

    def save_wav(self) -> str:
        """Return the path to the last saved WAV file, or None."""
        if self.wav_file:
            self.wav_file.close()
            self.wav_file = None
        if self.wav_path and self.wav_path.exists() and self.wav_path.stat().st_size > 44:
            return str(self.wav_path)
        return None

    async def stop(self):
        self.stop_requested = True
        try:
            self.steer_queue.put_nowait(None)
        except asyncio.QueueFull:
            pass
