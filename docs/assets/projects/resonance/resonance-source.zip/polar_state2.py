"""
Polar H10 · Event Engine v1
============================

架构：用户手动选择歌曲段落，生理信号映射为 Prompt Tags

流程:
  CALIBRATION (30s)  → 建立 HR/ACC 基线
  RUNNING            → 用户选段落 + Polar 修饰 Prompt

信号分工:
  HR / ΔHR        → 段落内能量 Prompt
  HR Trend (10s)  → 建立/稳定/释放 Prompt
  ACC Cadence     → BPM Anchor Prompt + Creative Event
  HRV (RMSSD)    → 质感 Prompt（仅可靠时）
  Breathing (RSA) → 旋律/空间 Prompt + Motif Creative Event

依赖:
    pip install bleak numpy
"""

import asyncio
import time
import sys
import numpy as np
from enum import Enum
from collections import deque
from bleak import BleakClient, BleakScanner

# === BLE UUIDs ===
HR_CHAR_UUID = "00002a37-0000-1000-8000-00805f9b34fb"
PMD_CONTROL  = "FB005C81-02E7-F387-1CAD-8ACD2D8DF0C8"
PMD_DATA     = "FB005C82-02E7-F387-1CAD-8ACD2D8DF0C8"

ACC_START_CMD = bytearray([
    0x02, 0x02,
    0x00, 0x01, 0xC8, 0x00,
    0x01, 0x01, 0x10, 0x00,
    0x02, 0x01, 0x08, 0x00,
])

ACC_SAMPLE_RATE = 200


# === Enums ===

class Phase(Enum):
    CALIBRATION = "calibration"
    RUNNING = "running"


class Section(Enum):
    INTRO = "intro"
    VERSE = "verse"
    CHORUS = "chorus"
    BRIDGE = "bridge"
    OUTRO = "outro"


SECTION_PROMPTS = {
    Section.INTRO:  "intro section with a soft opening and sparse instrumentation, gradual layering",
    Section.VERSE:  "verse section with emerging groove, rhythmic build, motif introduction",
    Section.CHORUS: "chorus section with a strong recurring theme, steady running groove, fuller layers",
    Section.BRIDGE: "bridge section with controlled tension, contrasting texture, dramatic transition",
    Section.OUTRO:  "outro section with gentle release, reduced percussion, spacious fade-out",
}


# === HR Prompt Mapping ===

def hr_to_prompt_tags(delta_hr):
    """Map ΔHR (current - baseline) to energy prompt tags."""
    if delta_hr is None:
        return []
    if delta_hr < 15:
        return ["light energy", "comfortable pacing", "soft rhythmic pulse"]
    elif delta_hr < 35:
        return ["steady motivating energy", "balanced rhythmic drive"]
    elif delta_hr < 50:
        return ["strong but controlled energy", "focused forward motion"]
    else:
        return ["regulated intensity", "grounded pulse", "reduced stimulation", "avoid aggressive escalation"]


def hr_trend_to_prompt_tags(trend):
    """Map HR trend (bpm change over last 10s) to momentum prompt tags."""
    if trend is None:
        return []
    if trend > 8:
        return ["building momentum", "controlled rhythmic rise"]
    elif trend < -4:
        return ["gradual release", "softer rhythmic motion", "easing transition"]
    else:
        return ["consistent groove", "sustained rhythmic balance"]


# === Cadence Prompt Mapping ===

def cadence_to_prompt_tags(cadence, cadence_locked):
    """Map step cadence to rhythm prompt tags."""
    if cadence is None:
        return []
    if cadence_locked:
        return [f"rhythmic pulse anchored to {cadence:.0f} steps per minute",
                "consistent percussion synchronized with stable running cadence"]
    else:
        return [f"approximate running cadence around {cadence:.0f} steps per minute"]


# === HRV Texture Prompt Mapping ===

def hrv_to_prompt_tags(rmssd, baseline_rmssd, section, hr_high):
    """Map HRV to texture prompt tags. Only when data is reliable."""
    if rmssd is None or baseline_rmssd is None:
        return []
    ratio = rmssd / (baseline_rmssd + 1e-6)
    if section in (Section.OUTRO, Section.INTRO) and ratio > 1.1:
        return ["open flowing harmonic texture", "spacious ambience"]
    elif hr_high and ratio < 0.7:
        return ["grounded restrained texture", "controlled tension", "reduced density"]
    elif 0.8 <= ratio <= 1.2:
        return ["balanced coherent texture", "stable tonal atmosphere"]
    return []


# === Breathing Rate Estimation (RSA) ===

def estimate_breathing_rate(rr_buffer):
    """Estimate breathing rate from RR intervals via Respiratory Sinus Arrhythmia.

    RSA: breathing modulates HR — inhale shortens RR, exhale lengthens RR.
    We interpolate RR to uniform time series, then find dominant frequency
    in the 0.15-0.5 Hz band (9-30 breaths/min) via FFT.

    Returns (breath_rate, confidence) or (None, None).
    confidence: 'good' if peak is strong, 'weak' if marginal.
    """
    now = time.time()
    cutoff = now - 60.0
    recent = [(t, rr) for t, rr in rr_buffer if t >= cutoff]

    if len(recent) < 30:
        return None, "insufficient_rr"

    timestamps = np.array([t for t, _ in recent])
    rr_values = np.array([rr for _, rr in recent])

    # Check if RR variability is sufficient for RSA detection
    rr_std = np.std(rr_values)
    if rr_std < 8.0:
        # RR variability too low (<8ms SD), RSA signal undetectable
        return None, f"low_variability(SD={rr_std:.1f}ms)"

    # Interpolate to uniform 4 Hz time series
    fs = 4.0
    t_start = timestamps[0]
    t_end = timestamps[-1]
    duration = t_end - t_start
    if duration < 20.0:
        return None, "duration_short"

    t_uniform = np.arange(t_start, t_end, 1.0 / fs)
    if len(t_uniform) < 80:
        return None, "samples_short"

    rr_interp = np.interp(t_uniform, timestamps, rr_values)

    # Remove DC and detrend
    rr_interp = rr_interp - np.mean(rr_interp)
    x = np.arange(len(rr_interp))
    slope = np.polyfit(x, rr_interp, 1)[0]
    rr_interp = rr_interp - slope * x

    # Apply Hann window
    window = np.hanning(len(rr_interp))
    rr_windowed = rr_interp * window

    # FFT
    n = len(rr_windowed)
    fft_vals = np.abs(np.fft.rfft(rr_windowed))
    freqs = np.fft.rfftfreq(n, d=1.0/fs)

    # Search in respiratory band: 0.15 - 0.5 Hz (9 - 30 breaths/min)
    # Lower bound raised from 0.1 to 0.15 to avoid picking up noise at band edge
    mask = (freqs >= 0.15) & (freqs <= 0.5)
    if not np.any(mask):
        return None, "no_band"

    band_fft = fft_vals[mask]
    band_freqs = freqs[mask]

    peak_idx = np.argmax(band_fft)
    peak_power = band_fft[peak_idx]
    band_mean = np.mean(band_fft)

    # Require strong peak: at least 3x band mean for good confidence
    ratio = peak_power / (band_mean + 1e-10)
    if ratio < 2.5:
        return None, f"weak_peak(ratio={ratio:.1f})"

    breath_freq = band_freqs[peak_idx]
    breath_rate = breath_freq * 60.0  # breaths per minute

    confidence = "good" if ratio > 4.0 else "weak"
    return breath_rate, confidence


def detect_breath_hold(rr_buffer):
    """Detect breath-holding via short-window RR variability drop.

    Breath-holding eliminates RSA, causing RR intervals to become very stable.
    We check a 10s window: if SD(RR) drops below 5ms while having enough samples,
    it's likely a breath hold.

    Returns: True if breath-hold detected, False otherwise.
    """
    now = time.time()
    recent = [(t, rr) for t, rr in rr_buffer if now - t <= 10.0]

    if len(recent) < 8:
        return False

    rr_vals = np.array([rr for _, rr in recent])
    rr_sd = np.std(rr_vals)

    # Breath-holding: RR becomes extremely stable (SD < 5ms)
    # Normal breathing produces SD of 15-60ms via RSA
    if rr_sd < 5.0:
        if state.breath_hold_start is None:
            state.breath_hold_start = now
        hold_duration = now - state.breath_hold_start
        if hold_duration >= 5.0:  # sustained for 5s
            state.breath_hold_detected = True
            return True
    else:
        state.breath_hold_start = None
        state.breath_hold_detected = False

    return False


def detect_deep_breath_realtime(rr_buffer):
    """Detect intentional deep breathing via short-window RR amplitude.

    Deep breathing produces large RR swings (strong RSA). We compare
    the peak-to-peak RR range in a 15s window vs. a 60s baseline.
    If current amplitude > 2x baseline amplitude, it's deep breathing.

    Returns: True if deep breathing detected, False otherwise.
    """
    now = time.time()

    # Short window (15s) - current breathing effect
    short_rr = [rr for t, rr in rr_buffer if now - t <= 15.0]
    if len(short_rr) < 10:
        return False

    # Long window (60s) - baseline breathing amplitude
    long_rr = [rr for t, rr in rr_buffer if now - t <= 60.0]
    if len(long_rr) < 20:
        return False

    short_range = float(np.max(short_rr) - np.min(short_rr))
    long_sd = float(np.std(long_rr))

    # Deep breathing: short-window amplitude significantly exceeds baseline
    if long_sd < 5.0:
        return False  # not enough baseline variability to compare

    short_sd = float(np.std(short_rr))
    ratio = short_sd / (long_sd + 1e-6)

    # If short-window variability is 1.8x+ the baseline, likely deep breathing
    if ratio > 1.8 and short_range > 40.0:
        state.deep_breath_realtime = True
        return True

    state.deep_breath_realtime = False
    return False


def detect_deep_breathing():
    """Detect intentional deep breathing pattern.

    Triggers only when breath rate drops SIGNIFICANTLY below the user's
    recent average — not just below an absolute threshold. This prevents
    false triggers when the user's normal resting rate is naturally slow.

    Requirements for trigger:
    1. Breath confidence must be 'good' (not 'weak')
    2. Current rate must be < 8 bpm AND at least 40% below recent average
    3. Must sustain for 3 consecutive detections (~15s)
    """
    now = time.time()

    if state.breath_rate is None:
        state.deep_breath_count = 0
        state.deep_breath_start = None
        return False

    # Only trust 'good' confidence readings for motif detection
    if state.breath_confidence != "good":
        return False

    # Compute recent average breath rate (from history)
    if len(state.breath_history) < 3:
        return False
    recent_avg = float(np.mean(list(state.breath_history)[-6:]))

    # Deep breathing = rate below 8 AND significantly lower than personal average
    is_deep = (state.breath_rate < 8.0) or \
              (state.breath_rate < recent_avg * 0.6 and state.breath_rate < 10.0)

    if is_deep:
        if state.deep_breath_start is None:
            state.deep_breath_start = now
        state.deep_breath_count += 1
    else:
        if state.deep_breath_count < 3:
            state.deep_breath_count = 0
            state.deep_breath_start = None

    # Trigger motif after 3 consecutive detections
    if state.deep_breath_count >= 3 and not state.motif_marker_triggered:
        if now - state.last_motif_time > 60.0:  # 60s cooldown
            state.motif_marker_triggered = True
            state.last_motif_time = now
            state.deep_breath_count = 0
            state.deep_breath_start = None
            state.creative_events.append({
                "type": "motif_marker",
                "trigger": "deep_breathing",
                "breath_rate": round(state.breath_rate, 1),
                "avg_breath_rate": round(recent_avg, 1),
                "section": state.section.value if state.section else "unknown",
                "timestamp": now - state.session_start,
            })
            return True

    # Reset trigger flag when breath goes back above average
    if state.breath_rate >= recent_avg * 0.8:
        state.motif_marker_triggered = False

    return False


# === Breathing Prompt Mapping ===

def breathing_to_prompt_tags(breath_rate, deep_breath_event, hr_high):
    """Map breathing rate and events to music prompt tags."""
    tags = []

    # Breath-hold → dramatic suspension
    if state.breath_hold_detected:
        tags = [
            "suspended tension", "held breath moment",
            "stripped-back texture", "anticipatory pause"
        ]
        return tags

    # Real-time deep breathing (short-window detection) → spacious tags
    if state.deep_breath_realtime and not deep_breath_event:
        tags = ["expanding spacious phrasing", "deep resonant tones", "slow wave-like motion"]
        return tags

    # Deep breathing event → motif marker (strongest)
    if deep_breath_event:
        tags = [
            "breathing-inspired recurring melodic motif",
            "long flowing phrases with expanded reverb",
            "prominent theme marked for later return"
        ]
        return tags

    if breath_rate is None:
        return []

    # Slow controlled breathing (< 12 bpm)
    if breath_rate < 12:
        tags = ["smooth phrasing", "gentle cyclical motion", "spacious resonance"]
    # Normal breathing (12-20 bpm)
    elif breath_rate <= 20:
        tags = ["natural rhythmic flow"]
    # Rapid breathing during high intensity (> 20 bpm)
    elif breath_rate > 25 and hr_high:
        tags = ["restrained texture", "slower harmonic movement", "reduced rhythmic density"]
    # Moderately elevated breathing
    elif breath_rate > 20:
        tags = ["forward-moving phrasing"]

    return tags


# === State ===

class State:
    def __init__(self):
        self.phase = Phase.CALIBRATION
        self.section = None
        self.session_start = 0.0
        self.calibration_start = 0.0

        # User preferences
        self.style = "electronic"
        self.mood = "uplifting"
        self.duration_min = 5

        # HR
        self.hr = None
        self.hr_baseline = None
        self.hr_history = deque(maxlen=60)  # (timestamp, hr) last 60 entries
        self.hr_calibration = []

        # RR / HRV
        self.rr_buffer = deque(maxlen=120)  # (timestamp, rr_ms) ~90s of data for breathing FFT
        self.rr_calibration = []
        self.baseline_rmssd = None
        self.last_valid_rr = None
        self.artifact_count = 0

        # ACC / Cadence
        self.acc_mag_buffer = deque(maxlen=1000)  # 5s at 200Hz
        self.acc_warmup_samples = []  # collected during calibration sec 10-30
        self.acc_collection_started = False
        self.acc_baseline = None  # RMS of stationary ACC magnitude
        self.cadence = None
        self.cadence_history = deque(maxlen=15)  # last 15 cadence estimates
        self.cadence_locked = False
        self.cadence_lock_start = None
        self.bpm_anchor = None

        # Breathing (RSA estimation)
        self.breath_rate = None  # breaths per minute
        self.breath_confidence = None  # 'good' or 'weak'
        self.breath_status = None  # reason if estimation fails
        self.breath_history = deque(maxlen=30)  # last 30 estimates
        self.deep_breath_count = 0
        self.deep_breath_start = None
        self.motif_marker_triggered = False
        self.last_motif_time = 0.0
        # Short-window breathing detection (complementary to FFT)
        self.breath_hold_detected = False
        self.breath_hold_start = None
        self.deep_breath_realtime = False  # real-time deep breath via RR amplitude

        # Creative events log
        self.creative_events = []
        self.section_log = []  # (timestamp, section)

        # Tap detection
        self.last_tap_time = 0.0
        self.tap_history = deque(maxlen=30)

        # Connection health
        self.last_hr_time = 0.0
        self.last_acc_time = 0.0

        # Output
        self.latest_output = None

        # Prompt timeline for music generation
        self.prompt_log = []  # [(elapsed_sec, section, prompt_text, prompt_tags)]
        self._last_prompt_text = None

        # Goal tracking
        self.max_goals = 0
        self.goals_completed = 0
        self.goal_triggered = False
        self.segment_wavs = []


state = State()


# === Parsing (reused from polar_state.py) ===

def parse_hr_data(data: bytearray):
    flags = data[0]
    hr_16bit = flags & 0x01
    rr_present = (flags & 0x10) >> 4
    offset = 1
    if hr_16bit:
        hr = int.from_bytes(data[offset:offset+2], "little")
        offset += 2
    else:
        hr = data[offset]
        offset += 1
    rr_intervals = []
    if rr_present:
        while offset < len(data):
            rr_raw = int.from_bytes(data[offset:offset+2], "little")
            rr_ms = rr_raw * 1000 / 1024
            rr_intervals.append(rr_ms)
            offset += 2
    return hr, rr_intervals


def parse_acc_data(data: bytearray):
    if len(data) < 10 or data[0] != 0x02:
        return []
    samples = []
    offset = 10
    while offset + 6 <= len(data):
        ax = int.from_bytes(data[offset:offset+2], "little", signed=True)
        ay = int.from_bytes(data[offset+2:offset+4], "little", signed=True)
        az = int.from_bytes(data[offset+4:offset+6], "little", signed=True)
        samples.append((ax/1000.0, ay/1000.0, az/1000.0))
        offset += 6
    return samples


def filter_rr(rr, last_valid):
    if rr < 300 or rr > 2000:
        return False
    if last_valid is not None:
        if abs(rr - last_valid) / last_valid > 0.25:
            return False
    return True


# === Cadence Detection ===

def estimate_cadence(mag_buffer):
    """Estimate step cadence from ACC magnitude using autocorrelation.

    Running produces periodic vertical acceleration. We look for the
    dominant period between 0.25s and 0.6s (100-240 steps/min).
    Only reports cadence when ACC energy is significantly above the
    stationary baseline (i.e., actually moving).
    """
    if len(mag_buffer) < 600:  # need at least 3s
        return None

    signal = np.array(list(mag_buffer))[-800:]  # use last 4s

    # Gate: require ACC energy significantly above stationary baseline
    if state.acc_baseline is not None:
        current_rms = float(np.sqrt(np.mean(signal ** 2)))
        ratio = current_rms / (state.acc_baseline + 1e-6)
        if ratio < 3.0:  # less than 3x baseline = not running
            return None

    signal = signal - np.mean(signal)

    # Autocorrelation
    n = len(signal)
    corr = np.correlate(signal, signal, mode='full')
    corr = corr[n-1:]  # positive lags only
    corr = corr / (corr[0] + 1e-10)

    # Search for peak between 0.25s and 0.6s lag (100-240 spm)
    min_lag = int(0.25 * ACC_SAMPLE_RATE)  # 50 samples
    max_lag = int(0.60 * ACC_SAMPLE_RATE)  # 120 samples

    if max_lag >= len(corr):
        return None

    search = corr[min_lag:max_lag+1]
    if len(search) == 0:
        return None

    peak_idx = np.argmax(search)
    peak_val = search[peak_idx]

    if peak_val < 0.3:  # too weak, probably not running
        return None

    period_samples = min_lag + peak_idx
    period_sec = period_samples / ACC_SAMPLE_RATE
    cadence_spm = 60.0 / period_sec

    if cadence_spm < 100 or cadence_spm > 240:
        return None

    return cadence_spm


def update_cadence_lock():
    """Check if cadence has been stable for 10+ seconds."""
    if len(state.cadence_history) < 10:
        state.cadence_locked = False
        return

    recent = list(state.cadence_history)[-10:]
    values = [c for c in recent if c is not None]
    if len(values) < 8:
        state.cadence_locked = False
        state.cadence_lock_start = None
        return

    arr = np.array(values)
    cv = np.std(arr) / (np.mean(arr) + 1e-6)

    if cv < 0.05:  # less than 5% variation = stable
        if not state.cadence_locked:
            state.cadence_locked = True
            state.cadence_lock_start = time.time()
            state.bpm_anchor = float(np.median(arr))
            state.creative_events.append({
                "type": "bpm_anchor",
                "value": round(state.bpm_anchor),
                "section": state.section.value if state.section else "unknown",
                "timestamp": time.time() - state.session_start,
            })
    else:
        state.cadence_locked = False
        state.cadence_lock_start = None


# === HRV Computation ===

def compute_rmssd(rr_list):
    if len(rr_list) < 5:
        return None
    diffs = np.diff(np.array(rr_list))
    return float(np.sqrt(np.mean(diffs ** 2)))


def compute_realtime_rmssd():
    now = time.time()
    cutoff = now - 30.0
    valid = [(t, rr) for t, rr in state.rr_buffer if t >= cutoff]
    if len(valid) < 10:
        return None
    return compute_rmssd([rr for _, rr in valid])


# === HR Trend ===

def compute_hr_trend():
    """Compute HR change over last 10 seconds."""
    now = time.time()
    recent = [(t, hr) for t, hr in state.hr_history if now - t <= 10]
    if len(recent) < 3:
        return None
    oldest_hr = recent[0][1]
    newest_hr = recent[-1][1]
    return newest_hr - oldest_hr


# === Prompt Builder ===

def build_prompt_output():
    """Combine all layers into final prompt tags and structured output."""
    if state.section is None:
        return None

    now = time.time()

    # Layer 1: Preference
    preference = f"instrumental {state.mood} {state.style} running music, immersive and rhythmic, no vocals"

    # Layer 2: Section
    section_prompt = SECTION_PROMPTS[state.section]

    # Layer 3: HR energy
    delta_hr = None
    if state.hr is not None and state.hr_baseline is not None:
        delta_hr = state.hr - state.hr_baseline
    hr_tags = hr_to_prompt_tags(delta_hr)

    # Layer 4: HR trend
    trend = compute_hr_trend()
    trend_tags = hr_trend_to_prompt_tags(trend)

    # Layer 5: Cadence
    cadence_tags = cadence_to_prompt_tags(state.cadence, state.cadence_locked)

    # Layer 6: HRV texture
    rmssd = compute_realtime_rmssd()
    hr_high = (delta_hr is not None and delta_hr > 40)
    hrv_tags = hrv_to_prompt_tags(rmssd, state.baseline_rmssd, state.section, hr_high)

    # Layer 7: Breathing
    deep_breath_event = detect_deep_breathing()
    breath_tags = breathing_to_prompt_tags(state.breath_rate, deep_breath_event, hr_high)

    # Combine all prompt tags
    all_tags = [section_prompt] + hr_tags + trend_tags + cadence_tags + hrv_tags + breath_tags
    constraint = "seamless loopable section, no vocals"

    output = {
        "timestamp": now - state.session_start,
        "phase": state.phase.value,
        "selected_section": state.section.value,
        "physiology": {
            "hr": state.hr,
            "hr_baseline": state.hr_baseline,
            "delta_hr": round(delta_hr, 1) if delta_hr is not None else None,
            "hr_trend_10s": round(trend, 1) if trend is not None else None,
            "cadence": round(state.cadence, 0) if state.cadence is not None else None,
            "cadence_locked": state.cadence_locked,
            "bpm_anchor": round(state.bpm_anchor) if state.bpm_anchor else None,
            "rmssd": round(rmssd, 1) if rmssd is not None else None,
            "rmssd_baseline": round(state.baseline_rmssd, 1) if state.baseline_rmssd is not None else None,
            "breath_rate": round(state.breath_rate, 1) if state.breath_rate is not None else None,
            "breath_confidence": state.breath_confidence,
        },
        "prompt": {
            "preference": preference,
            "section": section_prompt,
            "hr_tags": hr_tags,
            "trend_tags": trend_tags,
            "cadence_tags": cadence_tags,
            "hrv_tags": hrv_tags,
            "breath_tags": breath_tags,
            "constraint": constraint,
        },
        "prompt_tags": all_tags,
        "full_prompt": f"{preference}, {', '.join(all_tags)}, {constraint}",
        "creative_events": state.creative_events[-5:],
    }

    state.latest_output = output
    return output


# === BLE Callbacks ===

def hr_callback(_, data):
    state.last_hr_time = time.time()
    hr, rrs = parse_hr_data(data)
    state.hr = hr
    state.hr_history.append((time.time(), hr))

    if state.phase == Phase.CALIBRATION:
        state.hr_calibration.append(hr)

    for rr in rrs:
        if not filter_rr(rr, state.last_valid_rr):
            state.artifact_count += 1
            continue
        state.last_valid_rr = rr

        if state.phase == Phase.CALIBRATION:
            state.rr_calibration.append(rr)
        else:
            state.rr_buffer.append((time.time(), rr))


_acc_callback_count = 0
_acc_parse_fail_count = 0

def acc_callback(_, data):
    global _acc_callback_count, _acc_parse_fail_count
    _acc_callback_count += 1
    state.last_acc_time = time.time()
    samples = parse_acc_data(data)
    if not samples:
        _acc_parse_fail_count += 1
        return
    for ax, ay, az in samples:
        mag = np.sqrt(ax*ax + ay*ay + az*az) - 1.0
        state.acc_mag_buffer.append(abs(mag))
        if state.acc_collection_started and state.acc_baseline is None:
            state.acc_warmup_samples.append(abs(mag))


# === Calibration ===

def try_finish_calibration():
    if len(state.hr_calibration) < 20:
        return False, "HR 数据不足"
    state.hr_baseline = float(np.median(state.hr_calibration))
    if len(state.rr_calibration) >= 10:
        state.baseline_rmssd = compute_rmssd(state.rr_calibration)
    return True, "success"


# === Input Handling ===

def section_from_key(key):
    mapping = {
        '1': Section.INTRO,
        '2': Section.VERSE,
        '3': Section.CHORUS,
        '4': Section.BRIDGE,
        '5': Section.OUTRO,
    }
    return mapping.get(key)


SECTION_LABELS = {
    Section.INTRO:  "热身 Intro",
    Section.VERSE:  "加速 Verse",
    Section.CHORUS: "主训 Chorus",
    Section.BRIDGE: "高强度 Bridge",
    Section.OUTRO:  "放松 Outro",
}


# === Main Loop ===

async def main():
    print()
    print("  ╔══════════════════════════════════════════════════════════════════╗")
    print("  ║       共振 Resonance · Event Engine v1                         ║")
    print("  ║       Physiology → Prompt Tags → Music Control                 ║")
    print("  ╚══════════════════════════════════════════════════════════════════╝")
    print()

    # User preference (hardcoded for now, would be web UI)
    state.style = "electronic"
    state.mood = "uplifting"
    state.duration_min = 5
    print(f"  音乐设定: {state.mood} {state.style} · {state.duration_min} min")
    print()

    # Connect to Polar H10
    print("  扫描 Polar H10...")
    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    if not device:
        print("  没找到 Polar H10")
        return

    print(f"  找到: {device.name} ({device.address})")
    print("  连接中...")
    print()

    async with BleakClient(device) as client:
        await client.start_notify(HR_CHAR_UUID, hr_callback)
        print("  HR 流已启动")

        try:
            await client.write_gatt_char(PMD_CONTROL, ACC_START_CMD, response=True)
            await client.start_notify(PMD_DATA, acc_callback)
            print("  ACC 流已启动 (200Hz)")
        except Exception as e:
            print(f"  ACC 启动失败: {e}")

        state.session_start = time.time()
        state.calibration_start = time.time()

        # === CALIBRATION ===
        print()
        print("  ── 校准阶段 (30s) ────────────────────────────────────────────")
        print("  请保持安静，正在建立身体基线...")
        print()

        sec = 0
        while True:
            await asyncio.sleep(1)
            sec += 1
            elapsed = time.time() - state.calibration_start

            # Start ACC collection after 15s (sensor stabilization, same as polar_state.py)
            if not state.acc_collection_started:
                if elapsed >= 15.0:
                    state.acc_collection_started = True
                    print("  ACC 采集开始 (sec 15-30 建立静止基线)...")

            # Build ACC baseline at 30s using all warmup samples
            if state.acc_baseline is None and elapsed >= 30.0 and state.acc_warmup_samples:
                arr = np.array(state.acc_warmup_samples)
                state.acc_baseline = float(np.sqrt(np.mean(arr ** 2)))
                print(f"  ACC 基线 = {state.acc_baseline:.4f} g ({len(arr)} samples)")

            if elapsed >= 30:
                # Block if ACC baseline not ready (same behavior as polar_state.py)
                if state.acc_baseline is None:
                    if elapsed < 45:
                        print(f"  [{sec:2d}s] ⚠ ACC 基线尚未就绪 (cb:{_acc_callback_count},fail:{_acc_parse_fail_count}), 继续等待...")
                        continue
                    else:
                        print(f"  ⚠ ACC 超时, 跳过 ACC 基线")

                success, msg = try_finish_calibration()
                if success:
                    break
                elif elapsed >= 45:
                    print(f"  ⚠ 校准超时: {msg}")
                    if state.hr_calibration:
                        state.hr_baseline = float(np.median(state.hr_calibration))
                    else:
                        state.hr_baseline = 75
                    break

            # Display
            hr_str = f"{state.hr}" if state.hr else "---"
            rr_count = len(state.rr_calibration)
            if state.acc_baseline:
                acc_str = "ACC:ready"
            elif state.acc_collection_started:
                acc_str = f"collecting({len(state.acc_warmup_samples)}) cb:{_acc_callback_count} fail:{_acc_parse_fail_count}"
            else:
                acc_str = f"waiting(15s) cb:{_acc_callback_count}"
            print(f"  [{sec:2d}s] HR: {hr_str:>3} | RR 采集: {rr_count} | {acc_str} | 等待 {max(0, 30 - int(elapsed))}s...")

        # Calibration complete
        rmssd_str = f"{state.baseline_rmssd:.1f} ms" if state.baseline_rmssd else "N/A"
        acc_str = f"{state.acc_baseline:.4f} g" if state.acc_baseline else "N/A"
        print()
        print("  ┌─ 校准完成 ─────────────────────────────────────────────────┐")
        print(f"  │  HR Baseline = {state.hr_baseline:.0f} bpm                              │")
        print(f"  │  RMSSD 基线  = {rmssd_str:<20}                   │")
        print(f"  │  ACC 基线    = {acc_str:<20}                   │")
        print("  └────────────────────────────────────────────────────────────┘")
        print()

        # === RUNNING PHASE ===
        state.phase = Phase.RUNNING
        print("  ── 运动阶段 ──────────────────────────────────────────────────")
        print("  选择运动阶段 (按数字键切换):")
        print()
        print("    [1] 热身 Intro     [2] 加速 Verse     [3] 主训 Chorus")
        print("    [4] 高强度 Bridge  [5] 放松 Outro     [Q] 结束")
        print()
        print("  提示: 步频稳定 10s → 自动写入 BPM Anchor")
        print()

        # Start with Intro
        state.section = Section.INTRO
        state.section_log.append((time.time() - state.session_start, Section.INTRO))
        print(f"  ▶ 当前段落: 热身 Intro")
        print()

        # Setup non-blocking input
        input_queue = asyncio.Queue()

        async def read_input():
            loop = asyncio.get_event_loop()
            while True:
                line = await loop.run_in_executor(None, sys.stdin.readline)
                line = line.strip().lower()
                if line:
                    await input_queue.put(line)

        input_task = asyncio.create_task(read_input())

        running_sec = 0
        try:
            while True:
                await asyncio.sleep(1)
                running_sec += 1
                now = time.time()

                # Check for user input
                while not input_queue.empty():
                    key = await input_queue.get()
                    if key == 'q':
                        raise KeyboardInterrupt
                    new_section = section_from_key(key)
                    if new_section and new_section != state.section:
                        old_label = SECTION_LABELS[state.section]
                        state.section = new_section
                        new_label = SECTION_LABELS[new_section]
                        state.section_log.append((now - state.session_start, new_section))
                        print(f"\n  ▶ 段落切换: {old_label} → {new_label}")
                        print(f"    → crossfade 4s\n")

                # Connection health
                hr_stale = (state.last_hr_time > 0 and now - state.last_hr_time > 3.0)
                if hr_stale:
                    print(f"  [{running_sec:3d}s] ⚠ HR 信号丢失")
                    continue

                # Cadence estimation (every second)
                state.cadence = estimate_cadence(state.acc_mag_buffer)
                state.cadence_history.append(state.cadence)
                update_cadence_lock()

                # Short-window breathing detection (every second, responsive)
                detect_breath_hold(state.rr_buffer)
                detect_deep_breath_realtime(state.rr_buffer)

                # Breathing estimation via FFT (every 5s, for stable rate)
                if running_sec % 5 == 0:
                    br, br_status = estimate_breathing_rate(state.rr_buffer)
                    state.breath_status = br_status
                    if br is not None:
                        # Smooth: reject jumps > 2x or < 0.5x previous (likely harmonic confusion)
                        if state.breath_rate is not None:
                            ratio_to_prev = br / (state.breath_rate + 1e-6)
                            if ratio_to_prev > 2.2 or ratio_to_prev < 0.45:
                                state.breath_status = f"harmonic_jump({br:.0f}vs{state.breath_rate:.0f})"
                            else:
                                state.breath_rate = br
                                state.breath_confidence = br_status
                                state.breath_history.append(br)
                                state._breath_miss_count = 0
                        else:
                            state.breath_rate = br
                            state.breath_confidence = br_status
                            state.breath_history.append(br)
                            state._breath_miss_count = 0
                    else:
                        # Don't immediately clear — hold last value for 2 cycles (10s) then clear
                        if state.breath_rate is not None:
                            if not hasattr(state, '_breath_miss_count'):
                                state._breath_miss_count = 0
                            state._breath_miss_count += 1
                            if state._breath_miss_count >= 2:
                                state.breath_rate = None
                                state.breath_confidence = None
                                state._breath_miss_count = 0
                        else:
                            state.breath_confidence = None

                # Build prompt output
                output = build_prompt_output()
                if output is None:
                    continue

                # Display
                p = output["physiology"]
                hr_str = f"{p['hr']}" if p['hr'] else "---"
                delta_str = f"Δ{p['delta_hr']:+.0f}" if p['delta_hr'] is not None else "    "
                trend_str = ""
                if p['hr_trend_10s'] is not None:
                    if p['hr_trend_10s'] > 8:
                        trend_str = "↑"
                    elif p['hr_trend_10s'] < -4:
                        trend_str = "↓"
                    else:
                        trend_str = "→"

                cadence_str = f"{p['cadence']:.0f}spm" if p['cadence'] else "---"
                lock_str = "🔒" if p['cadence_locked'] else ""

                rmssd_str = f"{p['rmssd']:.0f}ms" if p['rmssd'] else "---"
                rr_count = len(state.rr_buffer)

                # Breathing display with confidence and real-time events
                if state.breath_hold_detected:
                    breath_str = "HOLD!"
                elif state.deep_breath_realtime:
                    br_val = f"{p['breath_rate']:.0f}" if p['breath_rate'] else "?"
                    breath_str = f"DEEP({br_val})"
                elif p['breath_rate'] and state.breath_confidence:
                    conf_mark = "~" if state.breath_confidence == "weak" else ""
                    breath_str = f"{conf_mark}{p['breath_rate']:.0f}/min"
                else:
                    breath_str = "---"

                # RR data quality indicator
                rr_std = 0.0
                if rr_count >= 5:
                    recent_rr = [rr for _, rr in list(state.rr_buffer)[-30:]]
                    rr_std = float(np.std(recent_rr)) if recent_rr else 0.0

                # HR energy label
                dhr = p['delta_hr']
                if dhr is None:
                    energy_label = "---"
                elif dhr < 15:
                    energy_label = "light"
                elif dhr < 35:
                    energy_label = "steady"
                elif dhr < 50:
                    energy_label = "strong"
                else:
                    energy_label = "HIGH"

                section_icon = {
                    Section.INTRO: "🌅",
                    Section.VERSE: "📈",
                    Section.CHORUS: "🎵",
                    Section.BRIDGE: "⚡",
                    Section.OUTRO: "🌙",
                }[state.section]

                # Line 1: Core metrics
                print(f"  [{running_sec:3d}s] {section_icon} {state.section.value:6s} | HR:{hr_str:>3}{delta_str:>5}{trend_str} | Cad:{cadence_str:>6}{lock_str} | RMSSD:{rmssd_str:>5}(RR:{rr_count},SD:{rr_std:.0f}) | Breath:{breath_str:>6} | E:{energy_label}")

                # Show BPM anchor event
                if state.cadence_locked and state.cadence_lock_start:
                    lock_dur = now - state.cadence_lock_start
                    if lock_dur < 2:  # just locked
                        print(f"         ★ BPM Anchor 写入: {state.bpm_anchor:.0f} spm")

                # Show motif marker event
                if state.creative_events and state.creative_events[-1].get("type") == "motif_marker":
                    last_motif = state.creative_events[-1]
                    if now - state.session_start - last_motif["timestamp"] < 2:
                        print(f"         ♪ Motif Marker 触发! 深呼吸 → 主题动机写入")

                # Every 5s, show current prompt tags and diagnostics
                if running_sec % 5 == 0:
                    hr_tag_short = output['prompt']['hr_tags'][0] if output['prompt']['hr_tags'] else ""
                    trend_tag_short = output['prompt']['trend_tags'][0] if output['prompt']['trend_tags'] else ""
                    cad_tag_short = output['prompt']['cadence_tags'][0] if output['prompt']['cadence_tags'] else "---"
                    hrv_tag_short = output['prompt']['hrv_tags'][0] if output['prompt']['hrv_tags'] else "---"
                    breath_tag_short = output['prompt']['breath_tags'][0] if output['prompt']['breath_tags'] else "---"
                    # Diagnostic reasons for missing data
                    cad_reason = "(需要跑步)" if not p['cadence'] else ""
                    breath_reason = f"({state.breath_status})" if not p['breath_rate'] and state.breath_status else ""
                    hrv_reason = ""
                    if not output['prompt']['hrv_tags']:
                        if p['rmssd'] is None:
                            hrv_reason = "(RR数据不足)"
                        elif state.baseline_rmssd is None:
                            hrv_reason = "(无基线)"

                    # Real-time breath event indicators
                    rt_breath = ""
                    if state.breath_hold_detected:
                        rt_breath = " [HOLD]"
                    elif state.deep_breath_realtime:
                        rt_breath = " [DEEP]"

                    print(f"         HR→[{hr_tag_short}] Trend→[{trend_tag_short}]")
                    print(f"         Cad→[{cad_tag_short}] {cad_reason}")
                    print(f"         HRV→[{hrv_tag_short}] {hrv_reason}")
                    print(f"         Breath→[{breath_tag_short}] {breath_reason}{rt_breath}")

                # Duration limit
                if running_sec >= state.duration_min * 60:
                    print(f"\n  ── 运动时长 {state.duration_min} min 到达 ──")
                    break

        except KeyboardInterrupt:
            pass
        finally:
            input_task.cancel()

        # === SESSION SUMMARY ===
        print()
        print("  ══════════════════════════════════════════════════════════════")
        print("  ║  运动结束 · Session Summary                               ║")
        print("  ══════════════════════════════════════════════════════════════")
        print()

        # Section structure
        section_names = [s.value for _, s in state.section_log]
        print(f"  歌曲结构: {' → '.join(section_names)}")
        print()

        # Creative events
        if state.creative_events:
            print("  创作事件:")
            for ev in state.creative_events:
                ts = ev['timestamp']
                if ev['type'] == 'bpm_anchor':
                    print(f"    [{ts:.0f}s] BPM Anchor: {ev['value']} spm (in {ev['section']})")
            print()

        # Final song prompt
        print("  ── 最终歌曲 Prompt ───────────────────────────────────────────")
        print()
        final_prompt = build_final_song_prompt()
        print(f"  {final_prompt}")
        print()

        # Cleanup
        try:
            await client.stop_notify(HR_CHAR_UUID)
        except Exception:
            pass
        try:
            await client.stop_notify(PMD_DATA)
        except Exception:
            pass

        print("  BLE 已断开. 会话结束.")


def build_final_song_prompt():
    """Generate the post-exercise prompt for final song creation."""
    section_names = [s.value for _, s in state.section_log]
    structure_str = ", ".join([
        f"a {s}" for s in section_names
    ])

    bpm_line = ""
    if state.bpm_anchor:
        bpm_line = f"\nAnchor the rhythmic identity around a stable {state.bpm_anchor:.0f} steps-per-minute running pulse."

    prompt = (
        f"Create a complete instrumental {state.mood} {state.style} running track.\n"
        f"Structure: {structure_str}."
        f"{bpm_line}\n"
        f"Maintain motivating but controlled energy.\n"
        f"The bridge should express effort and transition without aggressive escalation.\n"
        f"No vocals."
    )
    return prompt


if __name__ == "__main__":
    asyncio.run(main())
