"""
Polar H10 · HRV + 呼吸频率 实时监测 (v2 修复版)
==================================================

修复内容（相比 v1）：
1. 呼吸频率用专门的"中等窗口"（80 秒左右），不再复用 baseline_pool
2. 频率分辨率从 1.875/min 提升到 ~0.94/min
3. 用抛物线插值获得亚 bin 精度，读数连续变化
4. 呼吸读数滞后从 2-3 分钟降低到 30-60 秒

依赖：
    pip install bleak numpy scipy
"""

import asyncio
import numpy as np
from collections import deque
from scipy.signal import welch
from scipy.interpolate import interp1d
from bleak import BleakClient, BleakScanner

HR_CHAR_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

rr_short = deque(maxlen=25)
rr_breath_window = deque(maxlen=100)
rr_baseline_pool = deque(maxlen=200)

baseline_rmssd = None


def parse_hr_data(data: bytearray):
    flags = data[0]
    hr_16bit = flags & 0x01
    rr_present = (flags & 0x10) >> 4

    offset = 1
    if hr_16bit:
        hr = int.from_bytes(data[offset:offset+2], "little")
        offset += 2
    else:
        hr = data[offset]
        offset += 1

    rr_intervals = []
    if rr_present:
        while offset < len(data):
            rr_raw = int.from_bytes(data[offset:offset+2], "little")
            rr_ms = rr_raw * 1000 / 1024
            rr_intervals.append(rr_ms)
            offset += 2

    return hr, rr_intervals


def compute_rmssd(rr_list):
    if len(rr_list) < 5:
        return None
    rr = np.array(rr_list)
    diffs = np.diff(rr)
    return float(np.sqrt(np.mean(diffs ** 2)))


def compute_respiration_rate(rr_list):
    if len(rr_list) < 30:
        return None

    rr = np.array(rr_list)
    rr_seconds = rr / 1000.0
    t_cumulative = np.cumsum(rr_seconds)

    duration = t_cumulative[-1] - t_cumulative[0]
    if duration < 20:
        return None

    fs = 4.0
    t_uniform = np.arange(t_cumulative[0], t_cumulative[-1], 1/fs)

    if len(t_uniform) < 64:
        return None

    try:
        interp_func = interp1d(t_cumulative, rr_seconds, kind='cubic',
                                fill_value='extrapolate')
        rr_uniform = interp_func(t_uniform)
    except Exception:
        return None

    rr_detrended = rr_uniform - np.mean(rr_uniform)

    nperseg = min(len(rr_detrended), 256)
    freqs, psd = welch(rr_detrended, fs=fs, nperseg=nperseg)

    resp_mask = (freqs >= 0.07) & (freqs <= 0.5)

    if not resp_mask.any():
        return None

    resp_freqs = freqs[resp_mask]
    resp_psd = psd[resp_mask]

    peak_idx = np.argmax(resp_psd)

    if 0 < peak_idx < len(resp_psd) - 1:
        y0 = resp_psd[peak_idx - 1]
        y1 = resp_psd[peak_idx]
        y2 = resp_psd[peak_idx + 1]
        denom = (y0 - 2*y1 + y2)
        if abs(denom) > 1e-12:
            delta = 0.5 * (y0 - y2) / denom
        else:
            delta = 0
        df = resp_freqs[1] - resp_freqs[0]
        peak_freq = resp_freqs[peak_idx] + delta * df
    else:
        peak_freq = resp_freqs[peak_idx]

    resp_rate_bpm = peak_freq * 60

    return float(resp_rate_bpm)


def classify_relative(current, baseline):
    if baseline is None or current is None:
        return "校准中..."

    ratio = current / baseline

    if ratio > 1.5:
        return "🟢🟢 显著放松 (副交感↑↑)"
    elif ratio > 1.2:
        return "🟢 放松 (副交感↑)"
    elif ratio > 0.85:
        return "🟡 基线状态"
    elif ratio > 0.65:
        return "🟠 紧张 (交感↑)"
    else:
        return "🔴 高压/激活 (交感↑↑)"


def classify_breathing(breath_rate):
    if breath_rate is None:
        return ""
    if breath_rate < 7:
        return "🌬️慢深呼吸"
    elif breath_rate < 11:
        return "深呼吸  "
    elif breath_rate < 20:
        return "自然呼吸"
    else:
        return "急促呼吸"


async def main():
    global baseline_rmssd

    print("=" * 70)
    print("Polar H10 · 心率 + HRV + 呼吸频率 实时监测 (v2)")
    print("=" * 70)
    print("\n扫描 Polar H10...")

    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )

    if not device:
        print("\n没找到 Polar H10 胸带")
        return

    print(f"找到设备：{device.name} ({device.address})")
    print("正在连接...\n")

    sample_count = 0

    async with BleakClient(device) as client:
        print("【校准阶段】前 30 秒请保持自然呼吸、不动，建立个人基线...")
        print("【实验提示】校准后试试：")
        print("  · 6秒吸 + 8秒呼 慢深呼吸 -> 呼吸读数应跌到 4-6/min")
        print("  · 突然站起来 -> RMSSD 下降、状态切换 紧张")
        print("  · 屏息 5-10 秒 -> 呼吸读数瞬间异常\n")

        def callback(_, data):
            nonlocal sample_count
            global baseline_rmssd

            hr, rrs = parse_hr_data(data)

            for rr in rrs:
                rr_short.append(rr)
                rr_breath_window.append(rr)
                rr_baseline_pool.append(rr)

            sample_count += 1
            current_rmssd = compute_rmssd(list(rr_short))
            breath_rate = compute_respiration_rate(list(rr_breath_window))

            if baseline_rmssd is None and len(rr_baseline_pool) >= 30:
                baseline_rmssd = compute_rmssd(list(rr_baseline_pool))
                print(f"\n个人基线 RMSSD = {baseline_rmssd:.1f} ms")
                print(f"开始实验！\n")

            if sample_count % 2 == 0:
                breath_str = f"{breath_rate:5.2f}/min" if breath_rate is not None else "  ---    "
                breath_status = classify_breathing(breath_rate)

                if baseline_rmssd is None:
                    progress = min(100, len(rr_baseline_pool) * 100 // 30)
                    rmssd_str = f"{current_rmssd:5.1f}ms" if current_rmssd is not None else "  ---  "
                    print(f"HR: {hr:3d} | RMSSD: {rmssd_str} | 呼吸: {breath_str} {breath_status} | 校准 {progress}%")
                else:
                    status = classify_relative(current_rmssd, baseline_rmssd)
                    if current_rmssd is not None:
                        ratio = current_rmssd / baseline_rmssd
                        print(f"HR: {hr:3d} | RMSSD: {current_rmssd:5.1f}ms x{ratio:.2f} | 呼吸: {breath_str} {breath_status} | {status}")
                    else:
                        print(f"HR: {hr:3d} | RMSSD:  ---  | 呼吸: {breath_str} | {status}")

        await client.start_notify(HR_CHAR_UUID, callback)
        await asyncio.sleep(180)
        await client.stop_notify(HR_CHAR_UUID)

        print("\n" + "=" * 70)
        print("会话结束")
        print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())