"""
Music Mapping · 状态向量 → 音乐控制参数
=========================================

消费 polar_state.py 的 state.latest_state_vector，
输出 emotion_texture / energy_level / motif_event 供 stems 控制器使用。

规则：
- emotion_texture 仅在 confidence=="high" 时更新，其余时间保持上一次可靠值
- energy_level 每 tick 都更新（HR 驱动，不受 HRV 门控）
- motif_event 在任何状态下都可触发（highlight_marker）
"""

TEXTURE_MAP = {
    "deeply_relaxed": "deep_calm_texture",
    "relaxed": "gentle_flowing_texture",
    "neutral": "neutral_steady_texture",
    "recovering": "soft_transition_texture",
    "tense": "grounded_stabilizing_texture",
    "activated": "controlled_regulating_pulse",
}


class MusicMapper:
    def __init__(self):
        self.energy_level = None
        self.current_texture = "neutral_steady_texture"
        self.emotion_source_state = "unknown"

    def update(self, sv: dict) -> dict:
        emotion_updated = False

        if sv.get("confidence") == "high":
            confirmed = sv.get("confirmed_state", "unknown")
            if confirmed in TEXTURE_MAP and confirmed != self.emotion_source_state:
                self.current_texture = TEXTURE_MAP[confirmed]
                self.emotion_source_state = confirmed
                emotion_updated = True

        hr = sv.get("hr")
        baseline_hr = sv.get("baseline_hr")
        if hr is not None and baseline_hr is not None:
            raw_energy = (hr - baseline_hr) / 60.0
            raw_energy = max(0.0, min(1.0, raw_energy))
            if self.energy_level is None:
                self.energy_level = raw_energy
            else:
                self.energy_level += 0.1 * (raw_energy - self.energy_level)

        motif_event = None
        if sv.get("highlight_marker"):
            motif_event = "highlight_current_motif"

        hrv_paused = (
            sv.get("motion_excluded", False)
            or sv.get("recovery_pending", False)
            or sv.get("confidence") != "high"
        )

        motion_active = sv.get("movement_state") in ("small_motion", "strong_motion")

        return {
            "emotion_texture": self.current_texture,
            "energy_level": round(self.energy_level, 3) if self.energy_level is not None else 0.0,
            "motif_event": motif_event,
            "hrv_paused": hrv_paused,
            "motion_active": motion_active,
            "emotion_source_state": self.emotion_source_state,
            "emotion_updated_this_tick": emotion_updated,
        }
