"""
Physiology → Lyria RealTime parameter mapping.

Converts polar_state2.State + build_prompt_output() result into
Lyria RealTime protocol messages (weighted_prompts + music_generation_config).
"""

import polar_state2 as ps2


def physio_to_lyria(state, output: dict) -> tuple:
    """Convert current physiological state into Lyria RealTime protocol.

    Args:
        state: polar_state2.State object with current physiology
        output: dict from build_prompt_output() (contains physiology, prompt_tags, etc.)

    Returns:
        (weighted_prompts: list[dict], config: dict)
    """
    physio = output.get('physiology', {})
    delta_hr = physio.get('delta_hr', 0) or 0
    cadence = physio.get('cadence') or 0
    rmssd = physio.get('rmssd') or 40.0
    rmssd_baseline = physio.get('rmssd_baseline') or 40.0
    breath_rate = physio.get('breath_rate') or 14.0

    prompts = []

    # Base genre from user preferences
    style = getattr(state, 'style', 'electronic')
    mood = getattr(state, 'mood', 'uplifting')
    prompts.append({"text": f"{style} instrumental {mood}", "weight": 0.5})

    # Energy level from HR delta
    if delta_hr > 50:
        prompts.append({"text": "intense powerful driving", "weight": 1.0})
    elif delta_hr > 30:
        prompts.append({"text": "energetic motivating high energy", "weight": 1.0})
    elif delta_hr > 15:
        prompts.append({"text": "steady rhythmic groove", "weight": 0.8})
    elif delta_hr > 5:
        prompts.append({"text": "light movement gentle rhythm", "weight": 0.7})
    else:
        prompts.append({"text": "calm ambient relaxed", "weight": 0.7})

    # HRV texture
    hrv_ratio = rmssd / (rmssd_baseline + 1e-6)
    if hrv_ratio > 1.1:
        prompts.append({"text": "open flowing harmonic spacious", "weight": 0.6})
    elif hrv_ratio < 0.6:
        prompts.append({"text": "tight percussive minimal tense", "weight": 0.7})
    elif hrv_ratio < 0.8:
        prompts.append({"text": "focused rhythmic controlled", "weight": 0.5})
    else:
        prompts.append({"text": "balanced coherent steady", "weight": 0.4})

    # Section mood
    section = getattr(state, 'section', None)
    section_val = section.value if section else 'verse'
    section_prompts = {
        "intro": {"text": "building anticipation emerging", "weight": 0.5},
        "verse": {"text": "groove rhythmic build momentum", "weight": 0.6},
        "chorus": {"text": "peak energy euphoric powerful", "weight": 0.8},
        "bridge": {"text": "tension contrast unexpected", "weight": 0.6},
        "outro": {"text": "resolution fading peaceful gentle", "weight": 0.7},
    }
    prompts.append(section_prompts.get(section_val, section_prompts["verse"]))

    # Breathing events
    if getattr(state, 'breath_hold_detected', False):
        prompts.append({"text": "suspended dramatic pause tension", "weight": 0.9})
    elif getattr(state, 'deep_breath_realtime', False):
        prompts.append({"text": "expanding spacious deep breath", "weight": 0.8})

    # --- Music generation config ---
    bpm = str(int(cadence)) if cadence > 100 else "100"

    density = 1.0 - (rmssd / 60.0)
    density = max(0.1, min(0.9, density))

    brightness = breath_rate / 35.0
    brightness = max(0.2, min(0.9, brightness))

    guidance = int(delta_hr / 15) + 2
    guidance = max(2, min(6, guidance))

    config = {
        "music_generation_config": {
            "bpm": bpm,
            "density": f"{density:.1f}",
            "brightness": f"{brightness:.1f}",
            "guidance": str(guidance),
        }
    }

    return prompts, config
