import asyncio
from bleak import BleakClient, BleakScanner

HR_CHAR_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

def parse_hr_data(data: bytearray):
    """解析 Polar H10 心率数据包"""
    flags = data[0]
    hr_16bit = flags & 0x01
    rr_present = (flags & 0x10) >> 4
    
    offset = 1
    if hr_16bit:
        hr = int.from_bytes(data[offset:offset+2], "little")
        offset += 2
    else:
        hr = data[offset]
        offset += 1
    
    rr_intervals = []
    if rr_present:
        while offset < len(data):
            rr_raw = int.from_bytes(data[offset:offset+2], "little")
            rr_ms = rr_raw * 1000 / 1024
            rr_intervals.append(round(rr_ms, 1))
            offset += 2
    
    return hr, rr_intervals

async def main():
    print("扫描 Polar H10...")
    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    
    if not device:
        print("没找到 Polar H10 胸带。检查：")
        print("  (1) 胸带电极是否打湿")
        print("  (2) 胸带是否戴在身上")
        print("  (3) 手机的 Polar Beat App 是否已关闭（会抢占连接）")
        return
    
    print(f"找到设备：{device.name} ({device.address})")
    print("正在连接...")
    
    async with BleakClient(device) as client:
        print("已连接！开始接收数据（60 秒）...\n")
        
        def callback(_, data):
            hr, rrs = parse_hr_data(data)
            print(f"❤️  HR: {hr:3d} bpm  |  RR: {rrs} ms")
        
        await client.start_notify(HR_CHAR_UUID, callback)
        await asyncio.sleep(60)
        await client.stop_notify(HR_CHAR_UUID)
        
        print("\n数据流测试结束")

asyncio.run(main())