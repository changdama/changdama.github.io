"""
Resonance Signal Pipeline
=========================

反应式信号总线架构：BLE 信号 → 处理器 → 平滑参数 → 事件驱动 Lyria 转向

核心模块:
    bus             — SignalBus pub/sub 事件总线
    smoothers       — EMA, Interpolator, RateOfChange
    sources         — BLE 信号源适配器
    processors      — HR/Cadence/Breath 处理器
    prompt_composer — Prompt 组装（平滑输出 + 事件 fade-out）
    steer_controller — Lyria 转向控制器（事件驱动 + 漂移检测）
    calibration     — 校准管理器
"""

from sigbus.bus import SignalBus
from sigbus.smoothers import EMA, Interpolator, RateOfChange
from sigbus.pipeline import SignalPipeline
