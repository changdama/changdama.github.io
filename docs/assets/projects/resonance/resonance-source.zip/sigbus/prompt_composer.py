"""
PromptComposer — Prompt 组装器
================================

从 SignalBus 读取平滑状态，组装 Lyria RealTime 的 weighted_prompts + config。

核心改进:
    - 参数映射从阶梯式改为连续线性 + Interpolator 平滑
    - 事件型 prompt 使用 EventPrompt fade-out 衰减
    - config (density/brightness/guidance/bpm) 全经 Interpolator 输出
"""

import time
import numpy as np
from typing import Optional
from enum import Enum

from sigbus.bus import SignalBus
from sigbus.smoothers import Interpolator, EventPrompt


class Section(Enum):
    INTRO = "intro"
    VERSE = "verse"
    CHORUS = "chorus"
    BRIDGE = "bridge"
    OUTRO = "outro"


# 段落 prompt 模板
SECTION_PROMPTS = {
    Section.INTRO:  "ambient pad texture, no drums, no percussion, gentle atmospheric swell, sparse and airy",
    Section.VERSE:  "groove rhythmic build, forward momentum, motif development, light percussion emerging",
    Section.CHORUS: "peak energy euphoric, strong theme, full layers, driving beat",
    Section.BRIDGE: "tension contrast, unexpected shift, dramatic texture, intense percussion",
    Section.OUTRO:  "fading ambient, no drums, gentle release, spacious dissolve, breath-like pads",
}


class PromptComposer:
    """Prompt 组装器。从 bus 读取平滑信号，输出 Lyria 控制参数。

    所有连续参数经 Interpolator 平滑输出，事件型 prompt 带衰减。
    """

    def __init__(self, bus: SignalBus, style: str = 'electronic',
                 mood: str = 'uplifting', hr_baseline: float = 72.0,
                 rmssd_baseline: float = 40.0):
        self.bus = bus
        self.style = style
        self.mood = mood
        self.hr_baseline = hr_baseline
        self.rmssd_baseline = rmssd_baseline
        self.section = Section.VERSE

        # 连续参数 Interpolators (2s ease-out 过渡)
        self._density_interp = Interpolator(duration_sec=2.0, easing='ease_out', initial=0.5)
        self._brightness_interp = Interpolator(duration_sec=2.0, easing='ease_out', initial=0.5)
        self._guidance_interp = Interpolator(duration_sec=2.5, easing='ease_out', initial=3.0)
        self._bpm_interp = Interpolator(duration_sec=0.5, easing='ease_out', initial=140.0)
        self._energy_weight_interp = Interpolator(duration_sec=1.5, easing='ease_out', initial=0.5)
        self._hrv_weight_interp = Interpolator(duration_sec=2.0, easing='ease_out', initial=0.4)

        # 活跃的事件型 prompts (带衰减)
        self._active_events: list[EventPrompt] = []

        # 订阅 bus 更新 Interpolator 目标值
        bus.subscribe('hr.delta', self._on_hr_delta)
        bus.subscribe('hrv.rmssd', self._on_hrv)
        bus.subscribe('cadence.smooth', self._on_cadence)
        bus.subscribe('breath.rate', self._on_breath_rate)

        # 订阅事件通道
        bus.subscribe('breath.hold', self._on_breath_hold)
        bus.subscribe('breath.deep', self._on_breath_deep)
        bus.subscribe('cadence.locked', self._on_cadence_locked)

    def set_section(self, section: Section):
        """切换歌曲段落。

        Density 优先级排序（高→低）：
          Bridge(0.80) > Chorus(0.68) > Verse(0.50) > Intro/Outro(0.15)
        """
        self.section = section
        # 段落切换时，给 density 设一个新的目标（缓慢过渡，避免静音跳变）
        now = time.time()
        if section in (Section.INTRO, Section.OUTRO):
            self._density_interp.set_target(0.15, now)
            self._brightness_interp.set_target(0.35, now)
        elif section == Section.VERSE:
            self._density_interp.set_target(0.50, now)
            self._brightness_interp.set_target(0.50, now)
        elif section == Section.CHORUS:
            self._density_interp.set_target(0.68, now)
            self._brightness_interp.set_target(0.60, now)
        elif section == Section.BRIDGE:
            self._density_interp.set_target(0.80, now)
            self._brightness_interp.set_target(0.55, now)

    def set_baselines(self, hr_baseline: float, rmssd_baseline: float):
        self.hr_baseline = hr_baseline
        self.rmssd_baseline = rmssd_baseline

    # === Bus Callbacks: 更新 Interpolator 目标 ===

    def _on_hr_delta(self, channel, value, ts):
        """ΔHR → energy weight + guidance + density 目标。"""
        delta_hr = max(0, value)

        # Energy weight: 映射 [0, 40] → [0.1, 1.0]
        # 真实跑步 delta 范围: 热身+5, 中速+15-20, 快跑+25-35, 极限+40+
        energy = np.clip(delta_hr / 40.0, 0.1, 1.0)
        self._energy_weight_interp.set_target(float(energy), ts)

        # Guidance: [0, 40] → [2, 6]
        guidance = 2.0 + (delta_hr / 40.0) * 4.0
        guidance = np.clip(guidance, 2.0, 6.0)
        self._guidance_interp.set_target(float(guidance), ts)

        # Density partial: HR 高 → density 高
        density_from_hr = np.clip(delta_hr / 35.0, 0.2, 0.8)
        self._density_from_hr = float(density_from_hr)

    def _on_hrv(self, channel, value, ts):
        """HRV (RMSSD) → density + HRV texture weight。"""
        rmssd = value
        ratio = rmssd / (self.rmssd_baseline + 1e-6)

        # RMSSD 高 → density 低 (open/spacious)
        # RMSSD 低 → density 高 (tight/percussive)
        density_from_hrv = np.clip(1.0 - (rmssd / 60.0), 0.1, 0.9)
        self._density_interp.set_target(float(density_from_hrv), ts)

        # HRV texture weight
        if ratio > 1.1:
            self._hrv_weight_interp.set_target(0.6, ts)
        elif ratio < 0.6:
            self._hrv_weight_interp.set_target(0.7, ts)
        else:
            self._hrv_weight_interp.set_target(0.4, ts)

    def _on_cadence(self, channel, value, ts):
        """步频 → BPM 目标。"""
        if value and value > 100:
            self._bpm_interp.set_target(float(value), ts)

    def _on_breath_rate(self, channel, value, ts):
        """呼吸频率 → brightness。"""
        # 呼吸快 → brightness 高，呼吸慢 → brightness 低
        brightness = np.clip(value / 35.0, 0.2, 0.9)
        self._brightness_interp.set_target(float(brightness), ts)

    # === 事件型 Prompt ===

    def _on_breath_hold(self, channel, value, ts):
        if value:  # True = 检测到
            self._active_events.append(EventPrompt(
                text="suspended dramatic pause, held breath tension, stripped texture",
                peak_weight=0.9,
                decay_sec=4.0,
                triggered_at=ts,
            ))

    def _on_breath_deep(self, channel, value, ts):
        if value:  # True = 检测到
            self._active_events.append(EventPrompt(
                text="expanding spacious breath, deep resonant tones, slow wave motion",
                peak_weight=0.8,
                decay_sec=5.0,
                triggered_at=ts,
            ))

    def _on_cadence_locked(self, channel, value, ts):
        if value:  # True = 锁定
            anchor = self.bus.last_value('cadence.anchor', 170)
            self._active_events.append(EventPrompt(
                text=f"rhythmic pulse anchored to {anchor:.0f} spm, synchronized percussion",
                peak_weight=0.7,
                decay_sec=8.0,  # 步频锁定持续较长
                triggered_at=ts,
            ))

    # === 核心: Compose ===

    def compose(self, now: float = None) -> tuple[list[dict], dict]:
        """组装当前 Lyria 转向指令。

        Returns:
            (weighted_prompts, config)
            weighted_prompts: [{"text": ..., "weight": ...}, ...]
            config: {"music_generation_config": {"bpm": ..., "density": ..., ...}}
        """
        if now is None:
            now = time.time()

        prompts = []

        # 1. Base: style + mood
        prompts.append({
            "text": f"{self.style} instrumental {self.mood}",
            "weight": 0.5
        })

        # 2. Section
        section_text = SECTION_PROMPTS.get(self.section, SECTION_PROMPTS[Section.VERSE])
        prompts.append({
            "text": section_text,
            "weight": 0.6
        })

        # 3. Energy (from HR delta) — 档内连续变体 + 趋势修饰
        energy_weight = self._energy_weight_interp.get(now)
        delta_hr = self.bus.last_value('hr.delta', 0)
        hr_trend = self.bus.last_value('hr.trend', 0)  # 10s 内变化
        if delta_hr is not None:
            # 档内用 fractional position 选变体（同一档也有不同描述）
            if energy_weight > 0.85:
                frac = (energy_weight - 0.85) / 0.15
                if frac > 0.5:
                    energy_text = "absolute peak redline, distorted bass wall, chaotic energy burst"
                else:
                    energy_text = "maximum intensity explosive power, aggressive drums, relentless drive"
            elif energy_weight > 0.65:
                frac = (energy_weight - 0.65) / 0.20
                if frac > 0.6:
                    energy_text = "fierce surging power, pounding kicks, raw intensity building"
                elif frac > 0.3:
                    energy_text = "intense powerful driving energy, heavy percussion, surging momentum"
                else:
                    energy_text = "strong determined push, thick layered beats, muscular groove"
            elif energy_weight > 0.50:
                frac = (energy_weight - 0.50) / 0.15
                if frac > 0.5:
                    energy_text = "high energy ascending, punchy synths, escalating dynamics"
                else:
                    energy_text = "energetic motivating force, crisp snare hits, forward momentum"
            elif energy_weight > 0.35:
                frac = (energy_weight - 0.35) / 0.15
                if frac > 0.5:
                    energy_text = "warming groove picking up, growing rhythmic intensity"
                else:
                    energy_text = "steady rhythmic groove, moderate drive, consistent pulse"
            elif energy_weight > 0.20:
                frac = (energy_weight - 0.20) / 0.15
                if frac > 0.5:
                    energy_text = "gentle movement awakening, soft percussion materializing"
                else:
                    energy_text = "light ambient motion, subtle rhythmic hints, ease into flow"
            elif energy_weight > 0.13:
                frac = (energy_weight - 0.13) / 0.07
                if frac > 0.5:
                    energy_text = "quiet stirring beneath surface, faint pulse forming, subtle warmth"
                else:
                    energy_text = "barely perceptible drift, distant low hum, slow tonal shift"
            else:
                frac = energy_weight / 0.13
                if frac > 0.5:
                    energy_text = "calm ambient stillness, suspended in air, soft granular haze"
                else:
                    energy_text = "pure silence texture, frozen atmosphere, crystalline void"

            # 趋势修饰：HR 正在上升/下降/平稳 → 附加动态感描述
            if hr_trend and hr_trend > 3:
                energy_text += ", intensity rising, building pressure"
            elif hr_trend and hr_trend > 1.5:
                energy_text += ", slowly awakening, subtle lift"
            elif hr_trend and hr_trend < -3:
                energy_text += ", gradually easing, releasing tension"
            elif hr_trend and hr_trend < -1.5:
                energy_text += ", gently settling, softening edges"
            # hr_trend ∈ [-1.5, 1.5] → 稳定，不加修饰

            prompts.append({"text": energy_text, "weight": float(energy_weight)})

        # 4. HRV texture — 档内连续变体（ratio = rmssd / baseline）
        hrv_weight = self._hrv_weight_interp.get(now)
        rmssd = self.bus.last_value('hrv.rmssd')
        if rmssd is not None:
            ratio = rmssd / (self.rmssd_baseline + 1e-6)
            if ratio > 1.3:
                hrv_text = "wide open ethereal, lush reverb, drifting harmonic clouds"
            elif ratio > 1.0:
                frac = (ratio - 1.0) / 0.3
                if frac > 0.5:
                    hrv_text = "spacious airy pads, gentle shimmer, unhurried harmonic motion"
                else:
                    hrv_text = "open flowing harmonic, soft layering, relaxed stereo field"
            elif ratio > 0.8:
                frac = (ratio - 0.8) / 0.2
                if frac > 0.5:
                    hrv_text = "balanced coherent steady, clean mix, even texture"
                else:
                    hrv_text = "organized rhythmic clarity, structured layers, neutral tone"
            elif ratio > 0.65:
                frac = (ratio - 0.65) / 0.15
                if frac > 0.5:
                    hrv_text = "focused controlled precision, tight arrangement, clipped transients"
                else:
                    hrv_text = "narrowing focus, dry percussive hits, reduced reverb, direct sound"
            elif ratio > 0.5:
                frac = (ratio - 0.5) / 0.15
                if frac > 0.5:
                    hrv_text = "compressed tense urgency, stripped layers, mechanical repetition"
                else:
                    hrv_text = "tight percussive minimal, hard-panned stabs, staccato tension"
            else:
                if ratio > 0.35:
                    hrv_text = "raw aggressive distorted, stripped to core, maximum compression"
                else:
                    hrv_text = "chaotic noise texture, glitch artifacts, breaking apart"
            prompts.append({"text": hrv_text, "weight": float(hrv_weight)})

        # 4b. Breath texture — 呼吸频率映射音乐呼吸感 + 档内变体
        breath_rate = self.bus.last_value('breath.rate')
        if breath_rate is not None:
            if breath_rate > 35:
                frac = min((breath_rate - 35) / 10.0, 1.0)
                if frac > 0.5:
                    breath_text = "hyperventilating chaos, fragmented stuttering cuts, no space"
                else:
                    breath_text = "frantic staccato gasping, choppy short phrases, abrupt edits"
                breath_weight = 0.55
            elif breath_rate > 28:
                frac = (breath_rate - 28) / 7.0
                if frac > 0.5:
                    breath_text = "panting rhythm, clipped melodic bursts, rapid-fire texture"
                else:
                    breath_text = "quick breathing pace, short phrases, snappy transitions"
                breath_weight = 0.45
            elif breath_rate > 22:
                frac = (breath_rate - 22) / 6.0
                if frac > 0.5:
                    breath_text = "active breathing flow, medium-short phrases, natural momentum"
                else:
                    breath_text = "steady breathing rhythm, even phrase lengths, balanced pacing"
                breath_weight = 0.30
            elif breath_rate > 16:
                frac = (breath_rate - 16) / 6.0
                if frac > 0.5:
                    breath_text = "comfortable deep breathing, flowing legato lines, smooth arcs"
                else:
                    breath_text = "relaxed slow breathing, long sustained phrases, gentle contour"
                breath_weight = 0.35
            else:
                frac = max(0, (breath_rate - 8) / 8.0)
                if frac > 0.5:
                    breath_text = "deep meditative breath, extended tones, wide open space"
                else:
                    breath_text = "barely breathing stillness, infinite sustain, frozen time"
                breath_weight = 0.40
            prompts.append({"text": breath_text, "weight": breath_weight})

        # 4c. Cadence feel — 步频映射节奏性格 + 档内变体
        cadence = self.bus.last_value('cadence.smooth')
        if cadence and cadence > 100:
            if cadence > 190:
                frac = min((cadence - 190) / 15.0, 1.0)
                if frac > 0.5:
                    cad_text = "sprint maximum turnover, frenzied cymbal rolls, breakneck pace"
                else:
                    cad_text = "sprint tempo blazing fast, machine-gun hi-hats, relentless"
                cad_weight = 0.50
            elif cadence > 175:
                frac = (cadence - 175) / 15.0
                if frac > 0.5:
                    cad_text = "aggressive fast tempo, driving double-time fills, urgent pulse"
                else:
                    cad_text = "fast tempo pushing forward, rapid kick pattern, energetic pulse"
                cad_weight = 0.40
            elif cadence > 160:
                frac = (cadence - 160) / 15.0
                if frac > 0.5:
                    cad_text = "upbeat bouncy rhythm, offbeat accents, lively syncopation"
                else:
                    cad_text = "brisk tempo, clean rhythmic grid, propulsive groove"
                cad_weight = 0.35
            elif cadence > 145:
                frac = (cadence - 145) / 15.0
                if frac > 0.5:
                    cad_text = "comfortable jog rhythm, steady kick-snare, reliable groove"
                else:
                    cad_text = "moderate tempo, four-on-floor foundation, easy running feel"
                cad_weight = 0.30
            else:
                frac = max(0, (cadence - 120) / 25.0)
                if frac > 0.5:
                    cad_text = "easy shuffle tempo, swung groove, laid-back pocket"
                else:
                    cad_text = "slow half-time feel, wide spacing, patient rhythm"
                cad_weight = 0.25
            prompts.append({"text": cad_text, "weight": cad_weight})

        # 5. 活跃事件 prompts (带衰减 weight)
        self._cleanup_expired_events(now)
        for event in self._active_events:
            w = event.current_weight(now)
            if w > 0.05:  # 忽略接近 0 的
                prompts.append({"text": event.text, "weight": round(w, 2)})

        # 6. Config: 全部经 Interpolator 平滑输出
        bpm = self._bpm_interp.get(now)
        density = self._density_interp.get(now)
        brightness = self._brightness_interp.get(now)
        guidance = self._guidance_interp.get(now)

        # 段落约束：Intro/Outro 压制 density（set_section 已设目标，这里只做软上限）
        if self.section in (Section.INTRO, Section.OUTRO):
            density = min(density, 0.25)  # 软上限，允许过渡期稍高
            guidance = min(guidance, 3.0)

        config = {
            "music_generation_config": {
                "bpm": str(int(max(80, min(200, bpm)))),
                "density": f"{density:.2f}",
                "brightness": f"{brightness:.2f}",
                "guidance": str(int(max(2, min(6, guidance)))),
            }
        }

        return prompts, config

    def _cleanup_expired_events(self, now: float):
        """移除已衰减完毕的事件 prompts。"""
        self._active_events = [e for e in self._active_events
                               if e.current_weight(now) > 0.0]

    def build_metrics_output(self, elapsed_sec: float = 0, duration_sec: float = 300) -> dict:
        """构建发送给前端的 metrics 数据包。

        兼容旧版 build_prompt_output() 的结构：
        - prompt_tags: 细粒度 tag 列表（每层独立的描述性短语）
        - full_prompt: 所有层拼接的完整 prompt
        - prompt: 分层字典（preference, section, hr_tags, trend_tags, ...）
        """
        now = time.time()

        # === 分层 Tag 生成（与旧版 polar_state2.build_prompt_output 逻辑一致）===
        delta_hr = self.bus.last_value('hr.delta', 0) or 0
        trend = self.bus.last_value('hr.trend', 0)
        cadence = self.bus.last_value('cadence.smooth')
        cadence_locked = self.bus.last_value('cadence.locked', False)
        rmssd = self.bus.last_value('hrv.rmssd')
        breath_rate = self.bus.last_value('breath.rate')
        breath_hold = self.bus.last_value('breath.hold', False)
        deep_breath = self.bus.last_value('breath.deep', False)

        preference = f"instrumental {self.mood} {self.style} running music, immersive and rhythmic, no vocals"
        section_prompt = SECTION_PROMPTS.get(self.section, "")

        # HR energy tags
        hr_tags = []
        if delta_hr < 15:
            hr_tags = ["light energy", "comfortable pacing", "soft rhythmic pulse"]
        elif delta_hr < 35:
            hr_tags = ["steady motivating energy", "balanced rhythmic drive"]
        elif delta_hr < 50:
            hr_tags = ["strong but controlled energy", "focused forward motion"]
        else:
            hr_tags = ["regulated intensity", "grounded pulse"]

        # Trend tags
        trend_tags = []
        if trend is not None:
            if trend > 8:
                trend_tags = ["building momentum", "controlled rhythmic rise"]
            elif trend < -4:
                trend_tags = ["gradual release", "softer rhythmic motion"]
            else:
                trend_tags = ["evolving groove", "ongoing rhythmic development"]

        # Cadence tags
        cadence_tags = []
        if cadence and cadence > 100:
            if cadence_locked:
                cadence_tags = [f"rhythmic pulse anchored to {cadence:.0f} steps per minute",
                               "locked percussion driving forward with running cadence"]
            else:
                cadence_tags = [f"approximate running cadence around {cadence:.0f} steps per minute"]

        # HRV tags
        hrv_tags = []
        if rmssd is not None:
            ratio = rmssd / (self.rmssd_baseline + 1e-6)
            if ratio > 1.1:
                hrv_tags = ["open flowing harmonic texture", "spacious ambience"]
            elif ratio < 0.7:
                hrv_tags = ["grounded restrained texture", "controlled tension"]
            elif 0.8 <= ratio <= 1.2:
                hrv_tags = ["balanced coherent texture", "stable tonal atmosphere"]

        # Breath tags
        breath_tags = []
        if breath_hold:
            breath_tags = ["suspended tension", "held breath moment", "anticipatory pause"]
        elif deep_breath:
            breath_tags = ["expanding spacious phrasing", "deep resonant tones"]
        elif breath_rate is not None:
            if breath_rate < 12:
                breath_tags = ["smooth phrasing", "gentle cyclical motion", "spacious resonance"]
            elif breath_rate <= 20:
                breath_tags = ["natural rhythmic flow"]
            elif breath_rate > 25:
                breath_tags = ["restrained texture", "slower harmonic movement"]
            else:
                breath_tags = ["forward-moving phrasing"]

        # Combine all tags
        constraint = "seamless loopable section, no vocals"
        all_tags = [section_prompt] + hr_tags + trend_tags + cadence_tags + hrv_tags + breath_tags
        full_prompt = f"{preference}, {', '.join(all_tags)}, {constraint}"

        return {
            "timestamp": elapsed_sec,
            "elapsed_sec": elapsed_sec,
            "duration_sec": duration_sec,
            "phase": "running",
            "selected_section": self.section.value,
            "physiology": {
                "hr": self.bus.last_value('hr.raw'),
                "hr_baseline": self.hr_baseline,
                "delta_hr": round(delta_hr, 1) if delta_hr else None,
                "hr_trend_10s": round(trend, 1) if trend else None,
                "cadence": round(cadence, 0) if cadence else None,
                "cadence_locked": cadence_locked,
                "bpm_anchor": round(self.bus.last_value('cadence.anchor', 0))
                            if self.bus.last_value('cadence.anchor') else None,
                "rmssd": round(rmssd, 1) if rmssd else None,
                "rmssd_baseline": round(self.rmssd_baseline, 1),
                "breath_rate": round(breath_rate, 1) if breath_rate else None,
                "breath_confidence": self.bus.last_value('breath.confidence'),
            },
            "prompt": {
                "preference": preference,
                "section": section_prompt,
                "hr_tags": hr_tags,
                "trend_tags": trend_tags,
                "cadence_tags": cadence_tags,
                "hrv_tags": hrv_tags,
                "breath_tags": breath_tags,
                "constraint": constraint,
            },
            "prompt_tags": all_tags,
            "full_prompt": full_prompt,
            "creative_events": [e.text for e in self._active_events if e.current_weight(now) > 0.05],
            "breath_hold": breath_hold,
            "deep_breath_rt": deep_breath,
            "active_events": len(self._active_events),
        }
