"""
SignalPipeline — 信号管道组装器
=================================

将 SignalBus + Sources + Processors + Composer + SteerController 组装成
一个完整的管道实例，供 app.py 使用。

使用方式:
    pipeline = SignalPipeline(socketio=socketio, mock=False)
    await pipeline.run_calibration()
    await pipeline.run_session(duration_sec=300)
"""

import time
import asyncio
from typing import Optional

from sigbus.bus import SignalBus
from sigbus.sources import BLESource, MockSource
from sigbus.calibration import CalibrationManager
from sigbus.processors import HRProcessor, CadenceProcessor, BreathProcessor
from sigbus.prompt_composer import PromptComposer, Section
from sigbus.steer_controller import SteerController
from lyria_client import LyriaClient


class SignalPipeline:
    """完整的信号管道。

    组装所有组件，提供高层 API 给 app.py 调用。

    Lifecycle:
        1. __init__     — 创建 bus + source + processors
        2. calibrate()  — 30s 校准，建立 baseline
        3. start()      — 启动 SteerController + Lyria
        4. stop()       — 停止所有组件
    """

    def __init__(self, socketio=None, mock: bool = False,
                 style: str = 'electronic', mood: str = 'uplifting',
                 api_key: str = None, max_goals: int = 0):
        self.socketio = socketio
        self.mock = mock
        self.api_key = api_key
        self.max_goals = max_goals

        # 核心 bus
        self.bus = SignalBus(history_size=200)

        # 信号源
        if mock:
            self.source = MockSource(self.bus)
        else:
            self.source = BLESource(self.bus)

        # Processors (创建但先不设 baseline)
        self.hr_processor = HRProcessor(self.bus)
        self.cadence_processor = CadenceProcessor(self.bus)
        self.breath_processor = BreathProcessor(self.bus)

        # Composer
        self.composer = PromptComposer(
            self.bus, style=style, mood=mood
        )

        # SteerController + Lyria (延迟创建，start() 时初始化)
        self.steer_queue: Optional[asyncio.Queue] = None
        self.steer_controller: Optional[SteerController] = None
        self.lyria_client: Optional[LyriaClient] = None
        self._lyria_task: Optional[asyncio.Task] = None

        # Session state
        self._running = False
        self._session_start: float = 0.0
        self._goals_completed = 0
        self._goal_triggered = False
        self._last_segment_start = 0  # elapsed_sec of last segment boundary

        # Prompt log (for post-session polish)
        self.prompt_log: list[dict] = []
        self.creative_events: list[dict] = []
        self.section_log: list[tuple] = []

        # Metrics emitter 订阅
        self.bus.subscribe('cadence.locked', self._on_creative_event)
        self.bus.subscribe('breath.hold', self._on_creative_event)
        self.bus.subscribe('breath.deep', self._on_creative_event)

    # === Calibration ===

    async def calibrate(self, duration: int = 30) -> dict:
        """运行校准阶段。

        Returns:
            baseline dict
        """
        calibration = CalibrationManager(
            self.bus, duration=duration, socketio=self.socketio
        )
        result = await calibration.run()

        # 设置各组件的 baseline
        hr_base = result['hr_baseline']
        rmssd_base = result['rmssd_baseline']
        acc_base = result['acc_baseline']

        self.hr_processor.set_baselines(hr_base, rmssd_base)
        self.composer.set_baselines(hr_base, rmssd_base)

        if acc_base:
            self.cadence_processor.set_baseline(acc_base)

        return result

    # === Session Control ===

    async def start(self, loop: asyncio.AbstractEventLoop = None):
        """启动 SteerController 和 Lyria 连接。"""
        if loop is None:
            loop = asyncio.get_event_loop()

        self._running = True
        self._session_start = time.time()

        # 创建 steer queue
        self.steer_queue = asyncio.Queue(maxsize=8)

        # 创建 SteerController
        self.steer_controller = SteerController(
            self.bus, self.composer, self.steer_queue, loop=loop
        )
        self.steer_controller.start(loop)

        # 启动 Lyria
        if self.api_key:
            self.lyria_client = LyriaClient(
                api_key=self.api_key,
                socketio=self.socketio,
                steer_queue=self.steer_queue,
                output_dir="output",
                segment_idx=0,
            )
            self._lyria_task = asyncio.create_task(self.lyria_client.run())

            if self.socketio:
                self.socketio.emit('lyria_status', {'status': 'connecting'})

    async def stop(self):
        """停止所有组件。"""
        self._running = False

        if self.steer_controller:
            self.steer_controller.stop()

        if self.lyria_client:
            await self.lyria_client.stop()
            if self._lyria_task:
                try:
                    await asyncio.wait_for(self._lyria_task, timeout=5.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass

    # === Running Loop ===

    async def run_session(self, duration_sec: int = 300,
                          session_id_ref: list = None):
        """运行完整会话（校准后调用）。

        这是简化版的主循环：
        - Mock 模式下每秒 tick 模拟数据
        - 真实模式下 BLE 回调自动流入 bus
        - 每秒发送 metrics_update 给前端
        - SteerController 在后台自主决定何时转向

        Args:
            duration_sec: 会话时长（秒）
            session_id_ref: [session_id] — 用于检测会话是否被中断
        """
        elapsed = 0
        sid = session_id_ref[0] if session_id_ref else None

        while elapsed < duration_sec and self._running:
            # 会话中断检测
            if session_id_ref and session_id_ref[0] != sid:
                break

            await asyncio.sleep(1.0)
            elapsed += 1

            # Mock 模式: 每秒生成模拟数据（同步段落状态让 HR 跟随段落变化）
            if self.mock:
                self.source.section = self.composer.section.value
                self.source.tick(elapsed_sec=elapsed, phase='running')

            # Goal check
            if self._goal_triggered and self._goals_completed < self.max_goals:
                self._goal_triggered = False
                self._goals_completed += 1
                await self._handle_goal_rest(elapsed)
                continue

            # 构建 metrics（每秒一次，同时用于前端显示和 prompt_log）
            metrics = self.composer.build_metrics_output(
                elapsed_sec=elapsed,
                duration_sec=duration_sec,
            )
            metrics['goals_completed'] = self._goals_completed
            metrics['max_goals'] = self.max_goals

            # 发送 metrics 给前端
            if self.socketio:
                self.socketio.emit('metrics_update', metrics)

            # 记录 prompt log（每秒记一次，与旧版一致，用于 segment merge + polish）
            prompt_text = metrics.get('full_prompt', '')
            prompt_tags = metrics.get('prompt_tags', [])
            if prompt_text:
                self.prompt_log.append({
                    'elapsed_sec': elapsed,
                    'section': self.composer.section.value,
                    'prompt': prompt_text,
                    'tags': prompt_tags,
                })

        # Session complete
        await self.stop()
        return self._build_session_result(elapsed, duration_sec)

    async def _handle_goal_rest(self, current_elapsed: int):
        """处理 goal 达成后的休息期。"""
        REST_DURATION = 60
        KEEPALIVE_INTERVAL = 5

        # Mute Lyria
        if self.lyria_client:
            self.lyria_client.mute()

        # 收集本段的 prompt 数据（从上次 rest 或 session 开始到现在）
        segment_prompts = [p for p in self.prompt_log if p['elapsed_sec'] > self._last_segment_start]
        segment_tags = self._extract_unique_tags(segment_prompts)
        self._last_segment_start = current_elapsed

        if self.socketio:
            import os
            last_wav = (self.lyria_client.segment_wav_paths[-1]
                       if self.lyria_client and self.lyria_client.segment_wav_paths
                       else None)
            self.socketio.emit('rest_period_start', {
                'goal_num': self._goals_completed,
                'max_goals': self.max_goals,
                'rest_duration': REST_DURATION,
                'wav_url': f"/output/{os.path.basename(last_wav)}" if last_wav else None,
                'segment_prompts': segment_prompts[-5:],  # 最近 5 条
                'segment_tags': segment_tags,
            })

        # Rest countdown
        for rest_sec in range(REST_DURATION):
            if not self._running:
                return
            await asyncio.sleep(1)
            if self.socketio:
                self.socketio.emit('rest_tick', {'remaining': REST_DURATION - 1 - rest_sec})
            if self.lyria_client and rest_sec % KEEPALIVE_INTERVAL == 0:
                await self.lyria_client.send_keepalive()

        # Unmute
        if self.lyria_client:
            self.lyria_client.unmute()
            if self.socketio:
                self.socketio.emit('lyria_status', {'status': 'streaming'})
            # 立即转向
            if self.steer_controller:
                self.steer_controller.force_steer()

        if self.socketio:
            self.socketio.emit('rest_period_end', {
                'next_goal': self._goals_completed + 1
            })

    @staticmethod
    def _extract_unique_tags(prompts: list[dict]) -> list[str]:
        """从 prompt 条目列表中提取去重后的 tag 列表。"""
        seen = set()
        tags = []
        for p in prompts:
            for tag in p.get('tags', []):
                if tag not in seen:
                    seen.add(tag)
                    tags.append(tag)
        return tags

    def _build_session_result(self, elapsed: int, duration_sec: int) -> dict:
        """构建 session 结束结果。"""
        segment_wavs = []
        if self.lyria_client:
            segment_wavs = self.lyria_client.get_segment_wavs()

        return {
            'elapsed_sec': elapsed,
            'duration_sec': duration_sec,
            'prompt_log': self.prompt_log,
            'creative_events': self.creative_events,
            'section_log': self.section_log,
            'segment_wavs': segment_wavs,
            'steer_stats': self.steer_controller.get_stats() if self.steer_controller else {},
        }

    # === External Control ===

    def switch_section(self, section_name: str):
        """切换段落（由 UI 调用）。"""
        section_map = {
            'intro': Section.INTRO,
            'verse': Section.VERSE,
            'chorus': Section.CHORUS,
            'bridge': Section.BRIDGE,
            'outro': Section.OUTRO,
        }
        section = section_map.get(section_name)
        if section and section != self.composer.section:
            old = self.composer.section
            self.composer.set_section(section)
            self.section_log.append((time.time() - self._session_start, section_name))

            # 发布事件到 bus → 触发即时转向
            self.bus.publish('section.change', {
                'from': old.value,
                'to': section.value,
            })

            if self.socketio:
                self.socketio.emit('section_changed', {'section': section_name})

    def trigger_goal(self):
        """标记 goal 达成。"""
        self._goal_triggered = True

    # === Creative Events Logging ===

    def _on_creative_event(self, channel, value, ts):
        """记录创意事件（用于 session 后 AI polish）。"""
        if not value:
            return

        elapsed = ts - self._session_start if self._session_start else 0

        if channel == 'cadence.locked':
            anchor = self.bus.last_value('cadence.anchor', 170)
            self.creative_events.append({
                'type': 'bpm_anchor',
                'value': round(anchor),
                'section': self.composer.section.value,
                'timestamp': round(elapsed, 1),
            })
        elif channel == 'breath.hold':
            self.creative_events.append({
                'type': 'breath_hold',
                'section': self.composer.section.value,
                'timestamp': round(elapsed, 1),
            })
        elif channel == 'breath.deep':
            self.creative_events.append({
                'type': 'deep_breathing',
                'section': self.composer.section.value,
                'timestamp': round(elapsed, 1),
            })

    # === Properties ===

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def elapsed_sec(self) -> float:
        if self._session_start:
            return time.time() - self._session_start
        return 0.0
