"""
Signal Sources — BLE 信号源适配器
==================================

将 BLE GATT 回调适配为 SignalBus publish 调用。
复用 polar_state2.py 中的 parse 函数。
"""

import numpy as np
from typing import Optional

from sigbus.bus import SignalBus

# 复用现有 parse 函数
from polar_state2 import parse_hr_data, parse_acc_data, filter_rr


class BLESource:
    """BLE 信号源。将 Polar H10 的 HR/ACC BLE 回调转换为 bus 事件。

    Channels published:
        hr.raw      — 心率值 (bpm, int)
        rr.raw      — RR 间期 (ms, float)
        acc.raw     — 加速度向量 (ax, ay, az) in g
        acc.mag     — 加速度幅值 |a| - 1.0 (去重力)
    """

    def __init__(self, bus: SignalBus):
        self.bus = bus
        self._last_valid_rr: Optional[float] = None
        self._artifact_count = 0

    def hr_callback(self, _, data: bytearray):
        """BLE HR 特征值通知回调。直接注册为 BLE notify handler。"""
        hr, rrs = parse_hr_data(data)

        # 发布原始心率
        self.bus.publish('hr.raw', hr)

        # 发布有效 RR 间期
        for rr in rrs:
            if filter_rr(rr, self._last_valid_rr):
                self._last_valid_rr = rr
                self.bus.publish('rr.raw', rr)
            else:
                self._artifact_count += 1

    def acc_callback(self, _, data: bytearray):
        """BLE PMD ACC 数据通知回调。"""
        samples = parse_acc_data(data)
        if not samples:
            return

        for ax, ay, az in samples:
            # 发布原始三轴
            self.bus.publish('acc.raw', (ax, ay, az))

            # 发布去重力后的幅值
            mag = abs(np.sqrt(ax * ax + ay * ay + az * az) - 1.0)
            self.bus.publish('acc.mag', mag)

    @property
    def artifact_count(self) -> int:
        return self._artifact_count


class MockSource:
    """模拟信号源，用于 UI 测试和单元测试。

    模拟真实 BLE 数据量:
      - HR: 每秒 1 次 (BLE notify ~1Hz)
      - RR: 每秒 ~1-2 个间期
      - ACC: 每秒 200 个样本 (200Hz, 同真实 Polar H10)

    这样 CadenceProcessor 能拿到足够的 ACC 数据检测步频。
    """

    ACC_SAMPLES_PER_TICK = 200  # 真实 Polar H10 = 200Hz

    def __init__(self, bus: SignalBus):
        self.bus = bus
        self._tick = 0
        self._section = 'verse'  # 可由外部设置来模拟段落变化对 HR 的影响
        self._current_cadence_hz = 0.0    # 从静止开始，逐渐加速
        self._current_hr = 72.0          # 当前实际 HR，平滑过渡用

    @property
    def section(self):
        return self._section

    @section.setter
    def section(self, val):
        self._section = val

    def tick(self, elapsed_sec: float = 0.0, phase: str = 'running'):
        """模拟 1 秒内的全部数据（真实数据量）。

        每次调用产生:
          - 1 个 HR 值
          - 1-2 个 RR 间期
          - 200 个 ACC 样本

        Args:
            elapsed_sec: 会话已进行的秒数
            phase: 'calibration' 或 'running'
        """
        import math
        import random

        self._tick += 1

        # === HR ===
        # 目标 HR 按段落设定，实际 HR 每秒以指数平滑逼近目标
        # 真实跑步中：加速需要 15-30s 才稳定，减速更快 (~10s)
        section_target_hr = {
            'intro': 77, 'verse': 92, 'chorus': 107,
            'bridge': 117, 'outro': 82,
        }
        target_hr = section_target_hr.get(self._section, 87)

        # 指数平滑：加速慢(0.03/s ≈ 30s到位)，减速快(0.08/s ≈ 12s到位)
        if target_hr > self._current_hr:
            alpha_hr = 0.03  # 加速慢
        else:
            alpha_hr = 0.08  # 减速快
        self._current_hr += alpha_hr * (target_hr - self._current_hr)

        hr_wave = 3 * math.sin(elapsed_sec * 0.08)  # 缓慢呼吸波动
        hr = int(self._current_hr + hr_wave + random.gauss(0, 1.5))
        self.bus.publish('hr.raw', hr)

        # === RR intervals (1-2 per second) ===
        # 真实的每个心跳产生一个 RR，HR=80 → 每秒约 1.3 个 RR
        rr_count = 1 if hr < 75 else 2
        for i in range(rr_count):
            base_rr = 60000.0 / hr
            # RSA: 呼吸调制 RR (~15 bpm 呼吸)
            breath_phase = elapsed_sec + i * (base_rr / 1000.0)
            rsa = 25 * math.sin(breath_phase * 0.25 * 2 * math.pi)
            rr = base_rr + rsa + random.gauss(0, 8)
            if 300 < rr < 2000:
                self.bus.publish('rr.raw', rr)

        # === ACC (200 samples per second) ===
        # 步频渐进变化，模拟真实加速/减速过程:
        #   真实跑步加速时步频每秒上升 0.5-2 spm，不是瞬间跳变
        #   Intro/Outro: 目标 0 (走路，无稳定步频)
        #   Verse:  目标 2.78 Hz (~167 spm)
        #   Chorus: 目标 2.88 Hz (~173 spm)
        #   Bridge: 目标 2.97 Hz (~178 spm)
        SECTION_CADENCE = {
            'intro':  0.0,            # 走路 → CadenceProcessor 会因幅度小自动过滤
            'verse':  2.78,           # ~167 spm
            'chorus': 2.88,           # ~173 spm
            'bridge': 2.97,           # ~178 spm
            'outro':  0.0,            # 放松走路
        }
        target_cadence = SECTION_CADENCE.get(self._section, 2.78)

        # 步频过渡分两种情况：
        #   1. 走路→跑步 (或反之): 快速过渡 ~5-8s 到位
        #   2. 跑步中变速: 缓慢 ~20-30s，步频只变 5-10 spm
        is_currently_running = self._current_cadence_hz > 2.0
        target_is_running = target_cadence > 2.0

        if not is_currently_running and target_is_running:
            # 走路→跑步：3-4s 到位（真实只需 2-3 步）
            alpha_cad = 0.50
        elif is_currently_running and not target_is_running:
            # 跑步→走路：5-8s 减速
            alpha_cad = 0.15
        elif target_cadence > self._current_cadence_hz:
            # 跑步中加速：~15-20s 到 90% 目标（每秒上升 ~1 spm）
            alpha_cad = 0.10
        else:
            # 跑步中减速：~10-12s
            alpha_cad = 0.12
        self._current_cadence_hz += alpha_cad * (target_cadence - self._current_cadence_hz)

        # 步频低于 ~140 spm (2.3 Hz) 视为无稳定跑步节奏
        is_running = self._current_cadence_hz > 2.3

        if phase == 'running':
            for s in range(self.ACC_SAMPLES_PER_TICK):
                t = elapsed_sec + s / 200.0

                if is_running:
                    # 跑步：周期性冲击，幅度随强度增大
                    phase_main = 2 * math.pi * self._current_cadence_hz * t
                    # 幅度和步频正相关：更快=更用力
                    amplitude = 0.20 + 0.10 * (self._current_cadence_hz - 2.5)
                    amplitude = max(0.15, min(0.55, amplitude))
                    az = 1.0 + amplitude * math.sin(phase_main) + random.gauss(0, 0.03)
                    ax = 0.10 * math.sin(phase_main + 0.5) + random.gauss(0, 0.02)
                    ay = 0.05 * math.sin(phase_main * 0.5) + random.gauss(0, 0.02)
                else:
                    # 走路/静止：无规律微弱加速度
                    az = 1.0 + random.gauss(0, 0.015)
                    ax = random.gauss(0, 0.01)
                    ay = random.gauss(0, 0.01)

                mag = abs(math.sqrt(ax * ax + ay * ay + az * az) - 1.0)
                self.bus.publish('acc.mag', mag)
        else:
            # 静止/慢走 (校准、Intro、Outro) — 低幅度随机，无周期性
            for s in range(self.ACC_SAMPLES_PER_TICK):
                mag = abs(random.gauss(0, 0.008))
                self.bus.publish('acc.mag', mag)
