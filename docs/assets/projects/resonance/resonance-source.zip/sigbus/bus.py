"""
SignalBus — 轻量级反应式事件总线
================================

特性:
    - 同步 publish/subscribe，零延迟回调
    - 通配符订阅 (e.g. "hr.*")
    - 每通道 ring buffer 历史记录
    - 线程安全（threading.Lock）
"""

import time
import threading
import fnmatch
from collections import deque
from typing import Any, Callable, Optional


class SignalBus:
    """反应式信号总线。publish 时同步调用所有匹配的 subscriber。"""

    def __init__(self, history_size: int = 100):
        """
        Args:
            history_size: 每个 channel 保留的最大历史条数
        """
        self._history_size = history_size
        self._subscribers: dict[str, list[Callable]] = {}  # channel -> [callback]
        self._pattern_subscribers: list[tuple[str, Callable]] = []  # (pattern, callback)
        self._history: dict[str, deque] = {}  # channel -> deque of (timestamp, value)
        self._lock = threading.Lock()

    def publish(self, channel: str, value: Any, timestamp: float = None):
        """发布一个值到指定通道。同步调用所有匹配的 subscriber。

        Args:
            channel: 通道名 (e.g. "hr.raw", "breath.hold")
            value: 任意值
            timestamp: 时间戳，默认 time.time()
        """
        if timestamp is None:
            timestamp = time.time()

        # 存入历史
        with self._lock:
            if channel not in self._history:
                self._history[channel] = deque(maxlen=self._history_size)
            self._history[channel].append((timestamp, value))

            # 收集匹配的 callbacks
            callbacks = list(self._subscribers.get(channel, []))
            for pattern, cb in self._pattern_subscribers:
                if fnmatch.fnmatch(channel, pattern):
                    callbacks.append(cb)

        # 在锁外调用 callbacks，避免死锁
        for cb in callbacks:
            try:
                cb(channel, value, timestamp)
            except Exception as e:
                # 不让单个 subscriber 的异常中断整个 publish
                import traceback
                traceback.print_exc()

    def subscribe(self, channel: str, callback: Callable):
        """订阅精确通道。

        callback 签名: (channel: str, value: Any, timestamp: float) -> None
        """
        with self._lock:
            if channel not in self._subscribers:
                self._subscribers[channel] = []
            self._subscribers[channel].append(callback)

    def subscribe_pattern(self, pattern: str, callback: Callable):
        """通配符订阅。支持 * 和 ? 匹配。

        Example: bus.subscribe_pattern("hr.*", handler) 匹配 hr.raw, hr.smooth 等
        """
        with self._lock:
            self._pattern_subscribers.append((pattern, callback))

    def unsubscribe(self, channel: str, callback: Callable):
        """取消订阅。"""
        with self._lock:
            if channel in self._subscribers:
                try:
                    self._subscribers[channel].remove(callback)
                except ValueError:
                    pass

    def last(self, channel: str) -> Optional[tuple[float, Any]]:
        """获取通道最新一条记录。返回 (timestamp, value) 或 None。"""
        with self._lock:
            history = self._history.get(channel)
            if history and len(history) > 0:
                return history[-1]
            return None

    def last_value(self, channel: str, default=None) -> Any:
        """获取通道最新值，如果没有则返回 default。"""
        entry = self.last(channel)
        return entry[1] if entry else default

    def history(self, channel: str, duration_sec: float = None) -> list[tuple[float, Any]]:
        """获取通道历史记录。

        Args:
            channel: 通道名
            duration_sec: 只返回最近 N 秒的记录，None 则返回全部

        Returns:
            [(timestamp, value), ...] 按时间升序
        """
        with self._lock:
            history = self._history.get(channel)
            if not history:
                return []
            if duration_sec is None:
                return list(history)
            cutoff = time.time() - duration_sec
            return [(t, v) for t, v in history if t >= cutoff]

    def channels(self) -> list[str]:
        """返回所有有历史记录的通道名列表。"""
        with self._lock:
            return list(self._history.keys())

    def reset(self):
        """清除所有订阅和历史。用于测试。"""
        with self._lock:
            self._subscribers.clear()
            self._pattern_subscribers.clear()
            self._history.clear()
