"""
Signal Smoothers — 信号平滑与过渡工具
======================================

EMA           — 指数移动平均，实时平滑连续信号
Interpolator  — 参数过渡器，目标值改变时平滑渐变
RateOfChange  — 变化率检测器，超阈值时返回变化率
EventPrompt   — 事件型 Prompt 权重衰减器
"""

import time
import math
from typing import Optional
from collections import deque


class EMA:
    """指数移动平均 (Exponential Moving Average)。

    alpha 越大越跟踪最新值，越小越平滑。
    典型值: 0.2（平滑）, 0.4（中等）, 0.7（快速跟踪）
    """

    def __init__(self, alpha: float = 0.3, initial: float = None):
        self.alpha = alpha
        self._value = initial
        self._initialized = initial is not None

    @property
    def value(self) -> Optional[float]:
        return self._value

    def update(self, raw: float) -> float:
        """输入新原始值，返回平滑后的值。"""
        if not self._initialized:
            self._value = raw
            self._initialized = True
        else:
            self._value = self.alpha * raw + (1 - self.alpha) * self._value
        return self._value

    def reset(self, value: float = None):
        """重置状态。"""
        self._value = value
        self._initialized = value is not None


class Interpolator:
    """参数平滑过渡器。

    当 set_target(new_value) 被调用时，从当前值以 easing 函数
    渐变到目标值，持续 duration_sec 秒。

    用途: density, brightness, guidance 等音乐参数，避免跳变。
    """

    def __init__(self, duration_sec: float = 2.0, easing: str = 'ease_out',
                 initial: float = 0.5):
        self.duration_sec = duration_sec
        self.easing = easing
        self._current = initial
        self._start_value = initial
        self._target = initial
        self._transition_start = 0.0
        self._transitioning = False

    @property
    def target(self) -> float:
        return self._target

    def set_target(self, target: float, now: float = None):
        """设置新的目标值，开始过渡动画。"""
        if now is None:
            now = time.time()

        # 如果正在过渡中，从当前插值位置开始新过渡
        if self._transitioning:
            self._start_value = self.get(now)
        else:
            self._start_value = self._current

        self._target = target
        self._transition_start = now
        self._transitioning = True

    def get(self, now: float = None) -> float:
        """获取当前平滑值。"""
        if now is None:
            now = time.time()

        if not self._transitioning:
            return self._current

        elapsed = now - self._transition_start
        if elapsed >= self.duration_sec:
            self._current = self._target
            self._transitioning = False
            return self._current

        # 计算 progress [0, 1]
        t = elapsed / self.duration_sec
        eased_t = self._apply_easing(t)

        self._current = self._start_value + (self._target - self._start_value) * eased_t
        return self._current

    def _apply_easing(self, t: float) -> float:
        """应用 easing 函数。t ∈ [0, 1] → eased ∈ [0, 1]"""
        if self.easing == 'linear':
            return t
        elif self.easing == 'ease_out':
            # ease-out quadratic: 1 - (1-t)^2
            return 1 - (1 - t) ** 2
        elif self.easing == 'ease_in':
            # ease-in quadratic: t^2
            return t ** 2
        elif self.easing == 'ease_in_out':
            # ease-in-out: smooth step
            return t * t * (3 - 2 * t)
        else:
            return t

    @property
    def is_transitioning(self) -> bool:
        return self._transitioning


class RateOfChange:
    """变化率检测器。

    维护一个时间窗口内的值，当变化率（绝对值）超过阈值时返回变化率。
    用于检测心率急升/急降等需要立即响应的情况。
    """

    def __init__(self, threshold: float, window_sec: float = 10.0):
        """
        Args:
            threshold: 变化率阈值（单位/秒 × window_sec 内的总变化量）
            window_sec: 滑动窗口秒数
        """
        self.threshold = threshold
        self.window_sec = window_sec
        self._buffer: deque = deque()  # (timestamp, value)

    def update(self, value: float, timestamp: float = None) -> Optional[float]:
        """输入新值。如果变化率超阈值，返回变化量；否则返回 None。

        Returns:
            变化量 (signed) 或 None
        """
        if timestamp is None:
            timestamp = time.time()

        self._buffer.append((timestamp, value))

        # 清除窗口外的旧数据
        cutoff = timestamp - self.window_sec
        while self._buffer and self._buffer[0][0] < cutoff:
            self._buffer.popleft()

        if len(self._buffer) < 2:
            return None

        # 计算窗口内的总变化量 (最新 - 最旧)
        oldest_val = self._buffer[0][1]
        delta = value - oldest_val

        if abs(delta) >= self.threshold:
            return delta

        return None

    def reset(self):
        self._buffer.clear()


class DriftAccumulator:
    """漂移累计器。

    跟踪参数相对于上次 "发送" 时的累计变化量。
    当累计漂移超过阈值时返回 True 并自动重置。

    用于 SteerController 的漂移检测策略。
    """

    def __init__(self, threshold: float):
        self.threshold = threshold
        self._last_sent_value: Optional[float] = None
        self._current_value: Optional[float] = None

    def update(self, value: float) -> bool:
        """更新当前值。如果漂移超阈值返回 True。"""
        self._current_value = value

        if self._last_sent_value is None:
            self._last_sent_value = value
            return False

        drift = abs(value - self._last_sent_value)
        if drift >= self.threshold:
            return True
        return False

    def mark_sent(self):
        """标记已发送，重置漂移基准。"""
        if self._current_value is not None:
            self._last_sent_value = self._current_value

    @property
    def drift(self) -> float:
        """当前漂移量。"""
        if self._last_sent_value is None or self._current_value is None:
            return 0.0
        return abs(self._current_value - self._last_sent_value)

    def reset(self):
        self._last_sent_value = None
        self._current_value = None


class EventPrompt:
    """事件型 Prompt 权重衰减器。

    触发时以 peak_weight 注入，然后在 decay_sec 内线性衰减到 0。
    当 current_weight() <= 0 时，该事件可以被移除。
    """

    def __init__(self, text: str, peak_weight: float = 0.9,
                 decay_sec: float = 3.0, triggered_at: float = None):
        self.text = text
        self.peak_weight = peak_weight
        self.decay_sec = decay_sec
        self.triggered_at = triggered_at or time.time()

    def current_weight(self, now: float = None) -> float:
        """返回当前权重 [0, peak_weight]。"""
        if now is None:
            now = time.time()
        elapsed = now - self.triggered_at
        if elapsed >= self.decay_sec:
            return 0.0
        return self.peak_weight * (1.0 - elapsed / self.decay_sec)

    @property
    def is_expired(self) -> bool:
        return self.current_weight() <= 0.0
