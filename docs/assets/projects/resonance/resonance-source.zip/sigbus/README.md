# Resonance Signal Pipeline (`sigbus/`)

反应式信号总线架构，替代原有的轮询式处理循环。

## 架构

```
BLE Device (Polar H10)
    │
    ▼
BLESource (sources.py)        ← BLE 回调 → bus.publish()
    │
    ▼
SignalBus (bus.py)             ← pub/sub 事件总线
    │
    ├──▶ HRProcessor          → hr.smooth, hr.delta, hr.trend, hrv.rmssd
    ├──▶ CadenceProcessor     → cadence.smooth, cadence.locked
    └──▶ BreathProcessor      → breath.rate, breath.hold, breath.deep
           │
           ▼
    ┌──────────────────────────────────────────┐
    │ SteerController (steer_controller.py)     │
    │   • 事件驱动: breath.hold → 200ms 内转向  │
    │   • 漂移检测: 参数累计变化超阈值时转向     │
    │   • 兜底: 5s 无转向 → 发送当前状态         │
    └──────────────────────────────────────────┘
           │
           ▼
    PromptComposer (prompt_composer.py)
    │   • Interpolator 平滑 density/brightness/bpm
    │   • EventPrompt fade-out 衰减
    │
    ▼
    steer_queue → LyriaClient (lyria_client.py)
```

## 核心改进

| 对比项 | 旧方案 | 新方案 |
|--------|--------|--------|
| 事件响应延迟 | 1-4s (轮询) | < 300ms (事件驱动) |
| 参数过渡 | 阶梯跳变 | Interpolator 平滑 (2s ease-out) |
| 转向频率 | 固定 3s | 自适应 (事件时 200ms, 平稳时 8-10s) |
| 可测试性 | 全局单例 | 独立组件 + 单元测试 |
| 扩展性 | 改动主循环 | 新增 Processor 即可 |

## 集成到 app.py 的方式

```python
from sigbus.pipeline import SignalPipeline

# 在 start_session handler 中:
pipeline = SignalPipeline(
    socketio=socketio,
    mock=MOCK_MODE,
    style=data.get('style', 'electronic'),
    mood=data.get('mood', 'uplifting'),
    api_key=GOOGLE_API_KEY,
    max_goals=int(data.get('goals', 0)),
)

# BLE 连接后注册回调:
await client.start_notify(HR_CHAR_UUID, pipeline.source.hr_callback)
await client.start_notify(PMD_DATA, pipeline.source.acc_callback)

# 校准:
baselines = await pipeline.calibrate(duration=30)

# 运行:
pipeline.switch_section('verse')  # 初始段落
result = await pipeline.run_session(duration_sec=300)
```

## 运行测试

```bash
cd f:\resonance
python tests/test_bus.py
python tests/test_smoothers.py
python tests/test_processors.py
python tests/test_steer_controller.py
```

## 通道列表

| Channel | 来源 | 类型 | 说明 |
|---------|------|------|------|
| `hr.raw` | BLESource | int | 原始心率 bpm |
| `hr.smooth` | HRProcessor | float | EMA 平滑心率 |
| `hr.delta` | HRProcessor | float | ΔHR (smooth - baseline) |
| `hr.trend` | HRProcessor | float | 10s 内 HR 变化 |
| `hr.spike` | HRProcessor | float | HR 急变量 (超阈值时) |
| `rr.raw` | BLESource | float | RR 间期 ms |
| `hrv.rmssd` | HRProcessor | float | 30s 窗口 RMSSD |
| `acc.raw` | BLESource | tuple | (ax, ay, az) in g |
| `acc.mag` | BLESource | float | 去重力后的加速度幅值 |
| `cadence.raw` | CadenceProcessor | float | 原始步频 spm |
| `cadence.smooth` | CadenceProcessor | float | 平滑步频 |
| `cadence.locked` | CadenceProcessor | bool | 步频锁定事件 |
| `cadence.anchor` | CadenceProcessor | float | 锁定步频值 |
| `breath.rate` | BreathProcessor | float | 呼吸频率 bpm |
| `breath.confidence` | BreathProcessor | str | 'good' \| 'weak' |
| `breath.hold` | BreathProcessor | bool | 呼吸暂停事件 |
| `breath.deep` | BreathProcessor | bool | 深呼吸事件 |
| `section.change` | Pipeline | dict | 段落切换 {from, to} |
| `calibration.tick` | CalibrationManager | dict | 校准进度 |
| `calibration.complete` | CalibrationManager | dict | 校准结果 |
