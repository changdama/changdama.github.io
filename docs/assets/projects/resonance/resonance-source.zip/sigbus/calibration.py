"""
CalibrationManager — 校准阶段管理器
=====================================

在 30s 校准期内收集 HR/RR/ACC 数据，计算 baseline，
完成后发布 'calibration.complete' 事件。
"""

import time
import asyncio
import numpy as np
from typing import Optional
from collections import deque

from sigbus.bus import SignalBus
from polar_state2 import compute_rmssd


class CalibrationManager:
    """校准管理器。

    订阅 bus 收集数据，异步等待 duration 秒后计算 baseline。
    发布:
        calibration.tick     — 每秒进度 (elapsed_sec, remaining_sec)
        calibration.complete — baseline 结果 dict
    """

    def __init__(self, bus: SignalBus, duration: int = 30,
                 acc_start_delay: int = 15, socketio=None):
        """
        Args:
            bus: SignalBus 实例
            duration: 校准时长（秒）
            acc_start_delay: ACC 数据收集延迟（等传感器稳定）
            socketio: SocketIO 实例（可选，用于向 UI 发状态）
        """
        self.bus = bus
        self.duration = duration
        self.acc_start_delay = acc_start_delay
        self.socketio = socketio

        self._hr_samples: list[int] = []
        self._rr_samples: list[float] = []
        self._acc_mag_samples: list[float] = []
        self._acc_collecting = False
        self._start_time: float = 0.0
        self._completed = False

        # Baseline results
        self.hr_baseline: Optional[float] = None
        self.rmssd_baseline: Optional[float] = None
        self.acc_baseline: Optional[float] = None

    def _on_hr(self, channel, value, ts):
        if not self._completed:
            self._hr_samples.append(value)

    def _on_rr(self, channel, value, ts):
        if not self._completed:
            self._rr_samples.append(value)

    def _on_acc_mag(self, channel, value, ts):
        if self._acc_collecting and not self._completed:
            self._acc_mag_samples.append(value)

    async def run(self) -> dict:
        """运行校准阶段。阻塞直到完成。

        Returns:
            baseline dict: {hr_baseline, rmssd_baseline, acc_baseline}
        """
        self._start_time = time.time()

        # 订阅数据通道
        self.bus.subscribe('hr.raw', self._on_hr)
        self.bus.subscribe('rr.raw', self._on_rr)
        self.bus.subscribe('acc.mag', self._on_acc_mag)

        try:
            for sec in range(self.duration):
                await asyncio.sleep(1.0)
                elapsed = sec + 1

                # ACC 延迟开始收集
                if not self._acc_collecting and elapsed >= self.acc_start_delay:
                    self._acc_collecting = True

                # 发布进度
                self.bus.publish('calibration.tick', {
                    'elapsed_sec': elapsed,
                    'remaining_sec': self.duration - elapsed,
                    'hr_count': len(self._hr_samples),
                    'rr_count': len(self._rr_samples),
                    'acc_count': len(self._acc_mag_samples),
                    'acc_collecting': self._acc_collecting,
                })

                if self.socketio:
                    self.socketio.emit('calibration_tick', {
                        'hr': self._hr_samples[-1] if self._hr_samples else None,
                        'rr_count': len(self._rr_samples),
                        'acc_samples': len(self._acc_mag_samples),
                        'elapsed': elapsed,
                        'remaining': self.duration - elapsed,
                        'status': 'Collecting baseline data...',
                    })
        finally:
            # 取消订阅
            self.bus.unsubscribe('hr.raw', self._on_hr)
            self.bus.unsubscribe('rr.raw', self._on_rr)
            self.bus.unsubscribe('acc.mag', self._on_acc_mag)

        # 计算 baseline
        self._completed = True
        result = self._compute_baselines()

        # 发布完成事件
        self.bus.publish('calibration.complete', result)

        if self.socketio:
            self.socketio.emit('calibration_complete', result)

        return result

    def _compute_baselines(self) -> dict:
        """计算所有 baseline。"""
        # HR baseline
        if len(self._hr_samples) >= 10:
            self.hr_baseline = float(np.median(self._hr_samples))
        else:
            self.hr_baseline = 72.0  # fallback

        # HRV (RMSSD) baseline
        if len(self._rr_samples) >= 10:
            self.rmssd_baseline = compute_rmssd(self._rr_samples)
        else:
            self.rmssd_baseline = 40.0  # fallback

        # ACC baseline (stationary RMS)
        if len(self._acc_mag_samples) >= 50:
            arr = np.array(self._acc_mag_samples)
            self.acc_baseline = float(np.sqrt(np.mean(arr ** 2)))
        else:
            self.acc_baseline = None

        return {
            'hr_baseline': self.hr_baseline,
            'rmssd_baseline': self.rmssd_baseline,
            'acc_baseline': self.acc_baseline,
            'hr_samples': len(self._hr_samples),
            'rr_samples': len(self._rr_samples),
            'acc_samples': len(self._acc_mag_samples),
        }
