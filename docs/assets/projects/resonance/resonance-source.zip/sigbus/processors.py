"""
Signal Processors — 信号处理器
================================

每个 Processor 订阅 bus 的原始通道，内部维护 buffer 和状态，
处理后发布到新通道。所有算法复用 polar_state2.py 的核心实现。

HRProcessor      — 心率平滑 + ΔHR + 趋势 + HRV(RMSSD)
CadenceProcessor — 步频检测 + 锁定事件
BreathProcessor  — RSA 呼吸频率 + 呼吸暂停/深呼吸事件
"""

import time
import numpy as np
from collections import deque
from typing import Optional

from sigbus.bus import SignalBus
from sigbus.smoothers import EMA, RateOfChange


# === Constants ===

ACC_SAMPLE_RATE = 200  # Polar H10 ACC sampling rate


class HRProcessor:
    """心率信号处理器。

    订阅: hr.raw, rr.raw
    发布:
        hr.smooth       — EMA 平滑心率 (float)
        hr.delta        — ΔHR = hr.smooth - baseline (float)
        hr.trend        — 10s 内 HR 变化 (float)
        hr.spike        — HR 急变事件 (|ΔHR/10s| > 15)
        hrv.rmssd       — 实时 RMSSD (float, 30s 窗口)
    """

    def __init__(self, bus: SignalBus, hr_baseline: float = 72.0,
                 rmssd_baseline: float = 40.0):
        self.bus = bus
        self.hr_baseline = hr_baseline
        self.rmssd_baseline = rmssd_baseline

        # Smoothers
        self._hr_ema = EMA(alpha=0.3)
        self._hr_roc = RateOfChange(threshold=15.0, window_sec=10.0)

        # RR buffer for RMSSD (30s window)
        self._rr_buffer: deque = deque(maxlen=120)

        # HR history for trend
        self._hr_history: deque = deque(maxlen=60)  # (timestamp, hr)

        # Subscribe
        bus.subscribe('hr.raw', self._on_hr)
        bus.subscribe('rr.raw', self._on_rr)

        # Track last RMSSD computation time (compute every 2s, not every RR)
        self._last_rmssd_time = 0.0

    def set_baselines(self, hr_baseline: float, rmssd_baseline: float):
        """设置校准后的 baseline（通常在 calibration.complete 之后调用）。"""
        self.hr_baseline = hr_baseline
        self.rmssd_baseline = rmssd_baseline

    def _on_hr(self, channel, value, ts):
        """处理原始 HR。"""
        hr = float(value)

        # EMA 平滑
        smooth_hr = self._hr_ema.update(hr)
        self.bus.publish('hr.smooth', smooth_hr, ts)

        # ΔHR
        delta_hr = smooth_hr - self.hr_baseline
        self.bus.publish('hr.delta', delta_hr, ts)

        # HR 趋势 (10s)
        self._hr_history.append((ts, smooth_hr))
        trend = self._compute_trend(ts)
        if trend is not None:
            self.bus.publish('hr.trend', trend, ts)

        # HR 急变检测
        spike = self._hr_roc.update(smooth_hr, ts)
        if spike is not None:
            self.bus.publish('hr.spike', spike, ts)

    def _on_rr(self, channel, value, ts):
        """处理原始 RR 间期。"""
        self._rr_buffer.append((ts, value))

        # 每 2s 计算一次 RMSSD（避免过于频繁）
        if ts - self._last_rmssd_time >= 2.0:
            self._last_rmssd_time = ts
            rmssd = self._compute_rmssd(ts)
            if rmssd is not None:
                self.bus.publish('hrv.rmssd', rmssd, ts)

    def _compute_trend(self, now: float) -> Optional[float]:
        """计算最近 10s 的 HR 变化量。"""
        if len(self._hr_history) < 3:
            return None
        cutoff = now - 10.0
        recent = [(t, hr) for t, hr in self._hr_history if t >= cutoff]
        if len(recent) < 2:
            return None
        return recent[-1][1] - recent[0][1]

    def _compute_rmssd(self, now: float) -> Optional[float]:
        """计算最近 30s 的 RMSSD。"""
        cutoff = now - 30.0
        valid = [rr for t, rr in self._rr_buffer if t >= cutoff]
        if len(valid) < 10:
            return None
        diffs = np.diff(np.array(valid))
        return float(np.sqrt(np.mean(diffs ** 2)))


class CadenceProcessor:
    """步频信号处理器。

    订阅: acc.mag
    发布:
        cadence.raw     — 原始步频估计 (spm)
        cadence.smooth  — 平滑步频 (spm)
        cadence.locked  — 步频锁定事件 (bool)
    """

    def __init__(self, bus: SignalBus, acc_baseline: float = None):
        self.bus = bus
        self.acc_baseline = acc_baseline

        # ACC buffer (5s at 200Hz)
        self._mag_buffer: deque = deque(maxlen=1000)

        # Cadence smoothing
        self._cadence_ema = EMA(alpha=0.25)
        self._cadence_history: deque = deque(maxlen=15)
        self._cadence_locked = False
        self._cadence_lock_start: Optional[float] = None
        self._bpm_anchor: Optional[float] = None

        # Rate limiting: compute cadence every 50 ACC samples (~0.25s)
        self._sample_count = 0
        self._last_compute_time = 0.0
        self._last_detection_time: float = 0.0  # 上次成功检测步频的时间
        self._cadence_lost = False  # 步频已丢失（发过 None）

        bus.subscribe('acc.mag', self._on_acc_mag)

    def set_baseline(self, acc_baseline: float):
        self.acc_baseline = acc_baseline

    def _on_acc_mag(self, channel, value, ts):
        """收集 ACC 幅值，定期计算步频。"""
        self._mag_buffer.append(value)
        self._sample_count += 1

        # 每 200 samples (~1s) 计算一次步频
        if self._sample_count % 200 == 0:
            self._compute_cadence(ts)

    def _compute_cadence(self, ts: float):
        """自相关步频检测。"""
        if len(self._mag_buffer) < 600:
            return

        signal = np.array(list(self._mag_buffer))[-800:]

        # 运动门控: ACC 能量需要显著高于静止基线
        if self.acc_baseline is not None:
            current_rms = float(np.sqrt(np.mean(signal ** 2)))
            ratio = current_rms / (self.acc_baseline + 1e-6)
            if ratio < 3.0:
                self._handle_no_detection(ts)
                return

        signal = signal - np.mean(signal)

        # 自相关
        n = len(signal)
        corr = np.correlate(signal, signal, mode='full')
        corr = corr[n - 1:]
        corr = corr / (corr[0] + 1e-10)

        # 搜索 0.25s-0.6s 延迟 (100-240 spm)
        min_lag = int(0.25 * ACC_SAMPLE_RATE)
        max_lag = int(0.60 * ACC_SAMPLE_RATE)
        if max_lag >= len(corr):
            return

        search = corr[min_lag:max_lag + 1]
        if len(search) == 0:
            return

        peak_idx = np.argmax(search)
        peak_val = search[peak_idx]

        # 置信度门控
        if peak_val < 0.35:
            self._handle_no_detection(ts)
            return

        period_samples = min_lag + peak_idx
        period_sec = period_samples / ACC_SAMPLE_RATE
        cadence_spm = 60.0 / period_sec

        if cadence_spm < 100 or cadence_spm > 210:
            return

        # 跳变过滤：防止 0→240 类误判
        # 但允许正常的加速/减速（每秒最多变 ~2-3 spm，4秒检测间隔 → 允许 ±15 spm）
        if len(self._cadence_history) >= 3:
            last_valid = self._cadence_history[-1]
            if last_valid and abs(cadence_spm - last_valid) > 35:
                return

        # 成功检测 → 重置超时
        self._last_detection_time = ts
        self._cadence_lost = False

        # 发布原始步频
        self.bus.publish('cadence.raw', cadence_spm, ts)

        # EMA 平滑
        smooth_cadence = self._cadence_ema.update(cadence_spm)
        self.bus.publish('cadence.smooth', smooth_cadence, ts)

        # 步频锁定检测
        self._cadence_history.append(smooth_cadence)
        self._check_cadence_lock(ts)

    def _check_cadence_lock(self, ts: float):
        """检测步频是否稳定 10s+。"""
        if len(self._cadence_history) < 10:
            if self._cadence_locked:
                self._cadence_locked = False
                self.bus.publish('cadence.locked', False, ts)
            return

        recent = list(self._cadence_history)[-10:]
        values = [c for c in recent if c is not None]
        if len(values) < 8:
            if self._cadence_locked:
                self._cadence_locked = False
                self.bus.publish('cadence.locked', False, ts)
            return

        arr = np.array(values)
        cv = float(np.std(arr) / (np.mean(arr) + 1e-6))

        if cv < 0.05:  # < 5% 变异 = 稳定
            if not self._cadence_locked:
                self._cadence_locked = True
                self._cadence_lock_start = ts
                self._bpm_anchor = float(np.median(arr))
                self.bus.publish('cadence.locked', True, ts)
                self.bus.publish('cadence.anchor', self._bpm_anchor, ts)
        else:
            if self._cadence_locked:
                self._cadence_locked = False
                self._cadence_lock_start = None
                self.bus.publish('cadence.locked', False, ts)

    def _handle_no_detection(self, ts: float):
        """连续无法检测步频时，超时后清除步频状态。"""
        if self._cadence_lost:
            return  # 已经发过丢失信号

        # 首次无检测 → 记录时间（如果之前有过检测的话）
        if self._last_detection_time == 0:
            return  # 从未检测到过，不需要清除

        silence_duration = ts - self._last_detection_time
        if silence_duration >= 3.0:
            # 3秒无步频 → 宣告丢失
            self._cadence_lost = True
            self._cadence_history.clear()
            self._cadence_ema = EMA(alpha=0.25)  # 重置 EMA
            self.bus.publish('cadence.smooth', None, ts)
            if self._cadence_locked:
                self._cadence_locked = False
                self._cadence_lock_start = None
                self.bus.publish('cadence.locked', False, ts)

    @property
    def is_locked(self) -> bool:
        return self._cadence_locked

    @property
    def bpm_anchor(self) -> Optional[float]:
        return self._bpm_anchor


class BreathProcessor:
    """呼吸信号处理器。

    订阅: rr.raw
    发布:
        breath.rate     — 呼吸频率 (bpm, float)
        breath.hold     — 呼吸暂停事件 (True)
        breath.deep     — 深呼吸事件 (True)
        breath.confidence — 呼吸检测置信度 ('good' | 'weak')
    """

    def __init__(self, bus: SignalBus):
        self.bus = bus

        # RR buffer for FFT (60s)
        self._rr_buffer: deque = deque(maxlen=240)

        # Breath rate state
        self._breath_rate: Optional[float] = None
        self._breath_confidence: Optional[str] = None
        self._breath_history: deque = deque(maxlen=30)

        # Breath-hold detection
        self._hold_start: Optional[float] = None
        self._hold_detected = False

        # Deep breath detection
        self._deep_breath_detected = False

        # Rate limiting
        self._last_fft_time = 0.0
        self._last_hold_check = 0.0
        self._last_deep_check = 0.0

        bus.subscribe('rr.raw', self._on_rr)

    def _on_rr(self, channel, value, ts):
        """处理 RR 间期。"""
        self._rr_buffer.append((ts, value))

        # FFT 呼吸频率 (每 5s)
        if ts - self._last_fft_time >= 5.0:
            self._last_fft_time = ts
            self._estimate_breath_rate(ts)

        # 呼吸暂停检测 (每 1s)
        if ts - self._last_hold_check >= 1.0:
            self._last_hold_check = ts
            self._detect_breath_hold(ts)

        # 深呼吸检测 (每 2s)
        if ts - self._last_deep_check >= 2.0:
            self._last_deep_check = ts
            self._detect_deep_breath(ts)

    def _estimate_breath_rate(self, now: float):
        """RSA FFT 呼吸频率估计。"""
        cutoff = now - 60.0
        recent = [(t, rr) for t, rr in self._rr_buffer if t >= cutoff]

        if len(recent) < 30:
            return

        timestamps = np.array([t for t, _ in recent])
        rr_values = np.array([rr for _, rr in recent])

        # RR 变异性太低则无法检测 RSA
        rr_std = float(np.std(rr_values))
        if rr_std < 8.0:
            return

        # 插值到均匀 4Hz 时间序列
        fs = 4.0
        t_start, t_end = timestamps[0], timestamps[-1]
        duration = t_end - t_start
        if duration < 20.0:
            return

        t_uniform = np.arange(t_start, t_end, 1.0 / fs)
        if len(t_uniform) < 80:
            return

        rr_interp = np.interp(t_uniform, timestamps, rr_values)

        # 去 DC + 去趋势
        rr_interp = rr_interp - np.mean(rr_interp)
        x = np.arange(len(rr_interp))
        slope = np.polyfit(x, rr_interp, 1)[0]
        rr_interp = rr_interp - slope * x

        # Hann 窗 + FFT
        window = np.hanning(len(rr_interp))
        rr_windowed = rr_interp * window

        n = len(rr_windowed)
        fft_vals = np.abs(np.fft.rfft(rr_windowed))
        freqs = np.fft.rfftfreq(n, d=1.0 / fs)

        # 呼吸频带: 0.15-0.5 Hz (9-30 bpm)
        mask = (freqs >= 0.15) & (freqs <= 0.5)
        if not np.any(mask):
            return

        band_fft = fft_vals[mask]
        band_freqs = freqs[mask]

        peak_idx = int(np.argmax(band_fft))
        peak_power = band_fft[peak_idx]
        band_mean = float(np.mean(band_fft))

        ratio = peak_power / (band_mean + 1e-10)
        if ratio < 2.5:
            return

        breath_freq = band_freqs[peak_idx]
        breath_rate = float(breath_freq * 60.0)

        confidence = "good" if ratio > 4.0 else "weak"

        # 跳变过滤
        if self._breath_rate is not None:
            ratio_to_prev = breath_rate / (self._breath_rate + 1e-6)
            if ratio_to_prev > 2.2 or ratio_to_prev < 0.45:
                return  # 谐波跳变，忽略

        self._breath_rate = breath_rate
        self._breath_confidence = confidence
        self._breath_history.append(breath_rate)

        self.bus.publish('breath.rate', breath_rate, now)
        self.bus.publish('breath.confidence', confidence, now)

    def _detect_breath_hold(self, now: float):
        """呼吸暂停检测: RR 变异性极低 (SD < 5ms, 10s 窗口)。"""
        recent = [(t, rr) for t, rr in self._rr_buffer if now - t <= 10.0]
        if len(recent) < 8:
            if self._hold_detected:
                self._hold_detected = False
                self.bus.publish('breath.hold', False, now)
            return

        rr_vals = np.array([rr for _, rr in recent])
        rr_sd = float(np.std(rr_vals))

        if rr_sd < 5.0:
            if self._hold_start is None:
                self._hold_start = now
            hold_duration = now - self._hold_start
            if hold_duration >= 5.0 and not self._hold_detected:
                self._hold_detected = True
                self.bus.publish('breath.hold', True, now)
        else:
            if self._hold_detected:
                self._hold_detected = False
                self.bus.publish('breath.hold', False, now)
            self._hold_start = None

    def _detect_deep_breath(self, now: float):
        """深呼吸检测: 短窗口 RR 振幅显著高于长窗口基线。"""
        # 短窗口 (15s)
        short_rr = [rr for t, rr in self._rr_buffer if now - t <= 15.0]
        if len(short_rr) < 10:
            if self._deep_breath_detected:
                self._deep_breath_detected = False
                self.bus.publish('breath.deep', False, now)
            return

        # 长窗口 (60s)
        long_rr = [rr for t, rr in self._rr_buffer if now - t <= 60.0]
        if len(long_rr) < 20:
            return

        short_sd = float(np.std(short_rr))
        long_sd = float(np.std(long_rr))
        short_range = float(np.max(short_rr) - np.min(short_rr))

        if long_sd < 5.0:
            return

        ratio = short_sd / (long_sd + 1e-6)

        if ratio > 1.8 and short_range > 40.0:
            if not self._deep_breath_detected:
                self._deep_breath_detected = True
                self.bus.publish('breath.deep', True, now)
        else:
            if self._deep_breath_detected:
                self._deep_breath_detected = False
                self.bus.publish('breath.deep', False, now)

    @property
    def breath_rate(self) -> Optional[float]:
        return self._breath_rate

    @property
    def is_holding(self) -> bool:
        return self._hold_detected

    @property
    def is_deep_breathing(self) -> bool:
        return self._deep_breath_detected
