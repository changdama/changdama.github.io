"""
SteerController — Lyria 转向控制器
=====================================

事件驱动优先 + 漂移检测 + 定时兜底。

策略:
    1. 高优先级事件 (breath.hold, breath.deep, cadence.locked, section.change)
       → 200ms batch window 后立即转向
    2. 连续参数漂移 (hr.smooth, hrv.rmssd, cadence.smooth, breath.rate)
       → 累计变化超阈值时触发转向
    3. 兜底: 5s 无转向 → 发送当前平滑状态

去抖:
    - 200ms batch window: 同时发生的多个事件合并为一次转向
    - 语义去重: 如果 compose() 结果与上次相同则跳过
    - 最小间隔: 两次转向之间最少 500ms
"""

import time
import asyncio
import hashlib
import json
from typing import Optional

from sigbus.bus import SignalBus
from sigbus.smoothers import DriftAccumulator
from sigbus.prompt_composer import PromptComposer


# 漂移阈值
DRIFT_THRESHOLDS = {
    'hr.smooth': 8.0,       # ±8 bpm
    'hrv.rmssd': 15.0,      # ±15 ms
    'cadence.smooth': 10.0, # ±10 spm
    'breath.rate': 3.0,     # ±3 bpm
}

# 转向控制参数
BATCH_WINDOW_SEC = 0.2      # 200ms 事件合并窗口
MIN_STEER_INTERVAL = 0.5    # 最小转向间隔
FALLBACK_INTERVAL = 5.0     # 兜底转向间隔
KEEPALIVE_INTERVAL = 15.0   # WebSocket 保活间隔（防断连）

# 高优先级事件通道
URGENT_CHANNELS = ['breath.hold', 'breath.deep', 'cadence.locked', 'section.change']


class SteerController:
    """Lyria 转向控制器。

    核心职责:
        - 决定 "何时" 向 Lyria 发送转向指令
        - 调用 PromptComposer.compose() 获取 "发什么"
        - 将结果放入 steer_queue 供 LyriaClient 消费
    """

    def __init__(self, bus: SignalBus, composer: PromptComposer,
                 steer_queue: asyncio.Queue, loop: asyncio.AbstractEventLoop = None):
        self.bus = bus
        self.composer = composer
        self.steer_queue = steer_queue
        self._loop = loop

        # Timing
        self._last_steer_time: float = 0.0
        self._batch_pending = False
        self._batch_timer: Optional[asyncio.TimerHandle] = None
        self._stop_requested = False

        # 语义去重
        self._last_sent_hash: Optional[str] = None

        # 漂移累计器
        self._drift_accumulators: dict[str, DriftAccumulator] = {}
        for channel, threshold in DRIFT_THRESHOLDS.items():
            self._drift_accumulators[channel] = DriftAccumulator(threshold)

        # 统计
        self.steer_count = 0
        self.event_steer_count = 0
        self.drift_steer_count = 0
        self.fallback_steer_count = 0
        self.keepalive_steer_count = 0

        # 订阅高优事件
        for ch in URGENT_CHANNELS:
            bus.subscribe(ch, self._on_urgent_event)

        # 订阅连续参数（漂移检测）
        for ch in DRIFT_THRESHOLDS.keys():
            bus.subscribe(ch, self._on_param_update)

    def start(self, loop: asyncio.AbstractEventLoop = None):
        """启动兜底定时器。必须在 asyncio 事件循环中调用。"""
        if loop:
            self._loop = loop
        if self._loop is None:
            self._loop = asyncio.get_event_loop()

        # 立即发送第一次转向（消除启动空隙）
        self._do_steer('event')

        # 启动兜底+保活协程
        self._loop.create_task(self._fallback_loop())

    async def _fallback_loop(self):
        """兜底 + 保活循环。

        两个职责:
          1. 5s 无转向 → 发送当前状态（音乐方向更新）
          2. 15s 无转向 → 强制发送（即使 hash 相同，防止 WebSocket 超时断连）
        """
        while not self._stop_requested:
            await asyncio.sleep(1.0)
            now = time.time()
            silence_duration = now - self._last_steer_time

            if silence_duration >= KEEPALIVE_INTERVAL:
                # 超过 15s 无通信 → 强制发送保活（忽略语义去重）
                self._do_steer('keepalive')
            elif silence_duration >= FALLBACK_INTERVAL:
                # 超过 5s → 正常兜底（有语义去重）
                self._do_steer('fallback')

    def _on_urgent_event(self, channel, value, ts):
        """高优事件回调: 启动 batch window。"""
        # 只在事件为 "触发" 时响应（值为 True 或非空）
        if not value:
            return
        self._schedule_batch_steer()

    def _on_param_update(self, channel, value, ts):
        """连续参数回调: 漂移检测。"""
        if channel not in self._drift_accumulators:
            return

        acc = self._drift_accumulators[channel]
        if isinstance(value, (int, float)):
            triggered = acc.update(float(value))
            if triggered:
                self._schedule_batch_steer()

    def _schedule_batch_steer(self):
        """调度一次 batch 转向（200ms 窗口内的事件合并）。"""
        if self._batch_pending:
            return  # 已经有 pending batch

        self._batch_pending = True

        if self._loop:
            self._loop.call_later(BATCH_WINDOW_SEC, self._fire_batch)
        else:
            # 无 event loop 时直接触发
            self._fire_batch()

    def _fire_batch(self):
        """Batch 窗口结束，执行转向。"""
        self._batch_pending = False

        # 最小间隔检查
        now = time.time()
        if now - self._last_steer_time < MIN_STEER_INTERVAL:
            return

        self._do_steer('event')

    def _do_steer(self, trigger: str):
        """执行一次转向。

        Args:
            trigger: 触发原因 ('event', 'drift', 'fallback', 'keepalive')
        """
        now = time.time()
        prompts, config = self.composer.compose(now)

        # 语义去重（keepalive 和 event 不去重，fallback 去重）
        content_hash = self._hash_steer(prompts, config)
        if content_hash == self._last_sent_hash and trigger == 'fallback':
            return  # 兜底时如果内容相同则跳过（但 keepalive 不跳过）

        # 放入队列
        try:
            self.steer_queue.put_nowait({
                'prompts': prompts,
                'config': config,
                'trigger': trigger,
                'timestamp': now,
            })
        except asyncio.QueueFull:
            # 队列满时丢弃最旧的
            try:
                self.steer_queue.get_nowait()
                self.steer_queue.put_nowait({
                    'prompts': prompts,
                    'config': config,
                    'trigger': trigger,
                    'timestamp': now,
                })
            except (asyncio.QueueEmpty, asyncio.QueueFull):
                pass

        # 更新状态
        self._last_steer_time = now
        self._last_sent_hash = content_hash
        self.steer_count += 1

        if trigger == 'event':
            self.event_steer_count += 1
        elif trigger == 'drift':
            self.drift_steer_count += 1
        elif trigger == 'keepalive':
            self.keepalive_steer_count += 1
        else:
            self.fallback_steer_count += 1

        # 重置所有漂移累计器
        for acc in self._drift_accumulators.values():
            acc.mark_sent()

    def _hash_steer(self, prompts: list[dict], config: dict) -> str:
        """计算转向内容的哈希，用于去重。

        注意：只对比 prompt text 和 config 的关键参数（忽略小数变化）。
        """
        # 粗粒度: prompt texts + config 的整数值
        key_parts = []
        for p in prompts:
            key_parts.append(p.get('text', ''))
        cfg = config.get('music_generation_config', {})
        key_parts.append(cfg.get('bpm', ''))
        key_parts.append(cfg.get('guidance', ''))
        # density/brightness 保留 1 位小数
        key_parts.append(f"{float(cfg.get('density', 0)):.1f}")
        key_parts.append(f"{float(cfg.get('brightness', 0)):.1f}")

        content = '|'.join(key_parts)
        return hashlib.md5(content.encode()).hexdigest()[:8]

    def force_steer(self):
        """外部强制转向（如 section 切换时由 app.py 调用）。"""
        self._do_steer('event')

    def stop(self):
        """停止控制器。"""
        self._stop_requested = True

    def get_stats(self) -> dict:
        """返回转向统计。"""
        return {
            'total_steers': self.steer_count,
            'event_steers': self.event_steer_count,
            'drift_steers': self.drift_steer_count,
            'fallback_steers': self.fallback_steer_count,
            'keepalive_steers': self.keepalive_steer_count,
            'last_steer_age': time.time() - self._last_steer_time if self._last_steer_time else None,
        }
