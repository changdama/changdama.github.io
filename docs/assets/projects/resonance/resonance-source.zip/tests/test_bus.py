"""SignalBus 单元测试。"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import time
import threading
from sigbus.bus import SignalBus


def test_basic_publish_subscribe():
    """基本 pub/sub 功能。"""
    bus = SignalBus()
    received = []

    def handler(ch, val, ts):
        received.append((ch, val))

    bus.subscribe('hr.raw', handler)
    bus.publish('hr.raw', 72)
    bus.publish('hr.raw', 75)

    assert len(received) == 2
    assert received[0] == ('hr.raw', 72)
    assert received[1] == ('hr.raw', 75)


def test_multiple_subscribers():
    """多个 subscriber 都会收到。"""
    bus = SignalBus()
    r1, r2 = [], []

    bus.subscribe('hr.raw', lambda ch, v, ts: r1.append(v))
    bus.subscribe('hr.raw', lambda ch, v, ts: r2.append(v))
    bus.publish('hr.raw', 80)

    assert r1 == [80]
    assert r2 == [80]


def test_pattern_subscribe():
    """通配符订阅。"""
    bus = SignalBus()
    received = []

    bus.subscribe_pattern('hr.*', lambda ch, v, ts: received.append((ch, v)))
    bus.publish('hr.raw', 72)
    bus.publish('hr.smooth', 73.5)
    bus.publish('acc.raw', (0, 0, 1))  # 不匹配

    assert len(received) == 2
    assert received[0] == ('hr.raw', 72)
    assert received[1] == ('hr.smooth', 73.5)


def test_history():
    """历史记录查询。"""
    bus = SignalBus(history_size=5)

    for i in range(10):
        bus.publish('hr.raw', 70 + i)

    history = bus.history('hr.raw')
    assert len(history) == 5  # maxlen=5
    assert history[-1][1] == 79  # 最后一个


def test_last():
    """获取最新值。"""
    bus = SignalBus()
    assert bus.last('hr.raw') is None

    bus.publish('hr.raw', 72)
    bus.publish('hr.raw', 75)

    ts, val = bus.last('hr.raw')
    assert val == 75


def test_last_value():
    """last_value 便捷方法。"""
    bus = SignalBus()
    assert bus.last_value('hr.raw', default=60) == 60

    bus.publish('hr.raw', 72)
    assert bus.last_value('hr.raw') == 72


def test_unsubscribe():
    """取消订阅。"""
    bus = SignalBus()
    received = []

    def handler(ch, v, ts):
        received.append(v)

    bus.subscribe('hr.raw', handler)
    bus.publish('hr.raw', 72)
    bus.unsubscribe('hr.raw', handler)
    bus.publish('hr.raw', 75)

    assert received == [72]


def test_subscriber_exception_isolation():
    """单个 subscriber 异常不影响其他。"""
    bus = SignalBus()
    received = []

    def bad_handler(ch, v, ts):
        raise ValueError("boom")

    def good_handler(ch, v, ts):
        received.append(v)

    bus.subscribe('hr.raw', bad_handler)
    bus.subscribe('hr.raw', good_handler)
    bus.publish('hr.raw', 72)

    assert received == [72]  # good_handler 仍然收到


def test_thread_safety():
    """多线程并发 publish 不崩溃。"""
    bus = SignalBus()
    count = [0]

    def handler(ch, v, ts):
        count[0] += 1

    bus.subscribe('test', handler)

    def publisher():
        for i in range(100):
            bus.publish('test', i)

    threads = [threading.Thread(target=publisher) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert count[0] == 500


def test_channels():
    """列出所有活跃通道。"""
    bus = SignalBus()
    bus.publish('hr.raw', 72)
    bus.publish('acc.mag', 0.5)
    bus.publish('breath.rate', 14.0)

    channels = bus.channels()
    assert set(channels) == {'hr.raw', 'acc.mag', 'breath.rate'}


def test_reset():
    """reset 清除所有订阅和历史。"""
    bus = SignalBus()
    received = []
    bus.subscribe('hr.raw', lambda ch, v, ts: received.append(v))
    bus.publish('hr.raw', 72)
    bus.reset()

    # 订阅已清除
    bus.publish('hr.raw', 80)  # 无 subscriber 了，但 history 会记录
    assert received == [72]

    # 旧 history 已清除，但新 publish 会创建新 history
    # reset 后立刻查 channels 应为空
    bus2 = SignalBus()
    bus2.publish('x', 1)
    assert bus2.channels() == ['x']
    bus2.reset()
    assert bus2.channels() == []


if __name__ == '__main__':
    test_basic_publish_subscribe()
    test_multiple_subscribers()
    test_pattern_subscribe()
    test_history()
    test_last()
    test_last_value()
    test_unsubscribe()
    test_subscriber_exception_isolation()
    test_thread_safety()
    test_channels()
    test_reset()
    print("[PASS] All bus tests passed")
