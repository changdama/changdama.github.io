"""Processors 单元测试。"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import time
import numpy as np
from sigbus.bus import SignalBus
from sigbus.processors import HRProcessor, CadenceProcessor, BreathProcessor


def test_hr_processor_smooth():
    """HRProcessor 输出平滑 HR。"""
    bus = SignalBus()
    received = []

    bus.subscribe('hr.smooth', lambda ch, v, ts: received.append(v))
    proc = HRProcessor(bus, hr_baseline=72.0)

    # 发送几个原始 HR
    bus.publish('hr.raw', 80, 1.0)
    bus.publish('hr.raw', 85, 2.0)
    bus.publish('hr.raw', 90, 3.0)

    assert len(received) == 3
    # EMA 平滑: 不会直接跳到 90
    assert received[0] == 80.0  # 第一个直接采用
    assert received[1] < 85.0  # EMA 平滑
    assert received[2] < 90.0


def test_hr_processor_delta():
    """HRProcessor 计算 ΔHR。"""
    bus = SignalBus()
    deltas = []

    bus.subscribe('hr.delta', lambda ch, v, ts: deltas.append(v))
    proc = HRProcessor(bus, hr_baseline=70.0)

    bus.publish('hr.raw', 80, 1.0)

    assert len(deltas) == 1
    assert deltas[0] == 10.0  # 80 - 70


def test_hr_processor_spike():
    """HRProcessor 检测 HR 急变事件。"""
    bus = SignalBus()
    spikes = []

    bus.subscribe('hr.spike', lambda ch, v, ts: spikes.append(v))
    proc = HRProcessor(bus, hr_baseline=70.0)

    # 模拟急剧上升 (> 15 bpm / 10s)
    # EMA(0.3) 平滑，需要原始值变化足够大才能让平滑值超过阈值
    for i in range(15):
        bus.publish('hr.raw', 70 + i * 4, float(i))  # +4/s raw → EMA 跟踪幅度 > 15

    # 应该检测到 spike
    assert len(spikes) > 0


def test_hr_processor_rmssd():
    """HRProcessor 计算 RMSSD。"""
    bus = SignalBus()
    rmssd_vals = []

    bus.subscribe('hrv.rmssd', lambda ch, v, ts: rmssd_vals.append(v))
    proc = HRProcessor(bus, hr_baseline=70.0)

    # 发送足够的 RR 数据 (需要 10+ 在 30s 窗口内)
    base_time = time.time()
    for i in range(20):
        rr = 800 + np.random.randn() * 30  # ~800ms ± 30ms
        bus.publish('rr.raw', rr, base_time + i * 0.8)

    # RMSSD 应该被计算出来（每 2s 一次）
    # 由于我们发了 20 个 RR，间隔 0.8s 总共 16s，应该有几次计算
    assert len(rmssd_vals) > 0
    assert all(v > 0 for v in rmssd_vals)


def test_cadence_processor_lock():
    """CadenceProcessor 步频锁定检测。"""
    bus = SignalBus()
    lock_events = []

    bus.subscribe('cadence.locked', lambda ch, v, ts: lock_events.append(v))
    proc = CadenceProcessor(bus, acc_baseline=0.01)

    # 直接模拟发布 cadence (绕过 ACC)
    # 通过连续发布稳定的 cadence 值来测试锁定逻辑
    for i in range(15):
        # 模拟稳定步频 170±2 spm
        cadence = 170 + np.random.uniform(-1, 1)
        proc._cadence_ema.update(cadence)
        proc._cadence_history.append(cadence)

    proc._check_cadence_lock(time.time())

    # 应该检测到 lock (CV < 5%)
    assert len(lock_events) > 0
    assert lock_events[-1] == True


def test_breath_processor_hold_detection():
    """BreathProcessor 呼吸暂停检测。"""
    bus = SignalBus()
    hold_events = []

    bus.subscribe('breath.hold', lambda ch, v, ts: hold_events.append(v))
    proc = BreathProcessor(bus)

    # 模拟极其稳定的 RR (呼吸暂停特征: SD < 5ms)
    base_time = time.time()
    for i in range(20):
        rr = 800 + np.random.uniform(-1, 1)  # SD ≈ 0.58ms (< 5ms)
        bus.publish('rr.raw', rr, base_time + i * 0.5)

    # 等待足够时间让 hold 检测触发 (需 5s 持续)
    # 由于 _detect_breath_hold 每 1s 检查一次
    # 手动触发检测
    proc._detect_breath_hold(base_time + 10.0)

    assert len(hold_events) > 0
    assert True in hold_events


def test_breath_processor_deep_breath():
    """BreathProcessor 深呼吸检测。"""
    bus = SignalBus()
    deep_events = []

    bus.subscribe('breath.deep', lambda ch, v, ts: deep_events.append(v))
    proc = BreathProcessor(bus)

    base_time = time.time()

    # 先建立 60s 基线 (正常呼吸, SD ~10ms — 小振幅)
    for i in range(80):
        rr = 800 + 10 * np.sin(i * 0.5)
        proc._rr_buffer.append((base_time + i * 0.75, rr))

    # 然后模拟深呼吸 (15s 窗口, 大幅 RR 波动 — amplitude 100ms)
    for i in range(20):
        rr = 800 + 100 * np.sin(i * 0.4)  # SD ~70ms vs baseline ~10ms
        proc._rr_buffer.append((base_time + 60 + i * 0.7, rr))

    # 触发检测
    proc._detect_deep_breath(base_time + 74.0)

    assert len(deep_events) > 0
    assert True in deep_events


if __name__ == '__main__':
    test_hr_processor_smooth()
    test_hr_processor_delta()
    test_hr_processor_spike()
    test_hr_processor_rmssd()
    test_cadence_processor_lock()
    test_breath_processor_hold_detection()
    test_breath_processor_deep_breath()
    print("[PASS] All processor tests passed")
