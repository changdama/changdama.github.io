"""Smoothers 单元测试。"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import time
from sigbus.smoothers import EMA, Interpolator, RateOfChange, DriftAccumulator, EventPrompt


def test_ema_basic():
    """EMA 基本平滑。"""
    ema = EMA(alpha=0.5)

    # 第一个值直接采用
    assert ema.update(100) == 100

    # 后续平滑
    v = ema.update(200)
    assert v == 150.0  # 0.5 * 200 + 0.5 * 100

    v = ema.update(200)
    assert v == 175.0  # 0.5 * 200 + 0.5 * 150


def test_ema_smoothing_effect():
    """EMA 平滑效果: alpha 越小越平滑。"""
    ema_fast = EMA(alpha=0.8)
    ema_slow = EMA(alpha=0.1)

    # 初始 100，突跳到 200
    ema_fast.update(100)
    ema_slow.update(100)

    fast_v = ema_fast.update(200)
    slow_v = ema_slow.update(200)

    # 快速跟踪者更接近 200
    assert fast_v > slow_v
    assert fast_v > 150
    assert slow_v < 120


def test_interpolator_instant_when_no_transition():
    """Interpolator 无过渡时直接返回当前值。"""
    interp = Interpolator(duration_sec=2.0, initial=0.5)
    assert interp.get(0) == 0.5


def test_interpolator_transition():
    """Interpolator 过渡过程。"""
    interp = Interpolator(duration_sec=2.0, easing='linear', initial=0.0)
    interp.set_target(1.0, now=0.0)

    # 中间点
    v = interp.get(1.0)  # 50% 进度
    assert abs(v - 0.5) < 0.01

    # 完成
    v = interp.get(2.0)
    assert abs(v - 1.0) < 0.01

    # 完成后稳定
    v = interp.get(5.0)
    assert abs(v - 1.0) < 0.01


def test_interpolator_ease_out():
    """Interpolator ease-out: 开始快，结尾慢。"""
    interp = Interpolator(duration_sec=2.0, easing='ease_out', initial=0.0)
    interp.set_target(1.0, now=0.0)

    # ease-out 在前半段应该已经超过 0.5
    v_half = interp.get(1.0)
    assert v_half > 0.5  # ease-out 前半段更快


def test_interpolator_retarget():
    """Interpolator 过渡中改变目标。"""
    interp = Interpolator(duration_sec=2.0, easing='linear', initial=0.0)
    interp.set_target(1.0, now=0.0)

    # 在 t=1.0（值=0.5）时改变目标到 0.0
    v_at_1 = interp.get(1.0)
    assert abs(v_at_1 - 0.5) < 0.01

    interp.set_target(0.0, now=1.0)

    # 从 0.5 → 0.0，2s 线性
    v_at_2 = interp.get(2.0)  # 50% 进度
    assert abs(v_at_2 - 0.25) < 0.01


def test_rate_of_change_below_threshold():
    """RateOfChange: 变化量小于阈值时返回 None。"""
    roc = RateOfChange(threshold=15.0, window_sec=10.0)

    assert roc.update(100, 0.0) is None
    assert roc.update(105, 1.0) is None
    assert roc.update(110, 2.0) is None


def test_rate_of_change_above_threshold():
    """RateOfChange: 变化量超阈值时返回变化量。"""
    roc = RateOfChange(threshold=15.0, window_sec=10.0)

    roc.update(100, 0.0)
    roc.update(105, 1.0)
    roc.update(110, 2.0)
    result = roc.update(120, 3.0)  # delta = 120 - 100 = 20 > 15

    assert result is not None
    assert result == 20.0


def test_rate_of_change_window():
    """RateOfChange: 窗口外的数据被丢弃。"""
    roc = RateOfChange(threshold=15.0, window_sec=5.0)

    roc.update(100, 0.0)
    roc.update(110, 3.0)
    # t=6: 窗口外只有 t=3 (值110)，delta = 112-110 = 2
    result = roc.update(112, 6.0)
    assert result is None


def test_drift_accumulator():
    """DriftAccumulator 漂移检测。"""
    acc = DriftAccumulator(threshold=8.0)

    assert acc.update(100) == False
    assert acc.update(103) == False
    assert acc.update(105) == False
    assert acc.update(109) == True  # |109 - 100| = 9 > 8

    # mark_sent 后重置基准
    acc.mark_sent()
    assert acc.update(110) == False
    assert acc.update(115) == False
    assert acc.update(118) == True  # |118 - 109| = 9 > 8


def test_event_prompt_decay():
    """EventPrompt 权重衰减。"""
    ep = EventPrompt(
        text="test event",
        peak_weight=0.9,
        decay_sec=3.0,
        triggered_at=10.0,
    )

    # 刚触发时
    assert abs(ep.current_weight(10.0) - 0.9) < 0.01

    # 1.5s 后 (50%)
    assert abs(ep.current_weight(11.5) - 0.45) < 0.01

    # 3s 后衰减为 0
    assert ep.current_weight(13.0) == 0.0
    assert ep.is_expired == True


def test_event_prompt_not_expired():
    """EventPrompt 衰减期内未过期。"""
    ep = EventPrompt(
        text="test",
        peak_weight=1.0,
        decay_sec=5.0,
        triggered_at=0.0,
    )

    # 2s 时还未过期
    w = ep.current_weight(2.0)
    assert w > 0
    assert not ep.is_expired


if __name__ == '__main__':
    test_ema_basic()
    test_ema_smoothing_effect()
    test_interpolator_instant_when_no_transition()
    test_interpolator_transition()
    test_interpolator_ease_out()
    test_interpolator_retarget()
    test_rate_of_change_below_threshold()
    test_rate_of_change_above_threshold()
    test_rate_of_change_window()
    test_drift_accumulator()
    test_event_prompt_decay()
    test_event_prompt_not_expired()
    print("[PASS] All smoother tests passed")
