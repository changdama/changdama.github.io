"""
Resonance Web UI
================
Flask + SocketIO server with BLE thread for Polar H10 communication.

Usage:
    python app.py          # Real BLE connection
    python app.py --mock   # Simulated data for UI testing
"""

from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO
import threading
import asyncio
import time
import sys
import os
import numpy as np
import math
import random
from pathlib import Path

import polar_state2 as ps2
from physio_to_lyria import physio_to_lyria
from lyria_client import LyriaClient
from polar_state2 import (
    State, Phase, Section,
    HR_CHAR_UUID, PMD_CONTROL, PMD_DATA, ACC_START_CMD,
    parse_hr_data, parse_acc_data, filter_rr,
    try_finish_calibration, estimate_cadence, update_cadence_lock,
    detect_breath_hold, detect_deep_breath_realtime,
    estimate_breathing_rate, build_prompt_output,
    compute_rmssd,
    SECTION_LABELS, SECTION_PROMPTS,
)

MOCK_MODE = '--mock' in sys.argv
USE_NEW_PIPELINE = '--v2' in sys.argv or True  # 新信号管道 (默认启用)

# Lyria RealTime: load API key
def _load_google_api_key():
    key = os.environ.get("GOOGLE_API_KEY")
    if key:
        return key
    for env_path in [Path("lyria_poc/.env"), Path(".env")]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("GOOGLE_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None

GOOGLE_API_KEY = _load_google_api_key()
LYRIA_ENABLED = GOOGLE_API_KEY is not None

app = Flask(__name__)
app.config['SECRET_KEY'] = 'resonance-demo'
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*",
                    logger=False, engineio_logger=False)

# Session control: stop previous session when starting a new one
_session_id = 0
_active_pipeline = None  # SignalPipeline instance (v2), set during session


# === Routes ===

@app.route('/')
def index():
    return render_template('index.html')


# === WebSocket Handlers ===

@socketio.on('connect')
def handle_connect():
    print("  [WS] Client connected")


@socketio.on('start_session')
def handle_start(data):
    print(f"  [WS] start_session received: {data}")
    global _session_id
    _session_id += 1
    ps2.state = State()
    ps2.state.style = data.get('style', 'electronic')
    ps2.state.mood = data.get('mood', 'uplifting')
    ps2.state.duration_min = int(data.get('duration', 5))
    ps2.state.max_goals = int(data.get('goals', 0))
    t = threading.Thread(target=ble_thread_main, args=(_session_id,), daemon=True)
    t.start()


@socketio.on('goal_reached')
def handle_goal_reached(data=None):
    if USE_NEW_PIPELINE and _active_pipeline:
        _active_pipeline.trigger_goal()
    else:
        ps2.state.goal_triggered = True


@socketio.on('switch_section')
def handle_section_switch(data):
    if USE_NEW_PIPELINE and _active_pipeline:
        _active_pipeline.switch_section(data.get('section', 'verse'))
    else:
        section_map = {
            'intro': Section.INTRO,
            'verse': Section.VERSE,
            'chorus': Section.CHORUS,
            'bridge': Section.BRIDGE,
            'outro': Section.OUTRO,
        }
        new_section = section_map.get(data.get('section'))
        if new_section and new_section != ps2.state.section:
            ps2.state.section_log.append((time.time() - ps2.state.session_start, new_section))
            ps2.state.section = new_section
            socketio.emit('section_changed', {'section': new_section.value})


# === Prompt Segment Merging ===

def merge_prompt_segments(prompt_log, total_duration, min_segment_sec=15):
    """Merge per-second prompt snapshots into music-generation-friendly segments.

    Rules:
    - New segment on section change
    - Within same section, merge consecutive entries (use middle prompt as representative)
    - Minimum segment duration: min_segment_sec
    """
    if not prompt_log:
        return []

    segments = []
    current_section = prompt_log[0]['section']
    seg_start = prompt_log[0]['elapsed_sec']
    seg_entries = [prompt_log[0]]

    for entry in prompt_log[1:]:
        section_changed = entry['section'] != current_section
        if section_changed:
            # Flush current segment
            _flush_segment(segments, seg_entries, seg_start, entry['elapsed_sec'])
            # Start new segment
            current_section = entry['section']
            seg_start = entry['elapsed_sec']
            seg_entries = [entry]
        else:
            seg_entries.append(entry)

    # Flush last segment
    _flush_segment(segments, seg_entries, seg_start, total_duration)

    # Enforce minimum duration by merging short segments with neighbors
    merged = []
    for seg in segments:
        if merged and seg['duration_sec'] < min_segment_sec and merged[-1]['section'] == seg['section']:
            merged[-1]['end_sec'] = seg['end_sec']
            merged[-1]['duration_sec'] = merged[-1]['end_sec'] - merged[-1]['start_sec']
        else:
            merged.append(seg)

    # Re-merge any remaining short trailing segments
    final = []
    for seg in merged:
        if final and seg['duration_sec'] < min_segment_sec:
            final[-1]['end_sec'] = seg['end_sec']
            final[-1]['duration_sec'] = final[-1]['end_sec'] - final[-1]['start_sec']
        else:
            final.append(seg)

    # Assign segment IDs
    for i, seg in enumerate(final):
        seg['id'] = i

    return final


def _flush_segment(segments, entries, start_sec, end_sec):
    if not entries:
        return
    mid = entries[len(entries) // 2]
    segments.append({
        'start_sec': start_sec,
        'end_sec': end_sec,
        'duration_sec': end_sec - start_sec,
        'section': mid['section'],
        'prompt': mid['prompt'],
        'tags': mid['tags'],
    })


# === Output file serving ===

@app.route('/output/<filename>')
def serve_output(filename):
    from flask import send_from_directory
    return send_from_directory('output', filename)


# === Music Generation API (placeholder) ===

@app.route('/api/generate_music', methods=['POST'])
def api_generate_music():
    """Placeholder endpoint for music generation.

    Expects JSON: { segments: [...] }
    Returns: { status, clips: [{id, url, duration_sec}] }

    TODO: Integrate with Suno API / MusicGen / other service.
    """
    data = request.get_json()
    segments = data.get('segments', [])

    # Placeholder: return segment info without actual audio
    clips = []
    for seg in segments:
        clips.append({
            'id': seg['id'],
            'start_sec': seg['start_sec'],
            'duration_sec': seg['duration_sec'],
            'section': seg['section'],
            'status': 'pending',
            'url': None,  # Will be filled when music generation is integrated
        })

    return jsonify({
        'status': 'ready',
        'message': 'Music generation not yet connected. Segments prepared.',
        'total_clips': len(clips),
        'clips': clips,
    })


# === Prompt Polishing & Regeneration ===

import uuid
import json as json_module

_regen_jobs = {}  # job_id -> {status, progress, wav_url, polished_segments, message}

POLISH_SYSTEM_PROMPT = """You are a music director for a running-to-music app. You receive raw physiological-data-driven music prompts from a running session.

Your job: Transform these raw, repetitive prompts into polished, evocative music directions that tell a musical story.

Rules:
1. Keep the same number of segments with same durations
2. Preserve the energy curve (don't make a high-energy section calm)
3. Remove repetitive boilerplate (e.g. "instrumental X running music, no vocals" only needs to appear once as a global prefix)
4. Add emotional narrative and imagery (e.g. "dawn light filtering through trees" instead of "soft opening")
5. Make each segment distinct and evocative — each segment should have a DIFFERENT sonic character, instrumentation, or texture
6. If the runner shared their mood/feeling, weave that emotion into the musical narrative
7. Keep prompts concise (1-2 sentences each, not long lists of tags)
8. Include a "vocal_style" field — a concise Suno/Udio style tag string for the WHOLE song that captures the overall musical identity, tempo evolution, and emotional arc. This should be specific enough to avoid generic output (bad: "electronic pop" → good: "progressive trance with orchestral breakdowns, building from 140bpm ambient intro to 174bpm euphoric peak, cinematic synths, driving bassline"). Include BPM range, sub-genre, key instruments, and emotional progression.

Output format: Return a JSON object with two keys:
  - "segments": array of objects with keys: section, duration_sec, prompt
  - "vocal_style": a single string (20-40 words) for Suno/Udio style parameter

Example:
{
  "segments": [
    {"section": "intro", "duration_sec": 57, "prompt": "gentle dawn atmosphere, sparse piano notes emerging from silence, breath-like synth pads"},
    {"section": "chorus", "duration_sec": 45, "prompt": "explosive euphoria, full brass hits layered with chopped vocal chops, stadium energy"}
  ],
  "vocal_style": "progressive electronic with orchestral elements, 140-174bpm building intensity, cinematic synths, driving four-on-the-floor kick, euphoric trance breakdown"
}

IMPORTANT: Return ONLY the JSON object, no markdown formatting, no explanation."""

LYRICS_SYSTEM_PROMPT = """You are a lyricist for a running-to-music app. You receive polished music segment descriptions from a completed running session, along with the runner's mood and creative moments.

Your job: Write lyrics (in the runner's emotional voice) that match the musical structure and energy curve of their run.

Rules:
1. Write lyrics for each segment that match its section type and energy level
2. Lyrics should reflect the runner's emotional journey:
   - Intro: anticipation, setting out, the first breath of fresh air
   - Verse: building rhythm, finding the groove, internal monologue
   - Chorus: peak emotion, the runner's mantra, triumphant or determined
   - Bridge: struggle, doubt, pushing through, or a moment of contrast
   - Outro: accomplishment, reflection, cool-down peace
3. If the runner shared their mood, embody that feeling authentically
4. If creative events occurred (deep breathing, breath hold), reference those physical moments subtly
5. Keep lyrics concise: 2-4 lines per segment (suitable for singing over instrumental)
6. Write lyrics in Chinese (中文) by default unless the music style suggests otherwise
7. Each segment's lyrics should be singable at the section's energy level
8. Include a "hook" line in chorus sections that could repeat

Output format: Return a JSON array of objects with keys: section, duration_sec, lyrics, hook (hook is optional, only for chorus)
Example: [{"section": "intro", "duration_sec": 57, "lyrics": "晨光穿过树梢\\n每一步都是新的开始\\n脚下的路在呼唤"}, {"section": "chorus", "duration_sec": 45, "lyrics": "我就是节奏 我就是风\\n没有什么能熄灭心中的火焰", "hook": "我就是节奏 我就是风"}]

IMPORTANT: Return ONLY the JSON array, no markdown formatting, no explanation."""


def _call_gemini_lyrics(polished_segments, mood=None, style=None, creative_events=None):
    """Call Gemini to generate lyrics matching the polished music segments."""
    import urllib.request
    import urllib.error

    user_content = "Polished music segment descriptions:\n"
    for seg in polished_segments:
        user_content += f"\n[{seg.get('section', 'unknown')}] ({seg.get('duration_sec', 0)}s):\n{seg.get('prompt', '')}\n"

    if mood:
        user_content += f"\nRunner's post-workout feeling: {mood}"
    if style:
        user_content += f"\nMusic style: {style}"
    if creative_events:
        user_content += "\nSpecial moments during the run:"
        for ev in creative_events[:10]:  # limit to avoid token overflow
            user_content += f"\n  - [{ev.get('type', '')}] at {ev.get('timestamp', 0):.0f}s in {ev.get('section', '')} section"

    payload = {
        "contents": [{
            "parts": [{"text": LYRICS_SYSTEM_PROMPT + "\n\n" + user_content}]
        }],
        "generationConfig": {
            "temperature": 0.9,
            "maxOutputTokens": 4096,
        }
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GOOGLE_API_KEY}"
    req = urllib.request.Request(
        url,
        data=json_module.dumps(payload).encode('utf-8'),
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json_module.loads(resp.read().decode())
            parts = result['candidates'][0]['content']['parts']
            text = ''
            for part in parts:
                if 'text' in part:
                    text = part['text']  # use last text part (skip thinking)
            print(f"  [GEMINI-LYRICS] Raw response ({len(text)} chars): {text[:200]}...")
            # Strip markdown code fences
            text = text.strip()
            if text.startswith('```'):
                lines = text.split('\n')
                text = '\n'.join(lines[1:])
                if text.endswith('```'):
                    text = text[:-3]
                text = text.strip()
            # Find JSON array in response
            start = text.find('[')
            end = text.rfind(']')
            if start != -1 and end != -1:
                text = text[start:end + 1]
            lyrics = json_module.loads(text)
            return lyrics, None
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.readable() else ''
        print(f"  [GEMINI-LYRICS] HTTP {e.code}: {body[:200]}")
        return None, f"HTTP {e.code}: {body[:200]}"
    except Exception as e:
        print(f"  [GEMINI-LYRICS] Error: {e}")
        return None, str(e)


# === Vocal Synthesis via udioapi.pro ===

UDIO_API_BASE = "https://udioapi.pro/api/v2"

def _load_udio_api_key():
    """Load UDIO_API_KEY from env or .env files."""
    key = os.environ.get("UDIO_API_KEY")
    if key:
        return key
    for env_path in [Path(".env"), Path("lyria_poc/.env")]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                if line.startswith("UDIO_API_KEY="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None

UDIO_API_KEY = _load_udio_api_key()
if UDIO_API_KEY:
    print(f"  [UDIO] API key loaded (sk-...{UDIO_API_KEY[-6:]})")
else:
    print("  [UDIO] WARNING: No UDIO_API_KEY found. Vocal generation disabled.")


class VocalSynthesizer:
    """Generate vocal songs via udioapi.pro (cloud API, supports Suno/Udio models)."""

    def __init__(self, api_key=None, base_url=None):
        self.api_key = api_key or UDIO_API_KEY
        self.base_url = base_url or UDIO_API_BASE

    def _request(self, method, path, data=None, timeout=30):
        """Make authenticated request to udioapi.pro."""
        import urllib.request
        import urllib.error

        url = f"{self.base_url}{path}"
        body = json_module.dumps(data).encode('utf-8') if data else None
        req = urllib.request.Request(url, data=body, method=method)
        req.add_header("Authorization", f"Bearer {self.api_key}")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "Resonance/1.0")

        resp = urllib.request.urlopen(req, timeout=timeout)
        return json_module.loads(resp.read().decode())

    def is_available(self):
        """Check if udioapi.pro is accessible and has credits."""
        if not self.api_key:
            print("  [UDIO] No API key configured (set UDIO_API_KEY in .env)")
            return False
        try:
            result = self._request("GET", "/credits")
            # Response: {"code": 200, "data": {"credits": 980, "used_credits": 20}}
            if result.get('code') == 200:
                data = result.get('data', result)
                credits = data.get('credits', data.get('credits_left', 0))
                return credits > 0
            return False
        except Exception as e:
            print(f"  [UDIO] is_available check failed: {e}")
            return False

    def get_credits(self):
        """Get remaining credits."""
        try:
            result = self._request("GET", "/credits")
            if result.get('code') == 200:
                return result.get('data', result)
            return result
        except Exception:
            return None

    def generate(self, lyrics, style_prompt, title="Running Song"):
        """
        Generate a song with vocals via udioapi.pro.

        Args:
            lyrics: Full lyrics text (with line breaks)
            style_prompt: Music style description (e.g., "energetic electronic pop, 170bpm")
            title: Song title

        Returns:
            (song_data, error) — dict with task_id or (None, error_msg)
        """
        import urllib.error

        payload = {
            "prompt": lyrics,
            "style": style_prompt,
            "title": title,
            "model": "chirp-v4-5",
            "make_instrumental": False,
        }

        try:
            result = self._request("POST", "/generate", data=payload)
            print(f"  [UDIO] Generate response: {result}")
            # Response: {"code": 200, "workId": "gen2abc...", "data": {"task_id": "gen2abc..."}}
            if result.get('code') == 200:
                task_id = result.get('workId') or result.get('data', {}).get('task_id', '')
                if task_id:
                    return {'ids': task_id, 'clips': [{'task_id': task_id}]}, None
            return None, f"Unexpected response: {result}"
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.readable() else ''
            print(f"  [UDIO] HTTP {e.code}: {body[:200]}")
            return None, f"HTTP {e.code}: {body[:200]}"
        except Exception as e:
            print(f"  [UDIO] Error: {e}")
            return None, str(e)

    def poll_status(self, ids):
        """
        Poll udioapi.pro for generation status.

        Args:
            ids: task_id string (workId)

        Returns:
            list of clip dicts with status/audio_url (compatible with existing frontend)
        """
        try:
            result = self._request("GET", f"/feed?workId={ids}")
            print(f"  [UDIO] Poll response: {json_module.dumps(result, ensure_ascii=False)[:300]}")
            # Response format:
            # {"code": 200, "data": {"type": "IN_PROGRESS"|"SUCCESS"|"FAILED", "response_data": [...]}}
            if result.get('code') == 200:
                data = result.get('data', {})
                task_type = data.get('type', '')
                clips = data.get('response_data') or []

                # Still processing
                if task_type == 'IN_PROGRESS':
                    return [{'id': ids, 'status': 'processing', 'audio_url': None,
                             'title': '', 'image_url': ''}]

                # Failed
                if task_type == 'FAILED':
                    error_msg = data.get('fail_reason', 'Generation failed')
                    return [{'id': ids, 'status': 'error', 'audio_url': None,
                             'title': '', 'metadata': {'error_message': error_msg}}]

                # Success — normalize clips
                if task_type == 'SUCCESS' and isinstance(clips, list) and len(clips) > 0:
                    normalized = []
                    for clip in clips:
                        normalized.append({
                            'id': clip.get('id', ids),
                            'status': 'complete',
                            'audio_url': clip.get('audio_url', ''),
                            'title': clip.get('title', ''),
                            'image_url': clip.get('image_url', ''),
                            'metadata': {},
                        })
                    return normalized

            return None
        except Exception as e:
            print(f"  [UDIO] Poll error: {e}")
            return None


_vocal_synthesizer = VocalSynthesizer()


def _call_gemini_polish(segments, mood=None):
    """Call Gemini to polish raw prompts into artistic music directions."""
    import urllib.request
    import urllib.error

    user_content = "Raw prompt timeline from running session:\n"
    for seg in segments:
        user_content += f"\n[{seg.get('section', 'unknown')}] ({seg.get('duration_sec', 0)}s):\n{seg.get('prompt', '')}\n"

    if mood:
        user_content += f"\nRunner's post-workout feeling: {mood}"

    payload = {
        "contents": [{
            "parts": [{"text": POLISH_SYSTEM_PROMPT + "\n\n" + user_content}]
        }],
        "generationConfig": {
            "temperature": 0.8,
            "maxOutputTokens": 4096,
        }
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GOOGLE_API_KEY}"
    req = urllib.request.Request(
        url,
        data=json_module.dumps(payload).encode('utf-8'),
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json_module.loads(resp.read().decode())
            # Gemini 2.5 may have multiple parts (thinking + response)
            parts = result['candidates'][0]['content']['parts']
            text = ''
            for part in parts:
                if 'text' in part:
                    text = part['text']  # use last text part (skip thinking)
            print(f"  [GEMINI] Raw response ({len(text)} chars): {text[:200]}...")
            # Strip markdown code fences
            text = text.strip()
            if text.startswith('```'):
                lines = text.split('\n')
                text = '\n'.join(lines[1:])
                if text.endswith('```'):
                    text = text[:-3]
                text = text.strip()
            # Parse response: new format is {"segments": [...], "vocal_style": "..."}
            # Old format is just [...] array — handle both
            parsed = None
            # Try object format first
            obj_start = text.find('{')
            obj_end = text.rfind('}')
            if obj_start != -1 and obj_end != -1:
                try:
                    parsed = json_module.loads(text[obj_start:obj_end + 1])
                except json_module.JSONDecodeError:
                    parsed = None

            if parsed and isinstance(parsed, dict) and 'segments' in parsed:
                # New format: {"segments": [...], "vocal_style": "..."}
                segments = parsed['segments']
                vocal_style = parsed.get('vocal_style', '')
                # Attach vocal_style to first segment for downstream access
                if segments and vocal_style:
                    segments[0]['_vocal_style'] = vocal_style
                return segments, None
            else:
                # Fallback: old array format [...]
                arr_start = text.find('[')
                arr_end = text.rfind(']')
                if arr_start != -1 and arr_end != -1:
                    text = text[arr_start:arr_end + 1]
                polished = json_module.loads(text)
                return polished, None
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.readable() else ''
        print(f"  [GEMINI] HTTP {e.code}: {body[:200]}")
        return None, f"HTTP {e.code}: {body[:200]}"
    except Exception as e:
        print(f"  [GEMINI] Error: {e}")
        return None, str(e)


def _regenerate_with_lyria(job_id, polished_segments):
    """Background thread: feed polished prompts to Lyria RealTime sequentially."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(_async_regenerate(job_id, polished_segments))


async def _async_regenerate(job_id, polished_segments):
    """Async: connect to Lyria, feed prompts per segment timing, save WAV."""
    if not LYRIA_ENABLED:
        _regen_jobs[job_id]['status'] = 'error'
        _regen_jobs[job_id]['message'] = 'Lyria not enabled (no API key)'
        return

    steer_queue = asyncio.Queue(maxsize=5)
    total_duration = sum(seg['duration_sec'] for seg in polished_segments)
    lyria = LyriaClient(
        api_key=GOOGLE_API_KEY, socketio=socketio,
        steer_queue=steer_queue, output_dir="output", segment_idx=99
    )
    lyria_task = asyncio.create_task(lyria.run())

    # Wait for connection
    for _ in range(10):
        if lyria.connected:
            break
        await asyncio.sleep(0.5)

    if not lyria.connected:
        _regen_jobs[job_id]['status'] = 'error'
        _regen_jobs[job_id]['message'] = 'Could not connect to Lyria'
        return

    # 段落 → Lyria 参数映射（确保 intro 轻柔、bridge 密集）
    SECTION_CONFIG = {
        'intro':  {"bpm": "120", "density": "0.25", "brightness": "0.40", "guidance": "3"},
        'verse':  {"bpm": "135", "density": "0.45", "brightness": "0.50", "guidance": "4"},
        'chorus': {"bpm": "145", "density": "0.70", "brightness": "0.65", "guidance": "5"},
        'bridge': {"bpm": "150", "density": "0.80", "brightness": "0.55", "guidance": "5"},
        'outro':  {"bpm": "110", "density": "0.20", "brightness": "0.35", "guidance": "3"},
    }

    # Feed prompts according to timeline
    elapsed = 0
    stopped = False
    for i, seg in enumerate(polished_segments):
        if stopped:
            break

        prompt_text = seg['prompt']
        section = seg.get('section', '')
        duration = seg['duration_sec']

        prompts = [{"text": prompt_text, "weight": 1.0}]
        config = {"music_generation_config": SECTION_CONFIG.get(section, SECTION_CONFIG['verse'])}

        # Send initial steer for this segment
        try:
            steer_queue.put_nowait({'prompts': prompts, 'config': config})
        except asyncio.QueueFull:
            pass

        # Wait for segment duration, re-steering every 3s
        seg_elapsed = 0
        while seg_elapsed < duration:
            # Check stop signal
            if _regen_jobs[job_id].get('_stop_requested'):
                stopped = True
                break

            await asyncio.sleep(1)
            seg_elapsed += 1
            elapsed += 1

            if seg_elapsed % 3 == 0:
                try:
                    steer_queue.put_nowait({'prompts': prompts, 'config': config})
                except asyncio.QueueFull:
                    pass

            _regen_jobs[job_id]['progress'] = f"{elapsed}/{total_duration}s ({section})"

    # Stop Lyria and save whatever audio we have
    await lyria.stop()
    try:
        await asyncio.wait_for(lyria_task, timeout=5.0)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        pass

    wav_path = lyria.save_wav()
    if stopped:
        _regen_jobs[job_id]['status'] = 'stopped'
        _regen_jobs[job_id]['wav_url'] = f"/output/{os.path.basename(wav_path)}" if wav_path else None
        _regen_jobs[job_id]['message'] = f'Stopped at {elapsed}s'
    elif wav_path:
        _regen_jobs[job_id]['status'] = 'complete'
        _regen_jobs[job_id]['wav_url'] = f"/output/{os.path.basename(wav_path)}"
    else:
        _regen_jobs[job_id]['status'] = 'error'
        _regen_jobs[job_id]['message'] = 'No audio generated'


@app.route('/api/polish_and_regenerate', methods=['POST'])
def api_polish_and_regenerate():
    data = request.get_json()
    segments = data.get('segments', [])
    mood = data.get('mood', '')
    lyrics_enabled = data.get('lyrics_enabled', False)
    style = data.get('style', '')
    creative_events = data.get('creative_events', [])

    if not segments:
        return jsonify({'status': 'error', 'message': 'No segments provided'})

    # Step 1: Polish prompts with Gemini
    polished, error = _call_gemini_polish(segments, mood if mood else None)
    if not polished:
        return jsonify({'status': 'error', 'message': f'Failed to polish prompts: {error}'})

    # Step 2 (optional): Generate lyrics with Gemini
    if lyrics_enabled:
        lyrics_data, lyrics_error = _call_gemini_lyrics(
            polished,
            mood=mood if mood else None,
            style=style if style else None,
            creative_events=creative_events if creative_events else None,
        )
        if lyrics_data:
            # Merge lyrics into polished segments by index
            for i, seg in enumerate(polished):
                if i < len(lyrics_data):
                    seg['lyrics'] = lyrics_data[i].get('lyrics', '')
                    seg['hook'] = lyrics_data[i].get('hook', None)
                else:
                    seg['lyrics'] = ''
                    seg['hook'] = None
        else:
            # Lyrics generation failed — non-fatal, continue without
            print(f"  [LYRICS] Generation failed: {lyrics_error}, continuing without lyrics")
            for seg in polished:
                seg['lyrics'] = ''
                seg['hook'] = None

    # Step 3: Start background regeneration with Lyria
    job_id = str(uuid.uuid4())[:8]
    _regen_jobs[job_id] = {
        'status': 'regenerating',
        'progress': '0s',
        'wav_url': None,
        'polished_segments': polished,
        'lyrics_enabled': lyrics_enabled,
        'message': None,
    }

    t = threading.Thread(target=_regenerate_with_lyria, args=(job_id, polished), daemon=True)
    t.start()

    # Extract vocal_style from polished segments (attached to first segment)
    vocal_style = ''
    if polished and polished[0].get('_vocal_style'):
        vocal_style = polished[0].pop('_vocal_style')

    return jsonify({
        'status': 'polished',
        'job_id': job_id,
        'polished_segments': polished,
        'lyrics_enabled': lyrics_enabled,
        'vocal_style': vocal_style,
    })


@app.route('/api/regenerate_status/<job_id>')
def api_regenerate_status(job_id):
    job = _regen_jobs.get(job_id)
    if not job:
        return jsonify({'status': 'error', 'message': 'Job not found'})
    return jsonify(job)


@app.route('/api/stop_regeneration/<job_id>', methods=['POST'])
def api_stop_regeneration(job_id):
    """Stop an in-progress regeneration. Saves partial audio if available."""
    job = _regen_jobs.get(job_id)
    if not job:
        return jsonify({'status': 'error', 'message': 'Job not found'})
    if job['status'] != 'regenerating':
        return jsonify({'status': 'ok', 'message': 'Already finished'})

    # Signal the regeneration thread to stop
    job['_stop_requested'] = True
    return jsonify({'status': 'ok', 'message': 'Stop requested'})


# === Suno Vocal Generation ===

_suno_jobs = {}  # job_id -> {status, ids, audio_url, title, error}


@app.route('/api/suno_status')
def api_suno_status():
    """Check if Suno API is available and return credits."""
    available = _vocal_synthesizer.is_available()
    credits = _vocal_synthesizer.get_credits() if available else None
    return jsonify({
        'available': available,
        'credits': credits,
    })


@app.route('/api/generate_vocal', methods=['POST'])
def api_generate_vocal():
    """Generate a vocal song via Suno API using lyrics + style."""
    data = request.get_json()
    lyrics = data.get('lyrics', '')
    style = data.get('style', '')
    title = data.get('title', 'Running Song')

    if not lyrics:
        return jsonify({'status': 'error', 'message': 'No lyrics provided'})

    if not _vocal_synthesizer.is_available():
        return jsonify({'status': 'error', 'message': 'Music API not available (check UDIO_API_KEY in .env and credits at udioapi.pro)'})

    # Submit to Suno
    result, error = _vocal_synthesizer.generate(lyrics, style, title)
    if not result:
        return jsonify({'status': 'error', 'message': f'Suno generation failed: {error}'})

    job_id = str(uuid.uuid4())[:8]
    _suno_jobs[job_id] = {
        'status': 'generating',
        'ids': result['ids'],
        'clips': result['clips'],
        'audio_url': None,
        'title': title,
        'error': None,
    }

    return jsonify({
        'status': 'submitted',
        'job_id': job_id,
        'ids': result['ids'],
    })


@app.route('/api/suno_poll/<job_id>')
def api_suno_poll(job_id):
    """Poll Suno generation status."""
    job = _suno_jobs.get(job_id)
    if not job:
        return jsonify({'status': 'error', 'message': 'Job not found'})

    if job['status'] == 'complete' or job['status'] == 'error':
        return jsonify(job)

    # Poll Suno for updates
    clips = _vocal_synthesizer.poll_status(job['ids'])
    if not clips:
        return jsonify(job)

    # Check if any clip is ready (status = 'streaming' or 'complete')
    for clip in clips:
        status = clip.get('status', '')
        if status in ('streaming', 'complete') and clip.get('audio_url'):
            job['status'] = 'complete'
            job['audio_url'] = clip['audio_url']
            job['title'] = clip.get('title', job['title'])
            job['image_url'] = clip.get('image_url', '')
            return jsonify(job)

    # Check for errors
    for clip in clips:
        if clip.get('status') == 'error':
            job['status'] = 'error'
            job['error'] = clip.get('metadata', {}).get('error_message', 'Unknown error')
            return jsonify(job)

    # Still generating
    job['clips'] = clips
    return jsonify(job)


# === BLE Thread ===

def ble_thread_main(sid):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if USE_NEW_PIPELINE:
        if MOCK_MODE:
            loop.run_until_complete(pipeline_mock_session(sid))
        else:
            loop.run_until_complete(pipeline_ble_session(sid))
    else:
        if MOCK_MODE:
            loop.run_until_complete(mock_session(sid))
        else:
            loop.run_until_complete(ble_session(sid))


async def ble_session(sid):
    from bleak import BleakClient, BleakScanner

    state = ps2.state
    print("  [BLE] Scanning for Polar H10...")
    socketio.emit('connection_status', {'message': 'Scanning for Polar H10...'})

    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    if not device:
        print("  [BLE] Polar H10 NOT FOUND!")
        socketio.emit('connection_status', {'message': 'Polar H10 not found. Check device.'})
        return

    print(f"  [BLE] Found: {device.name} ({device.address})")
    socketio.emit('connection_status', {'message': f'Found: {device.name}. Connecting...'})

    async with BleakClient(device) as client:
        await client.start_notify(HR_CHAR_UUID, ps2.hr_callback)

        try:
            await client.write_gatt_char(PMD_CONTROL, ACC_START_CMD, response=True)
            await client.start_notify(PMD_DATA, ps2.acc_callback)
        except Exception:
            pass

        print("  [BLE] Connected! Starting calibration...")
        socketio.emit('connection_status', {'message': 'Connected. Calibrating...'})
        state.session_start = time.time()
        state.calibration_start = time.time()

        # --- Calibration ---
        await run_calibration(state, sid)
        if _session_id != sid:
            return

        # --- Running ---
        state.phase = Phase.RUNNING
        if state.section is None:
            state.section = Section.INTRO
            state.section_log.append((time.time() - state.session_start, Section.INTRO))

        socketio.emit('calibration_complete', {
            'hr_baseline': state.hr_baseline,
            'rmssd_baseline': round(state.baseline_rmssd, 1) if state.baseline_rmssd else None,
            'acc_baseline': round(state.acc_baseline, 4) if state.acc_baseline else None,
            'duration_min': state.duration_min,
        })

        # Lyria RealTime
        if state.max_goals > 0:
            # Goal mode: run_running_phase manages Lyria per-segment internally
            await run_running_phase(state, sid)
        else:
            # No goals: single Lyria session for the entire run
            steer_queue = asyncio.Queue(maxsize=5)
            lyria = None
            lyria_task = None
            if LYRIA_ENABLED:
                lyria = LyriaClient(api_key=GOOGLE_API_KEY, socketio=socketio,
                                    steer_queue=steer_queue, output_dir="output")
                lyria_task = asyncio.create_task(lyria.run())

            await run_running_phase(state, sid, steer_queue)

            # Stop Lyria and get WAV path
            if lyria and lyria_task:
                await lyria.stop()
                try:
                    await asyncio.wait_for(lyria_task, timeout=5.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass
                wav_path = lyria.save_wav()
                if wav_path:
                    wav_url = f"/output/{os.path.basename(wav_path)}"
                    socketio.emit('lyria_status', {'status': 'complete', 'wav_url': wav_url})

        # Cleanup
        try:
            await client.stop_notify(HR_CHAR_UUID)
            await client.stop_notify(PMD_DATA)
        except Exception:
            pass


async def run_calibration(state, sid):
    sec = 0
    while True:
        if _session_id != sid:
            return
        await asyncio.sleep(1)
        sec += 1
        elapsed = time.time() - state.calibration_start

        if not state.acc_collection_started and elapsed >= 15.0:
            state.acc_collection_started = True

        if state.acc_baseline is None and elapsed >= 30.0 and state.acc_warmup_samples:
            arr = np.array(state.acc_warmup_samples)
            state.acc_baseline = float(np.sqrt(np.mean(arr ** 2)))

        socketio.emit('calibration_tick', {
            'hr': state.hr,
            'rr_count': len(state.rr_calibration),
            'acc_samples': len(state.acc_warmup_samples),
            'elapsed': round(elapsed, 1),
            'remaining': max(0, 30 - int(elapsed)),
            'status': 'Collecting baseline data...',
        })

        if elapsed >= 30:
            if state.acc_baseline is None and elapsed < 45:
                continue
            success, msg = try_finish_calibration()
            if success:
                break
            elif elapsed >= 45:
                if state.hr_calibration:
                    state.hr_baseline = float(np.median(state.hr_calibration))
                else:
                    state.hr_baseline = 75
                break


REST_DURATION = 60  # seconds
KEEPALIVE_INTERVAL = 5  # send keepalive prompt every N seconds during rest


def extract_unique_tags(prompts):
    """Get deduplicated tag list from prompt entries."""
    seen = set()
    tags = []
    for p in prompts:
        for tag in p.get('tags', []):
            if tag not in seen:
                seen.add(tag)
                tags.append(tag)
    return tags


def combine_segment_wavs(paths, crossfade_ms=500):
    """Concatenate segment WAVs with crossfade between them."""
    import wave as wave_mod
    valid_paths = [p for p in paths if p and Path(p).exists()]
    if not valid_paths:
        return None

    if len(valid_paths) == 1:
        return valid_paths[0]

    # Read all segments
    segments_data = []
    for p in valid_paths:
        with wave_mod.open(p, 'rb') as wf:
            frames = wf.readframes(wf.getnframes())
            segments_data.append(np.frombuffer(frames, dtype=np.int16))

    # Crossfade samples (at 48kHz stereo = 96000 samples/sec)
    crossfade_samples = int(48000 * 2 * crossfade_ms / 1000)

    # Combine with crossfade
    combined = segments_data[0].astype(np.float32)
    for seg in segments_data[1:]:
        seg_f = seg.astype(np.float32)
        cf_len = min(crossfade_samples, len(combined), len(seg_f))
        if cf_len > 0:
            fade_out = np.linspace(1.0, 0.0, cf_len)
            fade_in = np.linspace(0.0, 1.0, cf_len)
            combined[-cf_len:] = combined[-cf_len:] * fade_out + seg_f[:cf_len] * fade_in
            combined = np.concatenate([combined, seg_f[cf_len:]])
        else:
            combined = np.concatenate([combined, seg_f])

    # Write combined WAV
    combined_int = np.clip(combined, -32768, 32767).astype(np.int16)
    output_path = Path("output") / f"final_combined_{time.strftime('%Y%m%d_%H%M%S')}.wav"
    with wave_mod.open(str(output_path), 'wb') as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(48000)
        wf.writeframes(combined_int.tobytes())

    return str(output_path)


async def run_running_phase(state, sid, steer_queue=None):
    running_sec = 0
    segment_start_sec = 0

    # In goal mode, we manage a single Lyria client with mute/unmute
    manages_lyria = state.max_goals > 0
    lyria = None
    lyria_task = None

    if manages_lyria and LYRIA_ENABLED:
        steer_queue = asyncio.Queue(maxsize=5)
        lyria = LyriaClient(api_key=GOOGLE_API_KEY, socketio=socketio,
                            steer_queue=steer_queue, output_dir="output", segment_idx=0)
        lyria_task = asyncio.create_task(lyria.run())

    while True:
        if _session_id != sid:
            return
        await asyncio.sleep(1)
        running_sec += 1

        # --- Goal check ---
        if state.goal_triggered and state.goals_completed < state.max_goals:
            state.goal_triggered = False
            state.goals_completed += 1

            # Mute Lyria (saves current segment WAV, keeps connection alive)
            if lyria:
                lyria.mute()

            # Collect prompts from this segment
            segment_prompts = [p for p in state.prompt_log if p['elapsed_sec'] > segment_start_sec]
            last_wav = lyria.segment_wav_paths[-1] if (lyria and lyria.segment_wav_paths) else None

            # Emit rest period
            socketio.emit('rest_period_start', {
                'goal_num': state.goals_completed,
                'max_goals': state.max_goals,
                'segment_prompts': segment_prompts,
                'segment_tags': extract_unique_tags(segment_prompts),
                'rest_duration': REST_DURATION,
                'wav_url': f"/output/{os.path.basename(last_wav)}" if last_wav else None,
            })

            # Wait rest period, send keepalive to Lyria every few seconds
            for rest_sec in range(REST_DURATION):
                if _session_id != sid:
                    return
                await asyncio.sleep(1)
                socketio.emit('rest_tick', {'remaining': REST_DURATION - 1 - rest_sec})
                # Keepalive: send minimal prompt to keep WebSocket alive
                if lyria and rest_sec % KEEPALIVE_INTERVAL == 0:
                    await lyria.send_keepalive()

            # Unmute: start new WAV segment, resume streaming
            if lyria:
                lyria.unmute()
                socketio.emit('lyria_status', {'status': 'streaming'})
                # Immediately steer with current physio state
                output = build_prompt_output()
                if output and steer_queue:
                    prompts, config = physio_to_lyria(state, output)
                    try:
                        steer_queue.put_nowait({'prompts': prompts, 'config': config})
                    except asyncio.QueueFull:
                        pass

            segment_start_sec = running_sec
            socketio.emit('rest_period_end', {'next_goal': state.goals_completed + 1})
            continue

        # --- Normal per-second processing ---
        # Cadence (only override from ACC if we have accelerometer data)
        if len(state.acc_mag_buffer) >= 600:
            state.cadence = estimate_cadence(state.acc_mag_buffer)
        state.cadence_history.append(state.cadence)
        update_cadence_lock()

        # Short-window breathing
        detect_breath_hold(state.rr_buffer)
        detect_deep_breath_realtime(state.rr_buffer)

        # FFT breathing (every 5s)
        if running_sec % 5 == 0:
            br, br_status = estimate_breathing_rate(state.rr_buffer)
            state.breath_status = br_status
            if br is not None:
                if state.breath_rate is not None:
                    ratio_to_prev = br / (state.breath_rate + 1e-6)
                    if ratio_to_prev > 2.2 or ratio_to_prev < 0.45:
                        state.breath_status = f"harmonic_jump({br:.0f}vs{state.breath_rate:.0f})"
                    else:
                        state.breath_rate = br
                        state.breath_confidence = br_status
                        state.breath_history.append(br)
                else:
                    state.breath_rate = br
                    state.breath_confidence = br_status
                    state.breath_history.append(br)
            else:
                if state.breath_rate is not None:
                    if not hasattr(state, '_breath_miss_count'):
                        state._breath_miss_count = 0
                    state._breath_miss_count += 1
                    if state._breath_miss_count >= 2:
                        state.breath_rate = None
                        state.breath_confidence = None
                        state._breath_miss_count = 0

        # Build output
        output = build_prompt_output()
        if output:
            output['elapsed_sec'] = running_sec
            output['duration_sec'] = state.duration_min * 60
            output['breath_hold'] = state.breath_hold_detected
            output['deep_breath_rt'] = state.deep_breath_realtime
            output['goals_completed'] = state.goals_completed
            output['max_goals'] = state.max_goals
            socketio.emit('metrics_update', output)

            # Log prompt snapshot
            prompt_text = output.get('full_prompt', '')
            if prompt_text:
                state.prompt_log.append({
                    'elapsed_sec': running_sec,
                    'section': state.section.value if state.section else None,
                    'prompt': prompt_text,
                    'tags': output.get('prompt_tags', []),
                })

            # Lyria steering: immediately on first second, then every 3s
            if steer_queue and (running_sec == 1 or running_sec % 3 == 0):
                prompts, config = physio_to_lyria(state, output)
                try:
                    steer_queue.put_nowait({'prompts': prompts, 'config': config})
                except asyncio.QueueFull:
                    pass

        # Duration limit
        if running_sec >= state.duration_min * 60:
            break

    # --- Session complete ---
    # Stop Lyria and collect all segment WAVs
    if manages_lyria and lyria:
        await lyria.stop()
        try:
            await asyncio.wait_for(lyria_task, timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
        state.segment_wavs = lyria.get_segment_wavs()

    # Combine all segment WAVs
    final_wav_path = combine_segment_wavs(state.segment_wavs) if state.segment_wavs else None
    final_wav_url = f"/output/{os.path.basename(final_wav_path)}" if final_wav_path else None

    segments = merge_prompt_segments(state.prompt_log, state.duration_min * 60)
    socketio.emit('session_complete', {
        'sections': [s.value for _, s in state.section_log],
        'creative_events': state.creative_events,
        'final_prompt': ps2.build_final_song_prompt(),
        'prompt_timeline': segments,
        'wav_url': final_wav_url,
        'segment_wavs': [f"/output/{os.path.basename(p)}" for p in state.segment_wavs if p],
    })


# === Mock Session (no BLE) ===

async def mock_session(sid):
    state = ps2.state
    socketio.emit('connection_status', {'message': '[MOCK] Simulating Polar H10...'})
    await asyncio.sleep(1)
    socketio.emit('connection_status', {'message': '[MOCK] Connected. Calibrating...'})

    state.session_start = time.time()
    state.calibration_start = time.time()
    state.hr = 72

    # Mock calibration
    for sec in range(1, 31):
        if _session_id != sid:
            return
        await asyncio.sleep(1)
        state.hr = 72 + random.randint(-2, 2)
        state.hr_calibration.append(state.hr)
        if sec >= 15:
            state.acc_warmup_samples.extend([0.01 + random.random() * 0.005 for _ in range(200)])
        rr = 60000.0 / state.hr + random.gauss(0, 15)
        state.rr_calibration.append(rr)

        socketio.emit('calibration_tick', {
            'hr': state.hr,
            'rr_count': len(state.rr_calibration),
            'acc_samples': len(state.acc_warmup_samples),
            'elapsed': sec,
            'remaining': max(0, 30 - sec),
            'status': '[MOCK] Collecting baseline...',
        })

    # Finish calibration
    state.hr_baseline = float(np.median(state.hr_calibration))
    state.baseline_rmssd = compute_rmssd(state.rr_calibration)
    arr = np.array(state.acc_warmup_samples)
    state.acc_baseline = float(np.sqrt(np.mean(arr ** 2)))

    state.phase = Phase.RUNNING
    state.section = Section.INTRO
    state.section_log.append((time.time() - state.session_start, Section.INTRO))

    socketio.emit('calibration_complete', {
        'hr_baseline': round(state.hr_baseline, 1),
        'rmssd_baseline': round(state.baseline_rmssd, 1) if state.baseline_rmssd else None,
        'acc_baseline': round(state.acc_baseline, 4),
        'duration_min': state.duration_min,
    })

    # Mock running — uses run_running_phase (which handles goals + Lyria internally)
    # But first we need to simulate physio data in a background task
    print(f"  [MOCK] Running phase started: duration={state.duration_min}min, goals={state.max_goals}, sid={sid}")

    if state.max_goals > 0:
        # Goal mode: run_running_phase manages Lyria per-segment
        mock_physio_task = asyncio.create_task(_mock_physio_generator(state, sid))
        await run_running_phase(state, sid)
        mock_physio_task.cancel()
    else:
        # No goals: single Lyria session
        steer_queue = asyncio.Queue(maxsize=5)
        lyria = None
        lyria_task = None
        if LYRIA_ENABLED:
            lyria = LyriaClient(api_key=GOOGLE_API_KEY, socketio=socketio,
                                steer_queue=steer_queue, output_dir="output")
            lyria_task = asyncio.create_task(lyria.run())

        mock_physio_task = asyncio.create_task(_mock_physio_generator(state, sid))
        await run_running_phase(state, sid, steer_queue)
        mock_physio_task.cancel()

        if lyria and lyria_task:
            await lyria.stop()
            try:
                await asyncio.wait_for(lyria_task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
            wav_path = lyria.save_wav()
            if wav_path:
                wav_url = f"/output/{os.path.basename(wav_path)}"
                socketio.emit('lyria_status', {'status': 'complete', 'wav_url': wav_url})

    print(f"  [MOCK] Session {sid} complete")


async def _mock_physio_generator(state, sid):
    """Background task that generates mock physiological data every second."""
    base_hr = state.hr_baseline or 72
    t = 0
    try:
        while True:
            if _session_id != sid:
                return
            await asyncio.sleep(1)
            t += 1

            section_delta = {
                Section.INTRO: 5, Section.VERSE: 20,
                Section.CHORUS: 35, Section.BRIDGE: 45, Section.OUTRO: 10,
            }
            target_delta = section_delta.get(state.section, 10)
            current_delta = (state.hr - base_hr) if state.hr else 0
            state.hr = base_hr + current_delta + (target_delta - current_delta) * 0.1 + random.gauss(0, 1)
            state.hr = int(state.hr)
            state.hr_history.append((time.time(), state.hr))

            rr = 60000.0 / state.hr + random.gauss(0, 20)
            state.rr_buffer.append((time.time(), rr))

            if state.section in (Section.VERSE, Section.CHORUS, Section.BRIDGE):
                state.cadence = 170 + random.gauss(0, 3)
            else:
                state.cadence = None

            if t % 5 == 0:
                state.breath_rate = 14 + random.gauss(0, 2)
                state.breath_confidence = "good"
    except asyncio.CancelledError:
        pass


# === New Pipeline Sessions (v2) ===

from sigbus.pipeline import SignalPipeline

# Active pipeline instance (one per session)
_active_pipeline: SignalPipeline = None


async def pipeline_mock_session(sid):
    """Mock session using the new reactive signal pipeline."""
    global _active_pipeline

    socketio.emit('connection_status', {'message': '[v2/MOCK] Simulating Polar H10...'})
    await asyncio.sleep(0.5)
    socketio.emit('connection_status', {'message': '[v2/MOCK] Connected. Calibrating...'})

    state = ps2.state  # still used for some legacy fields
    pipeline = SignalPipeline(
        socketio=socketio,
        mock=True,
        style=state.style,
        mood=state.mood,
        api_key=GOOGLE_API_KEY if LYRIA_ENABLED else None,
        max_goals=state.max_goals,
    )
    _active_pipeline = pipeline

    # Calibration (full 30s — mock source ticks every second with real data volume)
    CALIBRATION_DURATION = 30
    print(f"  [v2/MOCK] Calibrating ({CALIBRATION_DURATION}s)...")

    # 用 mock source 喂数据到 bus，CalibrationManager 订阅 bus 收集
    from sigbus.calibration import CalibrationManager
    cal_mgr = CalibrationManager(
        pipeline.bus, duration=CALIBRATION_DURATION,
        acc_start_delay=15, socketio=None,  # 我们自己 emit
    )

    # 启动校准（后台 coroutine）
    cal_task = asyncio.create_task(cal_mgr.run())

    # 每秒生成 mock 数据 + 发送 UI tick
    for sec in range(1, CALIBRATION_DURATION + 1):
        if _session_id != sid:
            cal_task.cancel()
            return
        pipeline.source.tick(elapsed_sec=sec, phase='calibration')
        await asyncio.sleep(1)
        socketio.emit('calibration_tick', {
            'hr': pipeline.bus.last_value('hr.raw'),
            'rr_count': len(cal_mgr._rr_samples),
            'acc_samples': len(cal_mgr._acc_mag_samples),
            'elapsed': sec,
            'remaining': CALIBRATION_DURATION - sec,
            'status': '[MOCK] Collecting baseline...',
        })

    # 等待校准完成
    baselines = await cal_task

    # 设置 baselines 到所有组件
    pipeline.hr_processor.set_baselines(baselines['hr_baseline'], baselines['rmssd_baseline'] or 40.0)
    pipeline.cadence_processor.set_baseline(baselines['acc_baseline'] or 0.01)
    pipeline.composer.set_baselines(baselines['hr_baseline'], baselines['rmssd_baseline'] or 40.0)

    socketio.emit('calibration_complete', {
        'hr_baseline': round(baselines['hr_baseline'], 1),
        'rmssd_baseline': round(baselines['rmssd_baseline'], 1) if baselines['rmssd_baseline'] else None,
        'acc_baseline': round(baselines['acc_baseline'], 4) if baselines['acc_baseline'] else None,
        'duration_min': state.duration_min,
    })

    # Start session
    pipeline.switch_section('intro')
    loop = asyncio.get_event_loop()
    await pipeline.start(loop)

    print(f"  [v2/MOCK] Running phase: duration={state.duration_min}min, goals={state.max_goals}")
    result = await pipeline.run_session(
        duration_sec=state.duration_min * 60,
        session_id_ref=[sid],
    )

    # Session complete
    _emit_session_complete(result, state)
    _active_pipeline = None
    print(f"  [v2/MOCK] Session {sid} complete. Steers: {result.get('steer_stats', {})}")


async def pipeline_ble_session(sid):
    """Real BLE session using the new reactive signal pipeline."""
    global _active_pipeline
    from bleak import BleakClient, BleakScanner

    state = ps2.state

    print("  [v2/BLE] Scanning for Polar H10...")
    socketio.emit('connection_status', {'message': 'Scanning for Polar H10...'})

    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    if not device:
        print("  [v2/BLE] Polar H10 NOT FOUND!")
        socketio.emit('connection_status', {'message': 'Polar H10 not found.'})
        return

    print(f"  [v2/BLE] Found: {device.name} ({device.address})")
    socketio.emit('connection_status', {'message': f'Found: {device.name}. Connecting...'})

    pipeline = SignalPipeline(
        socketio=socketio,
        mock=False,
        style=state.style,
        mood=state.mood,
        api_key=GOOGLE_API_KEY if LYRIA_ENABLED else None,
        max_goals=state.max_goals,
    )
    _active_pipeline = pipeline

    async with BleakClient(device) as client:
        # Register BLE callbacks to pipeline's BLESource
        await client.start_notify(HR_CHAR_UUID, pipeline.source.hr_callback)
        try:
            await client.write_gatt_char(PMD_CONTROL, ACC_START_CMD, response=True)
            await client.start_notify(PMD_DATA, pipeline.source.acc_callback)
        except Exception:
            pass

        print("  [v2/BLE] Connected! Calibrating...")
        socketio.emit('connection_status', {'message': 'Connected. Calibrating...'})

        # Calibration (30s, real data flows through bus)
        baselines = await pipeline.calibrate(duration=30)
        if _session_id != sid:
            return

        socketio.emit('calibration_complete', {
            'hr_baseline': baselines['hr_baseline'],
            'rmssd_baseline': round(baselines['rmssd_baseline'], 1) if baselines['rmssd_baseline'] else None,
            'acc_baseline': round(baselines['acc_baseline'], 4) if baselines['acc_baseline'] else None,
            'duration_min': state.duration_min,
        })

        # Start session
        pipeline.switch_section('intro')
        loop = asyncio.get_event_loop()
        await pipeline.start(loop)

        print(f"  [v2/BLE] Running phase: duration={state.duration_min}min, goals={state.max_goals}")
        result = await pipeline.run_session(
            duration_sec=state.duration_min * 60,
            session_id_ref=[sid],
        )

        # Session complete
        _emit_session_complete(result, state)
        _active_pipeline = None
        print(f"  [v2/BLE] Session {sid} complete. Steers: {result.get('steer_stats', {})}")

        # Cleanup BLE
        try:
            await client.stop_notify(HR_CHAR_UUID)
            await client.stop_notify(PMD_DATA)
        except Exception:
            pass


def _emit_session_complete(result, state=None):  # noqa: ARG001
    """Emit session_complete event with prompt log and segment info.

    字段与旧版一致，前端依赖:
      - prompt_timeline: 合并后的 segments（Polish 按钮读取）
      - sections: section 历史列表
      - creative_events: 创意事件
      - final_prompt: 最终合成 prompt
      - wav_url: 合并后的 WAV
      - segment_wavs: 各段 WAV URL
    """
    prompt_log = result.get('prompt_log', [])
    creative_events = result.get('creative_events', [])
    section_log = result.get('section_log', [])
    segment_wavs = result.get('segment_wavs', [])
    steer_stats = result.get('steer_stats', {})

    # Merge prompts into segments (reuse existing function)
    total_duration = result.get('elapsed_sec', 0)
    merged_segments = merge_prompt_segments(prompt_log, total_duration) if prompt_log else []

    # Build final prompt from last segment
    final_prompt = ''
    if prompt_log:
        final_prompt = prompt_log[-1].get('prompt', '')

    # Section history
    sections = [s for _, s in section_log] if section_log else []

    # Combine WAVs if multiple segments
    final_wav = None
    if len(segment_wavs) > 1:
        final_wav = combine_segment_wavs(segment_wavs)
    elif len(segment_wavs) == 1:
        final_wav = segment_wavs[0]

    wav_url = f"/output/{os.path.basename(final_wav)}" if final_wav else None
    segment_wav_urls = [f"/output/{os.path.basename(p)}" for p in segment_wavs if p]

    socketio.emit('session_complete', {
        'sections': sections,
        'creative_events': creative_events,
        'final_prompt': final_prompt,
        'prompt_timeline': merged_segments,
        'wav_url': wav_url,
        'segment_wavs': segment_wav_urls,
        'duration_sec': total_duration,
        'steer_stats': steer_stats,
    })


# === Entry ===

if __name__ == '__main__':
    mode = "MOCK" if MOCK_MODE else "LIVE BLE"
    print(f"\n  Resonance Web UI [{mode}]")
    print(f"  Open http://localhost:5000 in browser\n")
    socketio.run(app, host='0.0.0.0', port=5001, debug=False, allow_unsafe_werkzeug=True)
