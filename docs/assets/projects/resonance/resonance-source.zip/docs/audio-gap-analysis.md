# Resonance 项目：静音空隙问题分析

## 一、为什么会产生静音空隙？

静音空隙源自 **四个层面** 的延迟叠加：

### 1. Lyria API 不规则推送

Google Lyria RealTime API 通过 WebSocket 推送 PCM 音频 chunk，但推送间隔并非恒定——受服务端生成负载和网络抖动（jitter）影响，chunk 到达时间不均匀。

### 2. 启动延迟（Cold Start）

从发送 prompt + PLAY 命令到收到第一块音频，有 **3-5 秒** 的空白期（模型预热 + 首次推理）。

### 3. Steering 饥饿

如果 `steer_queue` 未能及时投递新 prompt，Lyria 可能暂停生成或输出静音段。

### 4. 多跳中继的抖动

音频路径：`Lyria WebSocket → Python Server → SocketIO → Browser`，每一跳引入不确定延迟，导致浏览器端收到 chunk 的时间间隔不规律。

---

## 二、项目目前的解决方案

项目采用 **四重策略** 消除静音：

### 策略 A：预缓冲 + 精确调度（客户端核心方案）

```javascript
const PREBUFFER_SEC = 3.0; // 攒 3 秒再播，吸收 Lyria burst 间隔
```

核心调度逻辑：

```javascript
function scheduleBuffer(buffer) {
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    const now = audioCtx.currentTime;
    if (nextStartTime <= now) nextStartTime = now;
    source.start(nextStartTime);
    nextStartTime += buffer.duration;  // 精确接续，零空隙
}
```

**工作原理**：
1. 先累积 3 秒音频（jitter buffer）
2. 一次性 flush 到 Web Audio 调度器
3. 之后每个新 chunk 立即调度在 `nextStartTime`（上一块结束的精确时刻）
4. 只要 chunk 到达速度 > 消耗速度，播放就无缝

### 策略 B：Warm-up Prompt（消除启动空白）

在 WebSocket 连接建立后**立即**发送预热 prompt + PLAY：

```python
WARMUP_PROMPT = [{"text": "ambient atmospheric pad, gentle swell, no drums", "weight": 1.0}]
```

省去等待第一个真实 steer 事件的 3-5 秒。

### 策略 C：立即 Steer（SteerController）

`start()` 方法立即入队一条 steer 命令，测试中明确断言：

> `"start() should immediately steer to eliminate startup silence gap"`

### 策略 D：Fallback + Keepalive（防止生成断流）

| 机制 | 超时 | 作用 |
|------|------|------|
| Fallback steer | 5 秒 | 无事件驱动 steer 时自动补发 |
| Keepalive | 15 秒 | 强制发送，防止 WebSocket 超时和 Lyria 静默 |

---

## 三、为什么不用 Ring Buffer？是否更好？

### 当前方案的本质

当前方案是 **"线性预缓冲 + 基于时间戳的精确调度"**——本质上是一个 **jitter buffer**：
- 预缓冲阶段：一次性攒够 3 秒
- 播放阶段：`nextStartTime` 指针单调递增，保证样本级无缝

### Ring Buffer 的适用场景

Ring Buffer（环形缓冲区）适合：
- **固定大小的滑动窗口**（如实时通信中的恒定延迟播放）
- **生产者-消费者速率匹配**（覆盖旧数据可接受时）
- **内存受限场景**（需要上界的缓冲）

### 对比分析

| 维度 | 当前方案（Jitter Buffer + 精确调度） | Ring Buffer |
|------|--------------------------------------|-------------|
| 无缝播放 | ✅ `nextStartTime` 保证零 gap | ✅ 可以做到 |
| 内存使用 | ⚠️ 播放后的 AudioBufferSource 由 GC 回收，但无硬上限 | ✅ 固定大小，有上界 |
| 实现复杂度 | ✅ Web Audio 原生支持 schedule-ahead | ⚠️ 需自己管理读写指针、wrap-around |
| 应对长时间卡顿 | ⚠️ runway 耗尽后只能静音等待 | ⚠️ 同样的问题 |
| 适配 Web Audio API | ✅ 天然契合 AudioBufferSourceNode | ❌ Web Audio 没有原生环形播放接口 |

### 结论

> **当前场景下 Ring Buffer 并不比现有方案更优。**

原因：
1. Web Audio API 的 `AudioBufferSourceNode` 是 "一次性播放" 设计，天然适合 "调度一块、播一块、丢弃" 的模式——这正是当前方案的做法。
2. Ring Buffer 的核心优势（固定内存、覆写旧数据）在此场景意义不大——音频已播放的 buffer 自然会被 GC。
3. 用 Ring Buffer 反而需要额外封装一个 ScriptProcessorNode/AudioWorklet 来逐帧填充，增加了复杂度和延迟。

---

## 四、未来可优化的方向

### 1. AudioWorklet + SharedArrayBuffer

用 AudioWorklet 替代多个 AudioBufferSourceNode，在音频线程内维护一个连续的播放缓冲区（这里才是 ring buffer 的正确用武之地）：
- 主线程写入 SharedArrayBuffer
- AudioWorklet `process()` 循环读取
- 好处：更低延迟、更精确的欠载（underrun）检测

### 2. 自适应预缓冲

当前 `PREBUFFER_SEC = 3.0` 是固定值。可以：
- 根据实时 `aheadMs` 统计动态调整（runway 充裕时缩短预缓冲 → 降低感知延迟）
- 网络状况差时自动增大缓冲

### 3. Opus/WebM 流式解码

当前传输原始 PCM（体积大）。改用 Opus 编码 + MediaSource Extensions 解码：
- 带宽减少 5-10×
- 减少因网络拥塞造成的 chunk 到达延迟

### 4. 预测性 Prefetch

在 SteerController 中加入预测逻辑：根据生理信号趋势提前生成下一段 prompt，让 Lyria 提前开始推理。

### 5. 服务端缓冲层

在 Python Server 端维护一个小缓冲（如 2 秒），平滑 Lyria 的 burst 特性后再推送给客户端，减轻客户端 jitter buffer 的压力。
