"""
Polar H10 · HRV (RMSSD) 实时监测
================================

功能：
- 通过 BLE 直连 Polar H10 胸带
- 实时读取心率 + RR 间期
- 计算短时 RMSSD（最近 20 秒）
- 自动建立个人基线
- 基于相对基线变化判断状态

用法：
    python polar_hrv.py

依赖：
    pip install bleak numpy

实验建议：
    1. 戴胸带，电极打湿
    2. 跑代码，前 30 秒静坐建立基线
    3. 实验：深呼吸（6 秒吸 + 8 秒呼）→ RMSSD 应该上升
    4. 实验：突然站起来 → RMSSD 应该下降
"""

import asyncio
import numpy as np
from collections import deque
from bleak import BleakClient, BleakScanner

# BLE Heart Rate Characteristic UUID（标准协议）
HR_CHAR_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

# 滑动窗口
rr_short = deque(maxlen=25)          # 短时窗口（~20 秒），用于实时 RMSSD
rr_baseline_pool = deque(maxlen=200)  # 长窗口，用于建立基线和后续分析

# 个人基线（首次校准后设定）
baseline_rmssd = None


def parse_hr_data(data: bytearray):
    """
    解析 Polar H10 心率数据包
    
    返回:
        hr: 当前心率 (bpm)
        rr_intervals: 此次推送包含的 RR 间期列表 (ms)
    """
    flags = data[0]
    hr_16bit = flags & 0x01
    rr_present = (flags & 0x10) >> 4
    
    offset = 1
    if hr_16bit:
        hr = int.from_bytes(data[offset:offset+2], "little")
        offset += 2
    else:
        hr = data[offset]
        offset += 1
    
    rr_intervals = []
    if rr_present:
        while offset < len(data):
            rr_raw = int.from_bytes(data[offset:offset+2], "little")
            rr_ms = rr_raw * 1000 / 1024  # Polar H10 用 1/1024 秒为单位
            rr_intervals.append(rr_ms)
            offset += 2
    
    return hr, rr_intervals


def compute_rmssd(rr_list):
    """
    计算 RMSSD（HRV 时域指标，单位 ms）
    
    RMSSD = sqrt(mean(diff(RR)^2))
    
    反映副交感神经活跃度：
      - 高 → 放松、恢复好
      - 低 → 紧张、压力、激活
    """
    if len(rr_list) < 5:
        return None
    rr = np.array(rr_list)
    diffs = np.diff(rr)
    return float(np.sqrt(np.mean(diffs ** 2)))


def classify_relative(current, baseline):
    """
    基于相对基线的变化分类
    
    用比例而不是绝对值——因为 HRV 个体差异极大，
    必须做"相对自己基线"的判断才有意义。
    """
    if baseline is None or current is None:
        return "校准中..."
    
    ratio = current / baseline
    
    if ratio > 1.5:
        return "🟢🟢 显著放松 (副交感↑↑)"
    elif ratio > 1.2:
        return "🟢 放松 (副交感↑)"
    elif ratio > 0.85:
        return "🟡 基线状态"
    elif ratio > 0.65:
        return "🟠 紧张 (交感↑)"
    else:
        return "🔴 高压/激活 (交感↑↑)"


async def main():
    global baseline_rmssd
    
    print("=" * 60)
    print("Polar H10 · HRV 实时监测")
    print("=" * 60)
    print("\n扫描 Polar H10...")
    
    device = await BleakScanner.find_device_by_filter(
        lambda d, ad: d.name and "Polar H10" in d.name,
        timeout=15
    )
    
    if not device:
        print("\n❌ 没找到 Polar H10 胸带。检查：")
        print("   (1) 胸带电极是否打湿")
        print("   (2) 胸带是否戴在身上")
        print("   (3) 手机 Polar Beat App 是否已关闭（会抢占连接）")
        return
    
    print(f"✅ 找到设备：{device.name} ({device.address})")
    print("正在连接...\n")
    
    sample_count = 0
    
    async with BleakClient(device) as client:
        print("【校准阶段】前 30 秒请保持自然呼吸、不动，建立个人基线...\n")
        
        def callback(_, data):
            nonlocal sample_count
            global baseline_rmssd
            
            hr, rrs = parse_hr_data(data)
            
            # 同步两个窗口
            for rr in rrs:
                rr_short.append(rr)
                rr_baseline_pool.append(rr)
            
            sample_count += 1
            current_rmssd = compute_rmssd(list(rr_short))
            
            # 校准完成时输出基线
            if baseline_rmssd is None and len(rr_baseline_pool) >= 30:
                baseline_rmssd = compute_rmssd(list(rr_baseline_pool))
                print(f"\n✅ 个人基线 RMSSD = {baseline_rmssd:.1f} ms")
                print(f"   现在可以做实验了：深呼吸、屏息、突然站起来都试试\n")
            
            # 每 2 次推送显示一次（避免刷屏）
            if sample_count % 2 == 0:
                if baseline_rmssd is None:
                    progress = min(100, len(rr_baseline_pool) * 100 // 30)
                    rmssd_str = f"{current_rmssd:5.1f}ms" if current_rmssd is not None else "  ---  "
                    print(f"❤️  HR: {hr:3d} | 短时RMSSD: {rmssd_str} | 校准 {progress}%")
                else:
                    status = classify_relative(current_rmssd, baseline_rmssd)
                    if current_rmssd is not None:
                        ratio = current_rmssd / baseline_rmssd
                        print(f"❤️  HR: {hr:3d} | RMSSD: {current_rmssd:5.1f}ms (基线 {baseline_rmssd:.1f}) | ×{ratio:.2f} | {status}")
                    else:
                        print(f"❤️  HR: {hr:3d} | RMSSD:  ---  | {status}")
        
        await client.start_notify(HR_CHAR_UUID, callback)
        
        # 跑 3 分钟（足够做几个实验）
        await asyncio.sleep(180)
        
        await client.stop_notify(HR_CHAR_UUID)
        
        # 总结
        print("\n" + "=" * 60)
        print("会话结束")
        print("=" * 60)
        if len(rr_baseline_pool) > 10:
            final_rmssd = compute_rmssd(list(rr_baseline_pool))
            print(f"收集到 RR 间期：{len(rr_baseline_pool)} 个")
            print(f"平均 RR：{np.mean(rr_baseline_pool):.1f} ms")
            print(f"个人基线 RMSSD：{baseline_rmssd:.1f} ms" if baseline_rmssd else "")
            print(f"最终 RMSSD：{final_rmssd:.1f} ms")


if __name__ == "__main__":
    asyncio.run(main())